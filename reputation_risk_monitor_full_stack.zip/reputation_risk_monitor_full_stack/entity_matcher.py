from __future__ import annotations

import hashlib
import re
from typing import Iterable, List, Tuple

import pandas as pd

DEFAULT_CONTEXT_TERMS = [
    "bank", "banks", "banking", "company", "capital", "credit", "payments", "payment",
    "regulatory", "lawsuit", "filing", "investor", "finance", "financial", "market",
    "loan", "fund", "trust", "securities", "shares", "stock", "corp", "plc", "inc",
    "ltd", "llc", "rating", "debt", "bond", "settlement", "probe", "investigation",
]


def clean_text(value: object) -> str:
    if value is None or pd.isna(value):
        return ""
    text = str(value)
    text = re.sub(r"&nbsp;", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def norm(value: object) -> str:
    text = clean_text(value).lower()
    text = text.replace("’", "'")
    return text


def tokenize(text: str) -> List[str]:
    return re.findall(r"[a-z0-9&'.-]+", norm(text))


def phrase_tokens(phrase: str) -> List[str]:
    return tokenize(phrase)


def phrase_positions(tokens: List[str], phrase: str) -> List[int]:
    pt = phrase_tokens(phrase)
    if not pt or len(pt) > len(tokens):
        return []
    out = []
    n = len(pt)
    for i in range(0, len(tokens) - n + 1):
        if tokens[i:i + n] == pt:
            out.append(i)
    return out


def any_near(tokens: List[str], anchors: List[int], terms: Iterable[str], window: int) -> Tuple[bool, List[str]]:
    hits = []
    if not anchors:
        return False, []
    for term in terms:
        for pos in phrase_positions(tokens, term):
            if any(abs(pos - anchor) <= window for anchor in anchors):
                hits.append(term)
                break
    return bool(hits), sorted(set(hits))


def any_present(text: str, terms: Iterable[str]) -> List[str]:
    low = norm(text)
    hits = []
    for term in terms:
        term_clean = norm(term)
        if not term_clean:
            continue
        if re.search(rf"\b{re.escape(term_clean)}\b", low):
            hits.append(term)
    return sorted(set(hits))


def split_terms(value: object) -> List[str]:
    text = clean_text(value)
    if not text:
        return []
    parts = re.split(r"[;|,]", text)
    return [p.strip() for p in parts if p.strip()]


def story_id(title: object, snippet: object = "") -> str:
    text = norm(title)
    text = re.sub(r"[^a-z0-9 ]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        text = norm(snippet)[:120]
    return hashlib.md5(text.encode("utf-8")).hexdigest()[:12]


def load_portfolio_data(data_dir) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    counterparties = pd.read_csv(data_dir / "counterparties.csv")
    aliases = pd.read_csv(data_dir / "counterparty_aliases.csv")
    exclusions = pd.read_csv(data_dir / "counterparty_exclusions.csv")
    for df in [counterparties, aliases, exclusions]:
        for col in df.columns:
            if df[col].dtype == object:
                df[col] = df[col].fillna("")
    return counterparties, aliases, exclusions


def prepare_aliases(counterparties: pd.DataFrame, aliases: pd.DataFrame, exclusions: pd.DataFrame) -> pd.DataFrame:
    cp_cols = [
        "counterparty_id", "legal_name", "common_name", "ticker", "counterparty_type_guess",
        "country_guess", "source_name_status", "match_risk_level", "alias_review_required",
        "review_flags", "importance_tier", "exposure_index", "relationship_owner", "notes",
    ]
    cp = counterparties[[c for c in cp_cols if c in counterparties.columns]].copy()
    out = aliases.merge(cp, on="counterparty_id", how="left")
    exc = exclusions[["counterparty_id", "alias_text", "do_not_match_terms", "require_context_terms"]].copy()
    exc = exc.rename(columns={
        "do_not_match_terms": "exclusion_do_not_match_terms",
        "require_context_terms": "exclusion_require_context_terms",
    })
    out = out.merge(exc, on=["counterparty_id", "alias_text"], how="left")
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].fillna("")
    out["alias_len_tokens"] = out["alias_text"].apply(lambda x: len(phrase_tokens(x)))
    out["alias_len_chars"] = out["alias_text"].apply(lambda x: len(clean_text(x)))
    return out


def match_confidence(alias_row: pd.Series, context_passed: bool, do_not_hit: bool) -> str:
    if do_not_hit:
        return "Suppressed"
    strength = clean_text(alias_row.get("match_strength"))
    requires_context = clean_text(alias_row.get("requires_context")).lower() == "yes"
    dangerous = clean_text(alias_row.get("dangerous_short_alias")).lower() == "yes"
    category = clean_text(alias_row.get("alias_category"))
    if requires_context and not context_passed:
        return "Low"
    if dangerous and not context_passed:
        return "Low"
    if category == "ticker" and not context_passed:
        return "Low"
    if strength == "Strong" and not dangerous:
        return "High"
    if strength == "Strong" and context_passed:
        return "High"
    if strength == "Medium" and (context_passed or not requires_context):
        return "Medium"
    if strength == "Weak" and context_passed:
        return "Medium"
    return "Low"


def relevance_label(confidence: str, needs_review: bool, suppressed: bool) -> str:
    if suppressed:
        return "Suppressed by exclusion rule"
    if confidence == "High" and not needs_review:
        return "Likely related"
    if confidence in {"High", "Medium"}:
        return "Likely related, review if material"
    return "Review before relying on match"


def match_articles_to_counterparties(
    articles: pd.DataFrame,
    counterparties: pd.DataFrame,
    aliases: pd.DataFrame,
    exclusions: pd.DataFrame,
    context_window: int = 18,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    prepared = prepare_aliases(counterparties, aliases, exclusions)
    prepared = prepared[prepared["active_status"].str.lower().eq("active")].copy()
    article_rows = []
    hit_rows = []
    for idx, art in articles.iterrows():
        title = clean_text(art.get("title"))
        snippet = clean_text(art.get("snippet"))
        source = clean_text(art.get("source_title") or art.get("source_name") or art.get("domain"))
        text = f"{title}. {snippet}. {source}"
        tokens = tokenize(text)
        sid = story_id(title, snippet)
        for _, alias in prepared.iterrows():
            alias_text = clean_text(alias.get("alias_text"))
            if not alias_text or len(alias_text) < 2:
                continue
            positions = phrase_positions(tokens, alias_text)
            if not positions:
                continue
            do_not_terms = split_terms(alias.get("exclusion_do_not_match_terms")) + split_terms(alias.get("do_not_match_terms"))
            do_not_hits = any_present(text, do_not_terms)
            required_terms = split_terms(alias.get("exclusion_require_context_terms")) + DEFAULT_CONTEXT_TERMS
            requires_context = clean_text(alias.get("requires_context")).lower() == "yes"
            dangerous = clean_text(alias.get("dangerous_short_alias")).lower() == "yes"
            alias_category = clean_text(alias.get("alias_category"))
            context_needed = requires_context or dangerous or alias_category == "ticker" or len(alias_text) <= 4
            context_passed, context_hits = any_near(tokens, positions, required_terms, context_window)
            suppressed = bool(do_not_hits and not context_passed)
            confidence = match_confidence(alias, context_passed, suppressed)
            source_cleanup = clean_text(alias.get("source_name_status")) == "Needs source cleanup"
            high_match_risk = clean_text(alias.get("match_risk_level")) == "High"
            alias_review_required = clean_text(alias.get("alias_review_required")).lower() == "yes"
            needs_review = bool(
                source_cleanup or high_match_risk or alias_review_required or confidence in {"Low", "Suppressed"} or context_needed
            )
            hit = {
                "article_id": art.get("validation_id", f"ARTICLE_{idx+1:05d}"),
                "story_id": sid,
                "title": title,
                "source_name": source,
                "counterparty_id": alias.get("counterparty_id"),
                "counterparty_name": alias.get("legal_name") or alias.get("common_name"),
                "alias_matched": alias_text,
                "alias_category": alias_category,
                "match_strength": alias.get("match_strength"),
                "requires_context": "Yes" if context_needed else "No",
                "context_passed": "Yes" if context_passed else "No",
                "context_hits": "; ".join(context_hits),
                "do_not_match_hits": "; ".join(do_not_hits),
                "entity_match_confidence": confidence,
                "needs_human_review": "Yes" if needs_review else "No",
                "automated_relevance_check": relevance_label(confidence, needs_review, suppressed),
                "match_reason": "Alias found with required business context." if context_needed and context_passed else "Strong alias found." if confidence == "High" else "Alias found but needs review before relying on it.",
                "suppressed": "Yes" if suppressed else "No",
                "match_risk_level": alias.get("match_risk_level"),
                "source_name_status": alias.get("source_name_status"),
            }
            hit_rows.append(hit)
            if not suppressed and confidence in {"High", "Medium"}:
                article_rows.append(hit)
    hits_df = pd.DataFrame(hit_rows)
    matches_df = pd.DataFrame(article_rows)
    if not matches_df.empty:
        priority = {"High": 3, "Medium": 2, "Low": 1}
        matches_df["confidence_rank"] = matches_df["entity_match_confidence"].map(priority).fillna(0)
        matches_df = matches_df.sort_values(
            ["article_id", "counterparty_id", "confidence_rank", "match_strength"],
            ascending=[True, True, False, True],
        )
        matches_df = matches_df.drop_duplicates(["article_id", "counterparty_id"], keep="first")
        matches_df = matches_df.drop(columns=["confidence_rank"])
    return matches_df.reset_index(drop=True), hits_df.reset_index(drop=True)
