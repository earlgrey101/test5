from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from entity_matcher import clean_text, phrase_positions, story_id, tokenize
from risk_engine import (
    any_phrase_present,
    bounded_exposure_multiplier,
    classify_claim_status,
    normalize_text,
    recency_points,
    risk_band,
    source_category,
)


def _risk_terms_by_theme(cfg: Dict) -> Dict[str, List[str]]:
    return cfg.get("risk_terms", {}) or {}


def _flat_risk_terms(cfg: Dict) -> List[str]:
    out = []
    for terms in _risk_terms_by_theme(cfg).values():
        out.extend(terms)
    return sorted(set(out), key=len, reverse=True)


def _aliases_for_counterparty(counterparty_id: str, aliases: pd.DataFrame) -> List[str]:
    if aliases is None or aliases.empty:
        return []
    sub = aliases[(aliases["counterparty_id"] == counterparty_id) & (aliases["active_status"].str.lower() == "active")]
    vals = [clean_text(x) for x in sub["alias_text"].tolist()]
    return sorted(set([v for v in vals if v]), key=len, reverse=True)


def _nearby_terms(text: str, anchors: List[str], terms: List[str], window: int) -> Tuple[bool, List[str]]:
    tokens = tokenize(text)
    positions = []
    for alias in anchors:
        positions.extend(phrase_positions(tokens, alias))
    hits = []
    for term in terms:
        term_positions = phrase_positions(tokens, term)
        if not term_positions:
            continue
        if positions and any(abs(tp - ap) <= window for tp in term_positions for ap in positions):
            hits.append(term)
    return bool(hits), sorted(set(hits))


def classify_risk_theme(text: str, aliases: List[str], cfg: Dict) -> Tuple[List[str], List[str], float]:
    themes = []
    hits = []
    window = int(cfg.get("scoring", {}).get("token_window", 12))
    for theme, terms in _risk_terms_by_theme(cfg).items():
        found, theme_hits = _nearby_terms(text, aliases + cfg.get("context_terms", []), terms, window)
        if found:
            themes.append(theme.replace("_", " ").title())
            hits.extend(theme_hits)
    context_hits = any_phrase_present(text, cfg.get("context_terms", []))
    narrative_score = 0.0
    if themes:
        narrative_score += min(30.0, 12.0 * len(set(themes)))
    if hits:
        narrative_score += min(30.0, 5.0 * len(set(hits)))
    if context_hits and not hits:
        narrative_score += 8.0
    return sorted(set(themes)), sorted(set(hits)), float(min(60.0, narrative_score))


def entity_match_points(confidence: str) -> float:
    return {"High": 20.0, "Medium": 10.0, "Low": 0.0}.get(clean_text(confidence), 0.0)


def confidence_label(score: float) -> str:
    if score >= 75:
        return "High"
    if score >= 55:
        return "Medium"
    return "Low"


def _exposure_value(match_row: pd.Series, counterparties: pd.DataFrame) -> float:
    cp_id = match_row.get("counterparty_id")
    val = match_row.get("exposure_index", "")
    try:
        if clean_text(val):
            return float(val)
    except Exception:
        pass
    if counterparties is not None and not counterparties.empty and "counterparty_id" in counterparties.columns:
        sub = counterparties[counterparties["counterparty_id"] == cp_id]
        if not sub.empty:
            try:
                if clean_text(sub.iloc[0].get("exposure_index")):
                    return float(sub.iloc[0].get("exposure_index"))
            except Exception:
                return 0.0
    return 0.0


def _source_for_article(article_row: pd.Series) -> str:
    for col in ["source_title", "source_name", "source", "domain"]:
        if col in article_row and clean_text(article_row.get(col)):
            return clean_text(article_row.get(col))
    return "Unknown"


def _serious_claim(claim_status: str) -> bool:
    return clean_text(claim_status) != "No serious claim detected"


def _gate_bucket(row: Dict, cfg: Dict) -> Tuple[str, List[str]]:
    failures = []
    rules = cfg.get("priority_review_rules", {})
    min_score = float(rules.get("minimum_score", 60))
    min_confidence = float(rules.get("minimum_confidence", 60))
    if row["overall_priority_score"] < min_score:
        failures.append("Score below priority level")
    if row["confidence_score"] < min_confidence:
        failures.append("Confidence below priority level")
    if row["entity_match_confidence"] != "High":
        failures.append("Counterparty match not high confidence")
    if rules.get("require_trusted_source", True) and not row["trusted_source"]:
        failures.append("Source is not trusted or official")
    if rules.get("require_serious_claim", True) and not _serious_claim(row["claim_status"]):
        failures.append("No serious claim status")
    if not row["risk_term_near_counterparty"]:
        failures.append("No risk term near the counterparty name")
    if row.get("duplicate_suppressed"):
        failures.append("Duplicate story already represented")
    if not failures:
        return "Priority items", []
    review_min = float(cfg.get("review_thresholds", {}).get("review_minimum_score", 40))
    if row["overall_priority_score"] >= review_min or row["risk_term_near_counterparty"] or row["trusted_source"]:
        return "Review items", failures
    return "Reference items", failures


def score_portfolio_matches(
    articles: pd.DataFrame,
    matches: pd.DataFrame,
    counterparties: pd.DataFrame,
    aliases: pd.DataFrame,
    cfg: Dict,
) -> pd.DataFrame:
    if matches is None or matches.empty:
        return pd.DataFrame()
    articles_idx = articles.copy()
    articles_idx["article_id"] = articles_idx.get("validation_id", pd.Series([f"ARTICLE_{i+1:05d}" for i in range(len(articles_idx))]))
    article_lookup = articles_idx.set_index("article_id", drop=False)
    rows = []
    story_seen = set()
    for _, match in matches.iterrows():
        article_id = clean_text(match.get("article_id"))
        if article_id not in article_lookup.index:
            continue
        art = article_lookup.loc[article_id]
        title = clean_text(art.get("title"))
        snippet = clean_text(art.get("snippet"))
        source = _source_for_article(art)
        text = f"{title}. {snippet}"
        cp_id = clean_text(match.get("counterparty_id"))
        cp_aliases = _aliases_for_counterparty(cp_id, aliases)
        if clean_text(match.get("alias_matched")) not in cp_aliases:
            cp_aliases.append(clean_text(match.get("alias_matched")))
        src_cat, src_score, trusted, low_source = source_category(source, cfg)
        claim_status, claim_hits = classify_claim_status(text, source, cfg)
        themes, risk_hits, narrative_score = classify_risk_theme(text, cp_aliases, cfg)
        near_risk, near_hits = _nearby_terms(text, cp_aliases, _flat_risk_terms(cfg), int(cfg.get("scoring", {}).get("token_window", 12)))
        context_hits = any_phrase_present(text, cfg.get("context_terms", []))
        context_only = bool(context_hits) and not bool(risk_hits)
        base = 5.0 + narrative_score
        if "trusted" in claim_status.lower() or "official" in claim_status.lower():
            base += 18.0
        elif "reported" in claim_status.lower():
            base += 10.0
        base += entity_match_points(match.get("entity_match_confidence"))
        base += recency_points(art.get("published_at"), cfg.get("scoring", {}).get("recency_half_life_days", 30))
        base = min(base, 100.0)
        confidence = 20 + 9 * src_score
        if trusted:
            confidence += 12
        if _serious_claim(claim_status):
            confidence += 10
        if match.get("entity_match_confidence") == "High":
            confidence += 12
        elif match.get("entity_match_confidence") == "Medium":
            confidence += 4
        else:
            confidence -= 15
        if low_source:
            confidence -= 20
        if context_only:
            confidence -= 12
        confidence = float(max(0, min(100, confidence)))
        exposure_index = _exposure_value(match, counterparties)
        multiplier = bounded_exposure_multiplier(exposure_index, cfg)
        if base < 35 or context_only or match.get("entity_match_confidence") != "High":
            multiplier = min(multiplier, 1.05)
        score = float(min(100.0, base * multiplier))
        sid = clean_text(match.get("story_id")) or story_id(title, snippet)
        duplicate_key = f"{sid}|{cp_id}"
        duplicate_suppressed = duplicate_key in story_seen
        story_seen.add(duplicate_key)
        out = {
            "article_id": article_id,
            "story_id": sid,
            "title": title,
            "url": clean_text(art.get("url")),
            "source_name": source,
            "source_category": src_cat,
            "trusted_source": bool(trusted),
            "published_at": clean_text(art.get("published_at")),
            "counterparty_id": cp_id,
            "counterparty_name": clean_text(match.get("counterparty_name")),
            "alias_matched": clean_text(match.get("alias_matched")),
            "alias_category": clean_text(match.get("alias_category")),
            "entity_match_confidence": clean_text(match.get("entity_match_confidence")),
            "automated_relevance_check": clean_text(match.get("automated_relevance_check")),
            "match_reason": clean_text(match.get("match_reason")),
            "needs_human_review": clean_text(match.get("needs_human_review")),
            "themes": "; ".join(themes),
            "risk_hits": "; ".join(risk_hits),
            "nearby_risk_hits": "; ".join(near_hits),
            "risk_term_near_counterparty": bool(near_risk),
            "context_terms": "; ".join(context_hits),
            "context_only_signal": bool(context_only),
            "claim_status": claim_status,
            "claim_matches": "; ".join(claim_hits),
            "base_article_risk": round(base, 1),
            "confidence_score": round(confidence, 1),
            "confidence_label": confidence_label(confidence),
            "exposure_index": exposure_index,
            "exposure_multiplier": round(multiplier, 3),
            "initial_signal_score": round(score, 1),
            "initial_signal_band": risk_band(score, cfg),
            "overall_priority_score": round(score, 1),
            "duplicate_suppressed": bool(duplicate_suppressed),
            "snippet": snippet,
        }
        bucket, failures = _gate_bucket(out, cfg)
        out["review_bucket"] = bucket
        out["gate_failure_reasons"] = "; ".join(failures)
        reason_codes = []
        if trusted:
            reason_codes.append("TRUSTED_SOURCE")
        if _serious_claim(claim_status):
            reason_codes.append("SERIOUS_CLAIM")
        if near_risk:
            reason_codes.append("RISK_TERM_NEAR_COUNTERPARTY")
        if out["entity_match_confidence"] != "High":
            reason_codes.append("ENTITY_MATCH_CAP")
        if low_source:
            reason_codes.append("SOURCE_CAP")
        if context_only:
            reason_codes.append("CONTEXT_ONLY")
        if duplicate_suppressed:
            reason_codes.append("DUPLICATE_STORY")
        out["reason_codes"] = "; ".join(reason_codes) if reason_codes else "REFERENCE_ONLY"
        if bucket == "Priority items":
            out["placement_explanation"] = "Meets the source, claim, match, and score checks for immediate review."
        elif bucket == "Review items":
            out["placement_explanation"] = "Relevant enough to review, but one or more checks held it below the priority level."
        else:
            out["placement_explanation"] = "Kept for reference because the match or risk evidence is limited."
        rows.append(out)
    scored = pd.DataFrame(rows)
    if not scored.empty:
        scored["story_count_for_counterparty"] = scored.groupby(["story_id", "counterparty_id"])["article_id"].transform("count")
        scored = scored.sort_values(["review_bucket", "overall_priority_score"], ascending=[True, False])
    return scored.reset_index(drop=True)


def portfolio_summary(counterparties: pd.DataFrame, aliases: pd.DataFrame, exclusions: pd.DataFrame, matches: pd.DataFrame, scored: pd.DataFrame) -> pd.DataFrame:
    total = len(counterparties)
    active = int(counterparties.get("active_status", pd.Series()).astype(str).str.lower().eq("active").sum()) if not counterparties.empty else 0
    high_risk = int(counterparties.get("match_risk_level", pd.Series()).astype(str).eq("High").sum()) if not counterparties.empty else 0
    needs_alias_review = int(counterparties.get("alias_review_required", pd.Series()).astype(str).str.lower().eq("yes").sum()) if not counterparties.empty else 0
    matched_counterparties = int(matches["counterparty_id"].nunique()) if matches is not None and not matches.empty else 0
    priority = int(scored["review_bucket"].eq("Priority items").sum()) if scored is not None and not scored.empty else 0
    review = int(scored["review_bucket"].eq("Review items").sum()) if scored is not None and not scored.empty else 0
    reference = int(scored["review_bucket"].eq("Reference items").sum()) if scored is not None and not scored.empty else 0
    return pd.DataFrame([
        {"metric": "Counterparties monitored", "value": total, "explanation": "Rows in the counterparty master file."},
        {"metric": "Active counterparties", "value": active, "explanation": "Counterparties currently included in matching."},
        {"metric": "Aliases available", "value": len(aliases), "explanation": "Names, tickers, brands, and variants used for matching."},
        {"metric": "Exclusion rules", "value": len(exclusions), "explanation": "Rules that suppress ambiguous matches."},
        {"metric": "High match risk counterparties", "value": high_risk, "explanation": "Names needing extra caution because they are generic, short, or incomplete."},
        {"metric": "Counterparties needing alias review", "value": needs_alias_review, "explanation": "Rows marked for manual alias cleanup."},
        {"metric": "Counterparties matched in sample", "value": matched_counterparties, "explanation": "Counterparties that appeared in the current sample article set."},
        {"metric": "Priority items", "value": priority, "explanation": "Matched items that passed all priority gates."},
        {"metric": "Review items", "value": review, "explanation": "Matched items needing review before follow up."},
        {"metric": "Reference items", "value": reference, "explanation": "Matched items retained for context or audit trail."},
    ])
