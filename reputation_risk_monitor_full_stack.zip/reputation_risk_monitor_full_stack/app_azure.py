from __future__ import annotations

import os
import uuid

import pandas as pd
import streamlit as st

from azure_sql.python.callbacks import classify_and_score, match_article
from azure_sql.python.refresh_pipeline import run_manual_refresh
from azure_sql.python.repository import AzureSqlRepository, DatabaseConfig
from news_sources import collect_phase1_news

st.set_page_config(page_title="Counterparty risk monitor - Azure SQL", layout="wide")


def repository() -> AzureSqlRepository:
    return AzureSqlRepository(DatabaseConfig.from_env())


def collect_selected(names: list[str], max_results: int):
    frame = collect_phase1_news(names, max_results_per_query=max_results, include_risk_query=True)
    return frame.to_dict(orient="records")


st.title("Counterparty risk monitor")
st.caption("Optional Azure SQL-backed entry point. The regular local dashboard remains available in app.py.")

required = ["AZURE_SQL_SERVER", "AZURE_SQL_DATABASE"]
missing = [key for key in required if not os.getenv(key)]
if missing:
    st.warning("Azure SQL settings are not configured. Copy .env.azure.example to .env or set the environment variables before using this page.")
    st.code("\n".join(f"{key}=..." for key in missing))
    st.stop()

repo = repository()
status = repo.refresh_status()
cols = st.columns(4)
cols[0].metric("Articles stored", status.get("article_count_stored", 0) or 0)
cols[1].metric("Processed this run", status.get("article_count_processed_last_run", 0) or 0)
cols[2].metric("New this run", status.get("new_article_count_last_run", 0) or 0)
cols[3].metric("Last refresh UTC", status.get("last_refresh_utc") or "Not yet refreshed")

reference = repo.load_matching_reference()
name_options = sorted({str(row.get("common_name") or row.get("legal_name")) for row in reference if row.get("common_name") or row.get("legal_name")})
selected = st.multiselect("Counterparties for this manual refresh", name_options, max_selections=10)
max_results = st.slider("Results per search", min_value=5, max_value=25, value=10)
actor_name = st.text_input("Your name")
actor_email = st.text_input("Your PayPal email")

if st.button("Refresh live articles", type="primary"):
    if not selected:
        st.error("Select at least one counterparty.")
    elif not actor_email.lower().endswith("@paypal.com"):
        st.error("Enter a valid @paypal.com email address.")
    else:
        with st.spinner("Collecting, matching, classifying, scoring, and storing articles"):
            result = run_manual_refresh(
                repository=repo,
                requested_by=actor_email,
                actor_name=actor_name or None,
                actor_ip=None,
                session_id=str(uuid.uuid4()),
                collect_articles=lambda: collect_selected(selected, max_results),
                match_article=match_article,
                classify_and_score=classify_and_score,
            )
        st.success(f"Refresh completed. {result.counts['article_rows_processed']} articles were processed.")
        st.rerun()

category = st.selectbox("Dashboard category", ["All", "PRIORITY", "REVIEW", "REFERENCE"])
items = pd.DataFrame(repo.dashboard_items(None if category == "All" else category))
st.dataframe(items, use_container_width=True, hide_index=True)
