from __future__ import annotations

import os
import re
import smtplib
from email.message import EmailMessage
from pathlib import Path

import pandas as pd

from admin_store import EMAIL_LOG_COLUMNS, EMAIL_SETTINGS_COLUMNS, RECIPIENT_COLUMNS, now_iso, read_csv, save_csv, next_numeric_id

PAYPAL_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@paypal\.com$", re.IGNORECASE)


def is_paypal_email(email: str) -> bool:
    return bool(PAYPAL_EMAIL_RE.match(str(email).strip()))


def load_recipients(data_dir: Path) -> pd.DataFrame:
    return read_csv(data_dir / "email_recipients.csv", RECIPIENT_COLUMNS)


def load_email_settings(data_dir: Path) -> dict:
    df = read_csv(data_dir / "email_settings.csv", EMAIL_SETTINGS_COLUMNS)
    return {str(row["setting"]): str(row["value"]) for _, row in df.iterrows()}


def save_email_setting(data_dir: Path, setting: str, value: str) -> None:
    path = data_dir / "email_settings.csv"
    df = read_csv(path, EMAIL_SETTINGS_COLUMNS)
    if setting in set(df["setting"].astype(str)):
        df.loc[df["setting"].astype(str) == setting, "value"] = value
    else:
        df.loc[len(df)] = [setting, value]
    save_csv(df, path)


def add_recipient(data_dir: Path, display_name: str, email: str, notes: str = "") -> tuple[bool, str]:
    email = str(email).strip().lower()
    display_name = str(display_name).strip()
    if not display_name:
        return False, "Enter a display name."
    if not is_paypal_email(email):
        return False, "Recipient email must end in @paypal.com."
    path = data_dir / "email_recipients.csv"
    df = load_recipients(data_dir)
    existing = df[df["email"].astype(str).str.lower() == email]
    if not existing.empty:
        idx = existing.index[0]
        df.loc[idx, "display_name"] = display_name
        df.loc[idx, "active_status"] = "Active"
        df.loc[idx, "removed_at"] = ""
        df.loc[idx, "notes"] = notes
        save_csv(df, path)
        return True, "Recipient already existed and was set to active."
    recipient_id = next_numeric_id(df["recipient_id"], "RECIP_", 4)
    df.loc[len(df)] = [recipient_id, display_name, email, "Active", now_iso(), "", notes]
    save_csv(df, path)
    return True, "Recipient added."


def deactivate_recipient(data_dir: Path, recipient_id: str) -> tuple[bool, str]:
    path = data_dir / "email_recipients.csv"
    df = load_recipients(data_dir)
    idx = df.index[df["recipient_id"].astype(str) == str(recipient_id)]
    if not len(idx):
        return False, "Recipient not found."
    df.loc[idx, "active_status"] = "Inactive"
    df.loc[idx, "removed_at"] = now_iso()
    save_csv(df, path)
    return True, "Recipient removed from active list."


def active_recipients(data_dir: Path) -> pd.DataFrame:
    df = load_recipients(data_dir)
    return df[df["active_status"].astype(str).str.lower() == "active"].copy()


def compose_priority_email(scored: pd.DataFrame, sender_name: str = "External Risk Monitor") -> tuple[str, str]:
    priority = scored[scored["review_bucket"].astype(str) == "Priority items"].copy() if scored is not None and not scored.empty else pd.DataFrame()
    subject = f"Priority counterparty risk items: {len(priority)}"
    lines = [
        f"{sender_name}",
        "",
        f"Priority items in the current dashboard run: {len(priority)}",
        "",
    ]
    if priority.empty:
        lines.extend([
            "No current rows meet the priority criteria.",
            "",
            "This message was generated from the local dashboard preview.",
        ])
    else:
        for i, (_, row) in enumerate(priority.sort_values("overall_priority_score", ascending=False).iterrows(), 1):
            lines.extend([
                f"{i}. {row.get('counterparty_name', '')}",
                f"Placement: {row.get('review_bucket', '')}",
                f"Score: {row.get('overall_priority_score', '')}",
                f"Source: {row.get('source_name', '')}",
                f"Claim: {row.get('claim_status', '')}",
                f"Article: {row.get('title', '')}",
                f"Reason: {row.get('placement_explanation', '')}",
                "",
            ])
        lines.extend([
            "Review notes:",
            "This email only includes rows that passed the dashboard's priority rules.",
            "It does not make legal conclusions or final risk ratings.",
        ])
    return subject, "\n".join(lines)


def smtp_ready(sender_email: str) -> tuple[bool, str]:
    if not is_paypal_email(sender_email):
        return False, "Sender email must be a @paypal.com address."
    missing = [k for k in ["SMTP_HOST", "SMTP_PORT", "SMTP_USERNAME", "SMTP_PASSWORD"] if not os.getenv(k)]
    if missing:
        return False, f"Missing SMTP environment variables: {', '.join(missing)}"
    return True, "SMTP settings found."


def log_email_attempt(data_dir: Path, mode: str, sender_email: str, recipient_count: int, subject: str, item_count: int, status: str, error: str = "") -> None:
    path = data_dir / "email_send_log.csv"
    df = read_csv(path, EMAIL_LOG_COLUMNS)
    df.loc[len(df)] = [now_iso(), mode, sender_email, recipient_count, subject, item_count, status, error]
    save_csv(df, path)


def send_priority_email(data_dir: Path, scored: pd.DataFrame, sender_email: str, sender_name: str, recipients: pd.DataFrame, dry_run: bool = True) -> tuple[bool, str]:
    subject, body = compose_priority_email(scored, sender_name)
    item_count = int(scored["review_bucket"].astype(str).eq("Priority items").sum()) if scored is not None and not scored.empty else 0
    recipient_emails = [str(x).strip().lower() for x in recipients.get("email", pd.Series(dtype=str)).tolist() if str(x).strip()]
    bad = [email for email in recipient_emails if not is_paypal_email(email)]
    if bad:
        msg = "All recipients must end in @paypal.com."
        log_email_attempt(data_dir, "blocked", sender_email, len(recipient_emails), subject, item_count, "Blocked", msg)
        return False, msg
    if not recipient_emails:
        msg = "No active recipients selected."
        log_email_attempt(data_dir, "blocked", sender_email, 0, subject, item_count, "Blocked", msg)
        return False, msg
    if dry_run:
        log_email_attempt(data_dir, "preview", sender_email, len(recipient_emails), subject, item_count, "Preview only", "")
        return True, "Preview logged. No email was sent."
    ready, message = smtp_ready(sender_email)
    if not ready:
        log_email_attempt(data_dir, "blocked", sender_email, len(recipient_emails), subject, item_count, "Blocked", message)
        return False, message
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = f"{sender_name} <{sender_email}>"
        msg["To"] = sender_email
        msg["Bcc"] = ", ".join(recipient_emails)
        msg.set_content(body)
        host = os.getenv("SMTP_HOST")
        port = int(os.getenv("SMTP_PORT", "587"))
        username = os.getenv("SMTP_USERNAME")
        password = os.getenv("SMTP_PASSWORD")
        with smtplib.SMTP(host, port, timeout=30) as server:
            server.starttls()
            server.login(username, password)
            server.send_message(msg)
        log_email_attempt(data_dir, "sent", sender_email, len(recipient_emails), subject, item_count, "Sent", "")
        return True, "Email sent via BCC."
    except Exception as exc:
        log_email_attempt(data_dir, "error", sender_email, len(recipient_emails), subject, item_count, "Error", str(exc))
        return False, str(exc)


def load_email_log(data_dir: Path) -> pd.DataFrame:
    return read_csv(data_dir / "email_send_log.csv", EMAIL_LOG_COLUMNS)
