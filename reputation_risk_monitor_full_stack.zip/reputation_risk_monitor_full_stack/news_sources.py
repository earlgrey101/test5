from __future__ import annotations

from datetime import datetime, timezone
from urllib.parse import quote_plus

import pandas as pd

try:
    import feedparser
except Exception:
    feedparser = None

try:
    import requests
except Exception:
    requests = None

USER_AGENT = "Phase1RiskMonitor/0.1 contact: local"


def google_news_rss_query(query: str, max_results: int = 25) -> pd.DataFrame:
    if feedparser is None:
        raise RuntimeError("feedparser is not installed")
    url = f"https://news.google.com/rss/search?q={quote_plus(query)}&hl=en-US&gl=US&ceid=US:en"
    parsed = feedparser.parse(url)
    rows = []
    for entry in parsed.entries[:max_results]:
        try:
            source_title = entry.get("source", {}).get("title", "")
        except Exception:
            source_title = ""
        rows.append(
            {
                "title": entry.get("title", ""),
                "url": entry.get("link", ""),
                "domain": "news.google.com",
                "source_title": source_title,
                "snippet": entry.get("summary", entry.get("title", "")),
                "published_at": entry.get("published", ""),
                "feed_source": "google_news_rss",
                "query": query,
                "is_error": False,
                "error_message": "",
                "searched_entity": query.split()[0] if query else "",
            }
        )
    return pd.DataFrame(rows)


def collect_phase1_news(entities: list[str], max_results_per_query: int = 25, include_risk_query: bool = True) -> pd.DataFrame:
    risk_terms = "(probe OR lawsuit OR settlement OR fraud OR redemption OR withdrawal OR private credit OR valuation OR data breach OR competition)"
    frames = []
    for entity in entities:
        queries = [entity]
        if include_risk_query:
            queries.append(f"{entity} {risk_terms}")
        for q in queries:
            try:
                df = google_news_rss_query(q, max_results=max_results_per_query)
                df["searched_entity"] = entity
                frames.append(df)
            except Exception as exc:
                frames.append(
                    pd.DataFrame(
                        [
                            {
                                "title": f"FEED_ERROR: {exc}",
                                "url": "",
                                "domain": "",
                                "source_title": "",
                                "snippet": "",
                                "published_at": datetime.now(timezone.utc).isoformat(),
                                "feed_source": "google_news_rss",
                                "query": q,
                                "is_error": True,
                                "error_message": str(exc),
                                "searched_entity": entity,
                            }
                        ]
                    )
                )
    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    out["_norm_title"] = out["title"].astype(str).str.lower().str.replace(r"\W+", " ", regex=True).str.strip()
    out = out.drop_duplicates(subset=["searched_entity", "_norm_title"]).drop(columns=["_norm_title"])
    return out.reset_index(drop=True)


def load_local_articles(path: str) -> pd.DataFrame:
    return pd.read_csv(path)
