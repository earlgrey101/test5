from __future__ import annotations

import pandas as pd


def fetch_price_history(tickers: list[str], period: str = "6mo") -> pd.DataFrame:
                                                    
    try:
        import yfinance as yf

        data = yf.download(tickers, period=period, auto_adjust=True, progress=False, group_by="ticker")
        frames = []
        for t in tickers:
            if isinstance(data.columns, pd.MultiIndex):
                if (t, "Close") in data.columns:
                    s = data[(t, "Close")].rename(t)
                else:
                    continue
            else:
                s = data["Close"].rename(t)
            frames.append(s)
        if not frames:
            return pd.DataFrame()
        return pd.concat(frames, axis=1).dropna(how="all")
    except Exception:
        return pd.DataFrame()


def compute_market_context(prices: pd.DataFrame) -> pd.DataFrame:
                                                        
    if prices.empty:
        return pd.DataFrame()
    rets = prices.pct_change().dropna() * 100
    rows = []
    for t in rets.columns:
        row = {
            "ticker": t,
            "latest_1d_return_pct": round(float(rets[t].iloc[-1]), 2) if len(rets) else None,
            "latest_5d_return_pct": round(float((prices[t].iloc[-1] / prices[t].iloc[-6] - 1) * 100), 2) if len(prices[t].dropna()) >= 6 else None,
            "volatility_30d_pct": round(float(rets[t].tail(30).std()), 2) if len(rets[t].dropna()) >= 5 else None,
        }
        if "SPY" in rets.columns and t != "SPY":
            row["latest_1d_minus_SPY_pct"] = round(float(rets[t].iloc[-1] - rets["SPY"].iloc[-1]), 2)
        rows.append(row)
    return pd.DataFrame(rows)


def event_study_context(articles: pd.DataFrame, prices: pd.DataFrame, ticker_map: dict[str, str]) -> pd.DataFrame:
                                                    
    if articles.empty or prices.empty:
        return pd.DataFrame()
    prices = prices.sort_index()
    rows = []
    for _, r in articles.iterrows():
        ticker = ticker_map.get(r.get("primary_entity"), "")
        if not ticker or ticker not in prices.columns:
            continue
        try:
            event_date = pd.to_datetime(r.get("published_at"), utc=True).tz_convert(None).date()
        except Exception:
            continue
        trading_dates = list(prices.index.date)
        future_dates = [d for d in trading_dates if d >= event_date]
        if len(future_dates) < 4:
            rows.append({
                "title": r.get("title"),
                "entity": r.get("primary_entity"),
                "ticker": ticker,
                "event_date": str(event_date),
                "event_window_status": "Pending",
                "three_day_return_pct": None,
                "interpretation": "Event window pending. There is not enough forward market data.",
            })
            continue
        d0, d3 = future_dates[0], future_dates[3]
        p0 = prices.loc[[idx for idx in prices.index if idx.date()==d0][0], ticker]
        p3 = prices.loc[[idx for idx in prices.index if idx.date()==d3][0], ticker]
        ret = (p3 / p0 - 1) * 100
        rows.append({
            "title": r.get("title"),
            "entity": r.get("primary_entity"),
            "ticker": ticker,
            "event_date": str(event_date),
            "event_window_status": "Complete",
            "three_day_return_pct": round(float(ret), 2),
            "interpretation": "Market context only. This is not causal proof.",
        })
    return pd.DataFrame(rows)
