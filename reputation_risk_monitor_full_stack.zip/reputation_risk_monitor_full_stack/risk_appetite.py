from __future__ import annotations

from typing import Dict, List

import pandas as pd


def marker_status(value: float, near: float, outside: float) -> str:
    if value > outside:
        return "Outside appetite"
    if value > near:
        return "Near appetite"
    return "Within appetite"


def marker_note(metric: str, value: float, near: float, outside: float) -> str:
    return f"{metric}: {value}. Near range starts above {near}. Above range starts above {outside}."


def summarize_risk_appetite(scored: pd.DataFrame, cfg: Dict) -> pd.DataFrame:
    appetite = cfg.get("risk_appetite", {})
    review = cfg.get("review_thresholds", {})
    if scored is None or scored.empty:
        return pd.DataFrame([
            {
                "marker": "No scored data",
                "value": 0,
                "near_threshold": "",
                "outside_threshold": "",
                "status": "No data",
                "interpretation": "Load the sample data or run a public scan.",
            }
        ])

    priority_count = int((scored["review_bucket"] == "Priority items").sum())
    review_count = int((scored["review_bucket"] == "Review items").sum())
    high_non_priority = int(
        (scored["review_bucket"].ne("Priority items")
         & scored["initial_signal_score"].ge(float(review.get("high_review_item_score", 75)))).sum()
    )
    low_conf_review = int(
        (scored["review_bucket"].eq("Review items")
         & scored["confidence_label"].eq("Low")).sum()
    )
    lower_source_review = int(
        (scored["review_bucket"].eq("Review items")
         & scored["source_category"].isin(["Unknown", "Low confidence"])).sum()
    )
    source_capped_high = int(
        (scored["source_cap_applied"].astype(bool)
         & scored["initial_signal_band"].isin(["High", "Critical"])).sum()
    )

    rows: List[dict] = []

    def add(metric: str, value: int, near_key: str, outside_key: str, why: str) -> None:
        near = float(appetite.get(near_key, 0))
        outside = float(appetite.get(outside_key, near))
        status = marker_status(value, near, outside)
        rows.append(
            {
                "marker": metric,
                "value": value,
                "near_threshold": near,
                "outside_threshold": outside,
                "status": status,
                "interpretation": why + " " + marker_note(metric, value, near, outside),
            }
        )

    add(
        "Items needing attention",
        priority_count,
        "near_priority_items",
        "max_priority_items",
        "Shows whether the current scan has an unusual number of rows for senior review.",
    )
    add(
        "Items needing review",
        review_count,
        "near_review_items",
        "max_review_items",
        "Shows the volume of rows that should be checked before any follow up.",
    )
    add(
        "High raw signals kept below attention level",
        high_non_priority,
        "near_high_review_items",
        "max_high_review_items",
        "Shows severe looking rows that were held back by confidence, source, or claim checks.",
    )
    add(
        "Low confidence rows needing review",
        low_conf_review,
        "near_low_confidence_review_items",
        "max_low_confidence_review_items",
        "Shows how much review volume depends on lower confidence material.",
    )
    add(
        "Lower source rows needing review",
        lower_source_review,
        "near_lower_source_review_items",
        "max_lower_source_review_items",
        "Shows rows that need better source confirmation before being raised.",
    )
    add(
        "High raw signals limited by source checks",
        source_capped_high,
        "near_source_capped_high_items",
        "max_source_capped_high_items",
        "Shows rows that looked severe in text but were limited by source quality.",
    )
    return pd.DataFrame(rows)


def threshold_summary(cfg: Dict) -> pd.DataFrame:
    rows = []
    rb = cfg.get("risk_bands", {})
    rules = cfg.get("priority_review_rules", {})
    scoring = cfg.get("scoring", {})
    review = cfg.get("review_thresholds", {})
    appetite = cfg.get("risk_appetite", {})

    def add(category: str, setting: str, value: object, note: str) -> None:
        rows.append({"category": category, "setting": setting, "current_value": value, "note": note})

    add("Raw signal levels", "Medium begins at", rb.get("medium"), "Raw text and claim score needed for a medium raw signal.")
    add("Raw signal levels", "High begins at", rb.get("high"), "Raw text and claim score needed for a high raw signal.")
    add("Raw signal levels", "Critical begins at", rb.get("critical"), "Raw text and claim score needed for a critical raw signal.")
    add("Attention level", "Minimum score", rules.get("minimum_score"), "Minimum score before a row can appear as needing attention.")
    add("Attention level", "Minimum confidence", rules.get("minimum_confidence"), "Minimum confidence before a row can appear as needing attention.")
    add("Review level", "Minimum score", review.get("review_minimum_score"), "Score that can place a row into the review level.")
    add("Review level", "High raw signal marker", review.get("high_review_item_score"), "Used to count severe looking rows kept below the attention level.")
    add("Matching", "Nearby word range", scoring.get("token_window"), "Maximum word distance between an entity or context term and a risk term.")
    add("Exposure", "Maximum exposure lift", scoring.get("exposure_multiplier_cap"), "Maximum amount exposure can increase a credible row.")
    add("Exposure", "Exposure curve", scoring.get("exposure_log_alpha"), "Controls how quickly exposure increases the priority score.")
    names = {
        "max_priority_items": "Needs attention above range",
        "near_priority_items": "Needs attention near range",
        "max_review_items": "Needs review above range",
        "near_review_items": "Needs review near range",
        "max_high_review_items": "High raw signals above range",
        "near_high_review_items": "High raw signals near range",
        "max_low_confidence_review_items": "Low confidence rows above range",
        "near_low_confidence_review_items": "Low confidence rows near range",
        "max_lower_source_review_items": "Lower source rows above range",
        "near_lower_source_review_items": "Lower source rows near range",
        "max_source_capped_high_items": "Source limited rows above range",
        "near_source_capped_high_items": "Source limited rows near range",
    }
    for key, val in appetite.items():
        add("Range markers", names.get(key, key.replace("_", " ").title()), val, "Demo marker used to explain current volume.")
    return pd.DataFrame(rows)
