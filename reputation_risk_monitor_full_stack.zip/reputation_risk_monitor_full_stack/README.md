# Counterparty risk monitor full stack

This folder combines the latest working local Streamlit dashboard with the Azure SQL database design and integration code.

## What is included

### Working local dashboard

Run `app.py` for the current local CSV-backed application. It includes:

- PayPal-aligned GUI and top navigation
- 373-counterparty portfolio data
- legal names, common names, aliases, tickers, and exclusions
- article-to-counterparty matching
- entity match confidence
- coded risk theme classification
- claim-strength classification
- risk scoring and hard gates
- Priority, Review, and Reference categories
- counterparty and alias administration
- email-recipient administration and preview/send controls
- audit trail and rolling retention

### Azure SQL layer

The `azure_sql` folder contains:

- `sql/all_in_one.sql`: schemas, tables, seeds, indexes, views, procedures, triggers, roles, retention, email queue, audit, and dashboard objects
- `python/repository.py`: Azure SQL access layer
- `python/refresh_pipeline.py`: manual collection-to-storage orchestration
- `python/callbacks.py`: adapter connecting the existing matcher/classifier/scorer to the Azure pipeline
- `docs/architecture.md`: architecture and processing flow
- `docs/data_dictionary.csv`: database object inventory
- `docs/PROMPT_FOR_EXTERNAL_LLM_REVIEW.md`: complete review prompt

### Optional Azure-backed Streamlit entry point

Run `app_azure.py` only after:

1. Azure SQL has been provisioned.
2. `azure_sql/sql/all_in_one.sql` has been reviewed and applied.
3. Environment variables from `.env.azure.example` have been configured.
4. Azure dependencies have been installed with `requirements-azure.txt`.

This entry point supports a manual button-triggered refresh, Azure SQL article storage, matching, classification, scoring, hard gates, and dashboard retrieval.

## Local run

Install once:

```text
py -m pip install -r requirements.txt
```

Run the working local dashboard:

```text
py -m streamlit run app.py
```

## Optional Azure run

Install Azure support:

```text
py -m pip install -r requirements-azure.txt
```

Set the Azure SQL environment values, then run:

```text
py -m streamlit run app_azure.py
```

## Important boundary

`app.py` is the fully working local prototype using CSV storage and sample articles.

The Azure SQL layer is an integration-ready database and pipeline scaffold. It still requires company Azure provisioning, Microsoft Entra permissions, network/security review, approved news-source access, SQL execution/testing, and approved email integration before production use.
