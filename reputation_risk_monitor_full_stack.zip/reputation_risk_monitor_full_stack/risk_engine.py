from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd


              

def normalize_text(text: object) -> str:
       
    if text is None or (isinstance(text, float) and np.isnan(text)):
        return ""
    text = str(text)
    text = re.sub(r"&nbsp;", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def tokenize(text: str) -> List[str]:
       
    return re.findall(r"[A-Za-z0-9$%\.\-]+", normalize_text(text).lower())


def phrase_positions(tokens: List[str], phrase: str) -> List[int]:
       
    phrase_tokens = tokenize(phrase)
    if not phrase_tokens or len(phrase_tokens) > len(tokens):
        return []
    positions = []
    n = len(phrase_tokens)
    for i in range(len(tokens) - n + 1):
        if tokens[i : i + n] == phrase_tokens:
            positions.append(i)
    return positions


def acronym_present(text: str, acronym: str) -> bool:
       
    return bool(re.search(rf"\b{re.escape(acronym)}\b", normalize_text(text)))


def any_phrase_present(text: str, phrases: Iterable[str]) -> List[str]:
       
    clean = normalize_text(text)
    low = clean.lower()
    hits = []
    for phrase in phrases:
        if phrase in {"SEC", "DOJ", "FTC", "CFPB"}:
            if acronym_present(clean, phrase):
                hits.append(phrase)
        elif phrase.lower() in low:
            hits.append(phrase)
    return hits


def has_nearby_risk_term(text: str, entity_aliases: List[str], context_terms: List[str], risk_terms: List[str], window: int = 12) -> Tuple[bool, List[str]]:
       
    tokens = tokenize(text)
    anchor_positions = []
    for phrase in entity_aliases + context_terms:
        anchor_positions.extend(phrase_positions(tokens, phrase))

    risk_hits = []
    for term in risk_terms:
        term_positions = phrase_positions(tokens, term)
        if not term_positions:
            continue
        if not anchor_positions:
                                                                                              
                                                                                                
            risk_hits.append(term)
            continue
        for tp in term_positions:
            if any(abs(tp - ap) <= window for ap in anchor_positions):
                risk_hits.append(term)
                break
    return bool(risk_hits), sorted(set(risk_hits))


                           

def clean_source(row: pd.Series) -> str:
       
    for col in ["source_name", "source_title", "source", "publisher", "domain"]:
        if col in row and normalize_text(row.get(col)):
            return normalize_text(row.get(col))
    return "Unknown"


def source_category(source: str, cfg: Dict) -> Tuple[str, int, bool, bool]:
       
    src = normalize_text(source)
    trusted = cfg.get("trusted_sources", [])
    medium = cfg.get("medium_sources", [])
    low = cfg.get("blocked_or_low_confidence_sources", [])

    def matches(source_name: str, names: List[str]) -> bool:
        return any(name.lower() == source_name.lower() or name.lower() in source_name.lower() for name in names)

    if matches(src, trusted):
        return "Trusted", 5, True, False
    if matches(src, medium):
        return "Medium", 3, False, False
    if matches(src, low):
        return "Low confidence", 1, False, True
    return "Unknown", 2, False, False


def detect_primary_entity(text: str, cfg: Dict, fallback: str = "") -> Tuple[str, List[str]]:
       
    found = []
    clean = normalize_text(text)
    for entity, meta in cfg.get("entities", {}).items():
        aliases = meta.get("aliases", [entity])
        for alias in aliases:
            if alias in {"PYPL", "KKR", "OWL"}:
                if acronym_present(clean, alias):
                    found.append(entity)
                    break
            elif re.search(rf"\b{re.escape(alias)}\b", clean, flags=re.IGNORECASE):
                found.append(entity)
                break
    if found:
        return found[0], sorted(set(found))
    if fallback in cfg.get("entities", {}):
                                                                                      
                                                                         
        return fallback, []
    return "Unmatched", []


                                     

def flatten_risk_terms(cfg: Dict) -> List[str]:
       
    terms = []
    for vals in cfg.get("risk_terms", {}).values():
        terms.extend(vals)
    return sorted(set(terms), key=len, reverse=True)


def classify_claim_status(text: str, source: str, cfg: Dict) -> Tuple[str, List[str]]:
       
    clean = normalize_text(text)
    src_cat, _, trusted, _ = source_category(source, cfg)
    official_sources = ["SEC", "DOJ", "FTC", "CFPB"]
    if any(src.lower() == normalize_text(source).lower() or src.lower() in normalize_text(source).lower() for src in official_sources):
        return "Confirmed regulatory or official source", [normalize_text(source)]

    official_terms = ["enforcement action", "consent order", "court filing", "complaint filed", "charged", "settlement"]
    investigation_terms = ["probe", "investigation", "inquiry", "lawsuit", "class action", "sued", "alleges", "alleged", "Justice Department"]
    official_hits = any_phrase_present(clean, official_terms)
    investigation_hits = any_phrase_present(clean, investigation_terms + ["DOJ", "SEC", "FTC", "CFPB"])

    if official_hits and trusted:
        return "Reported legal or regulatory development by trusted source", official_hits
    if investigation_hits and trusted:
        return "Reported investigation by trusted source", investigation_hits
    if official_hits or investigation_hits:
        return "Reported legal or regulatory development", official_hits + investigation_hits
    return "No serious claim detected", []


def detect_themes(text: str, cfg: Dict, entity_aliases: List[str]) -> Tuple[List[str], List[str], List[str], bool]:
       
    context_hits = any_phrase_present(text, cfg.get("context_terms", []))
    all_risk_hits = []
    themes = []
    for theme, terms in cfg.get("risk_terms", {}).items():
        nearby, hits = has_nearby_risk_term(
            text,
            entity_aliases=entity_aliases,
            context_terms=cfg.get("context_terms", []),
            risk_terms=terms,
            window=int(cfg.get("scoring", {}).get("token_window", 12)),
        )
        if nearby:
            themes.append(theme.replace("_", " ").title())
            all_risk_hits.extend(hits)
    context_only = bool(context_hits) and not bool(all_risk_hits)
    return sorted(set(themes)), sorted(set(all_risk_hits)), sorted(set(context_hits)), context_only


def recency_points(published_at: object, half_life_days: int = 30) -> float:
       
    try:
        dt = pd.to_datetime(published_at, utc=True)
        days = max(0, (pd.Timestamp.now(tz="UTC") - dt).days)
        return float(8 * np.exp(-np.log(2) * days / max(half_life_days, 1)))
    except Exception:
        return 0.0


def bounded_exposure_multiplier(exposure_index: float, cfg: Dict) -> float:
       
    scoring = cfg.get("scoring", {})
    cap = float(scoring.get("exposure_multiplier_cap", 1.30))
    alpha = float(scoring.get("exposure_log_alpha", 0.10))
    e = max(0.0, float(exposure_index or 0.0))
    return float(min(cap, 1.0 + alpha * np.log1p(e)))


def risk_band(score: float, cfg: Dict) -> str:
       
    rb = cfg.get("risk_bands", {})
    if score >= rb.get("critical", 80):
        return "Critical"
    if score >= rb.get("high", 60):
        return "High"
    if score >= rb.get("medium", 35):
        return "Medium"
    return "Low"


def escalation_marker(bucket: str) -> str:
                                                         
    if bucket == "Priority items":
        return "Needs attention"
    if bucket == "Review items":
        return "Needs review"
    return "Reference only"


def apply_hard_caps(row: Dict, cfg: Dict) -> Dict:
       
    not_escalated = []
    row["hard_cap_applied"] = False
    row["source_cap_applied"] = False
    row["context_cap_applied"] = False
    row["entity_match_cap_applied"] = False
    if row["context_only_signal"]:
        row["hard_cap_applied"] = True
        row["context_cap_applied"] = True
        row["review_bucket"] = "Reference items"
        row["priority_item"] = False
        not_escalated.append("Context only. No nearby risk term was found.")
    if row.get("searched_entity_only"):
        row["hard_cap_applied"] = True
        row["entity_match_cap_applied"] = True
        if row.get("source_category") in {"Low confidence", "Unknown", "Medium"}:
            row["review_bucket"] = "Reference items"
        else:
            row["review_bucket"] = "Reference items" if row.get("context_only_signal") else "Review items"
        row["priority_item"] = False
        not_escalated.append("The article does not directly mention the monitored entity. The match came from the search query.")
    if row["source_category"] in {"Low confidence", "Unknown"} and row["initial_signal_band"] in {"High", "Critical"} and not row.get("searched_entity_only"):
        row["review_bucket"] = "Review items"
        row["priority_item"] = False
        row["hard_cap_applied"] = True
        row["source_cap_applied"] = True
        not_escalated.append("Source is not trusted or official, so it stays below the attention level.")
    if row["confidence_score"] < float(cfg.get("priority_review_rules", {}).get("minimum_confidence", 60)) and row["review_bucket"] == "Priority items":
        row["review_bucket"] = "Review items"
        row["priority_item"] = False
        row["hard_cap_applied"] = True
        not_escalated.append("Confidence is below the attention level.")
    row["not_escalated_reason"] = " ".join(not_escalated) if not_escalated else row.get("not_escalated_reason", "")
    row["final_escalation_marker"] = escalation_marker(row.get("review_bucket", "Reference items"))
    return row


def priority_gate(row: Dict, cfg: Dict) -> bool:
       
    rules = cfg.get("priority_review_rules", {})
    if row["overall_priority_score"] < float(rules.get("minimum_score", 65)):
        return False
    if row["confidence_score"] < float(rules.get("minimum_confidence", 60)):
        return False
    if rules.get("require_trusted_source", True) and not row["trusted_source"]:
        return False
    if rules.get("require_serious_claim", True) and row["claim_status"] == "No serious claim detected":
        return False
    if row["context_only_signal"]:
        return False
    return True


def score_article(row: pd.Series, cfg: Dict) -> Dict:
       
    if bool(row.get("is_error", False)):
        return {"drop_reason": "Feed error row excluded from scoring."}

    title = normalize_text(row.get("title"))
    snippet = normalize_text(row.get("snippet"))
    text = f"{title}. {snippet}"
    source = clean_source(row)
    src_cat, src_score, trusted, low_conf = source_category(source, cfg)
    fallback = normalize_text(row.get("searched_entity"))
    primary_entity, detected_entities = detect_primary_entity(text, cfg, fallback=fallback)
    entity_meta = cfg.get("entities", {}).get(primary_entity, {})
    aliases = entity_meta.get("aliases", [primary_entity])
    themes, risk_hits, context_hits, context_only = detect_themes(text, cfg, aliases)
                                                                                                                
    if re.search(r"\boverblown\b|built to handle|not the same ['’]freak out", text, flags=re.IGNORECASE):
        risk_hits = []
        themes = []
        context_only = bool(context_hits)
    claim_status, claim_hits = classify_claim_status(text, source, cfg)

                                                                                     
    base = 5.0
    base += min(40.0, 12.0 * len(themes))
    base += min(30.0, 6.0 * len(risk_hits))
    if "trusted" in claim_status.lower():
        base += 20.0
    elif "reported" in claim_status.lower():
        base += 12.0
    if primary_entity == "PayPal" and risk_hits:
        base += 8.0
    base += recency_points(row.get("published_at"), cfg.get("scoring", {}).get("recency_half_life_days", 30))
    base = min(base, 100.0)

    confidence = 20 + 10 * src_score
    if trusted:
        confidence += 15
    if "trusted" in claim_status.lower() or "official" in claim_status.lower():
        confidence += 15
    if context_only:
        confidence -= 15
    searched_only_tmp = bool(fallback in cfg.get("entities", {}) and not detected_entities)
    if searched_only_tmp:
        confidence -= 20
    if low_conf:
        confidence -= 20
    confidence = float(max(0, min(100, confidence)))

    exposure_index = float(entity_meta.get("exposure_index", 0.0))
    multiplier = bounded_exposure_multiplier(exposure_index, cfg)
                                                                      
    if base < 35 or context_only:
        multiplier = min(multiplier, 1.05)
    final_score = min(100.0, base * multiplier)
    band = risk_band(final_score, cfg)

    out = {
        "validation_id": normalize_text(row.get("validation_id")),
        "title": title,
        "url": normalize_text(row.get("url")),
        "source_name": source,
        "source_category": src_cat,
        "trusted_source": trusted,
        "published_at": normalize_text(row.get("published_at")),
        "searched_entity": fallback,
        "primary_entity": primary_entity,
        "detected_entities": ", ".join(detected_entities),
        "searched_entity_only": bool(fallback in cfg.get("entities", {}) and not detected_entities),
        "relationship_type": entity_meta.get("relationship_type", ""),
        "relationship_note": entity_meta.get("relationship_note", ""),
        "ticker": entity_meta.get("ticker", ""),
        "themes": ", ".join(themes),
        "risk_hits": ", ".join(risk_hits),
        "context_terms": ", ".join(context_hits),
        "context_only_signal": bool(context_only),
        "claim_status": claim_status,
        "claim_matches": ", ".join(claim_hits),
        "base_article_risk": round(base, 1),
        "confidence_score": round(confidence, 1),
        "confidence_label": "High" if confidence >= 75 else "Medium" if confidence >= 55 else "Low",
        "exposure_index": exposure_index,
        "exposure_multiplier": round(multiplier, 3),
        "initial_signal_score": round(final_score, 1),
        "initial_signal_band": band,
        "overall_priority_score": round(final_score, 1),
        "risk_band": band,                                              
        "final_escalation_marker": "Reference only",
        "hard_cap_applied": False,
        "source_cap_applied": False,
        "context_cap_applied": False,
        "entity_match_cap_applied": False,
        "review_bucket": "Reference items",
        "priority_item": False,
        "not_escalated_reason": "",
        "score_explanation": "",
        "so_what": "",
        "recommended_action": "",
        "snippet": snippet,
    }

                                      
    if priority_gate(out, cfg):
        out["priority_item"] = True
        out["review_bucket"] = "Priority items"
    elif final_score >= float(cfg.get("review_thresholds", {}).get("review_minimum_score", 40)) or risk_hits or (trusted and themes):
        out["review_bucket"] = "Review items"
    else:
        out["review_bucket"] = "Reference items"

    out = apply_hard_caps(out, cfg)

    if out["review_bucket"] != "Priority items" and not out["not_escalated_reason"]:
        reasons = []
        if not trusted:
            reasons.append("No trusted or official source confirmation.")
        if out["confidence_score"] < 60:
            reasons.append("Confidence is below the attention level.")
        if out["claim_status"] == "No serious claim detected":
            reasons.append("No serious claim status detected.")
        if out["overall_priority_score"] < cfg.get("priority_review_rules", {}).get("minimum_score", 65):
            reasons.append("Priority score is below the attention level.")
        out["not_escalated_reason"] = " ".join(reasons) or "Kept below the attention level by the review checks."

    out["score_explanation"] = (
        f"Base risk={out['base_article_risk']}; confidence={out['confidence_score']}; "
        f"exposure index={out['exposure_index']} with bounded multiplier={out['exposure_multiplier']}; "
        f"initial signal score={out['initial_signal_score']} ({out['initial_signal_band']}); "
        f"final placement={out['review_bucket']} after controls."
    )
    if out["review_bucket"] == "Priority items":
        out["so_what"] = (
            f"{primary_entity} has a trusted source adverse signal with {out['confidence_label']} confidence. "
            f"Themes: {out['themes'] or 'none'}. Claim status: {claim_status}. "
            f"PayPal relevance: {entity_meta.get('relationship_note', '')}"
        )
        out["recommended_action"] = "Confirm the source and review the claim before deciding on next steps."
    elif out["review_bucket"] == "Review items":
        out["so_what"] = (
            f"Potentially relevant signal for {primary_entity}. It does not meet the attention checks yet. "
            f"Reason: {out['not_escalated_reason']}"
        )
        out["recommended_action"] = "Track it and look for a second source, official source, internal signal, or market context."
    else:
        out["so_what"] = "Context or lower confidence row retained for reference."
        out["recommended_action"] = "No immediate action."
    return out


def score_articles(df: pd.DataFrame, cfg: Dict) -> pd.DataFrame:
       
    rows = []
    for _, r in df.iterrows():
        out = score_article(r, cfg)
        if "drop_reason" not in out:
            rows.append(out)
    return pd.DataFrame(rows)
