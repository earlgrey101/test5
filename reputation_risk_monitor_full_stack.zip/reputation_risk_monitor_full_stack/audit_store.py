from __future__ import annotations

import shutil
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

AUDIT_COLUMNS = [
    "event_id",
    "event_time_utc",
    "event_date_utc",
    "event_type",
    "area",
    "action",
    "actor_name",
    "actor_email",
    "ip_address",
    "session_id",
    "target_type",
    "target_id",
    "target_name",
    "detail",
    "old_value",
    "new_value",
    "status",
    "retention_until_utc",
]

RETENTION_COLUMNS = [
    "cleanup_time_utc",
    "retention_days",
    "audit_rows_deleted",
    "email_rows_deleted",
    "counterparty_change_rows_deleted",
    "cache_items_deleted",
    "status",
]

DEFAULT_RETENTION_DAYS = 120


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def utc_now_iso() -> str:
    return utc_now().isoformat()


def read_csv(path: Path, columns: list[str]) -> pd.DataFrame:
    if path.exists():
        df = pd.read_csv(path)
    else:
        df = pd.DataFrame(columns=columns)
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    df = df[columns + [c for c in df.columns if c not in columns]]
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].fillna("")
    return df


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def initialize_audit_files(data_dir: Path) -> None:
    audit_path = data_dir / "audit_log.csv"
    retention_path = data_dir / "retention_cleanup_log.csv"
    if not audit_path.exists():
        save_csv(pd.DataFrame(columns=AUDIT_COLUMNS), audit_path)
    if not retention_path.exists():
        save_csv(pd.DataFrame(columns=RETENTION_COLUMNS), retention_path)


def actor_value(actor: dict, key: str, default: str = "") -> str:
    value = actor.get(key, default) if isinstance(actor, dict) else default
    return str(value or default).strip()


def log_event(
    data_dir: Path,
    actor: dict | None,
    event_type: str,
    area: str,
    action: str,
    target_type: str = "",
    target_id: str = "",
    target_name: str = "",
    detail: str = "",
    old_value: str = "",
    new_value: str = "",
    status: str = "Completed",
    retention_days: int = DEFAULT_RETENTION_DAYS,
) -> str:
    initialize_audit_files(data_dir)
    event_time = utc_now()
    event_id = f"AUDIT_{uuid.uuid4().hex[:12].upper()}"
    retention_until = event_time + timedelta(days=int(retention_days))
    row = {
        "event_id": event_id,
        "event_time_utc": event_time.isoformat(),
        "event_date_utc": event_time.date().isoformat(),
        "event_type": str(event_type),
        "area": str(area),
        "action": str(action),
        "actor_name": actor_value(actor or {}, "actor_name", "Local user"),
        "actor_email": actor_value(actor or {}, "actor_email", ""),
        "ip_address": actor_value(actor or {}, "ip_address", "Unavailable locally"),
        "session_id": actor_value(actor or {}, "session_id", ""),
        "target_type": str(target_type),
        "target_id": str(target_id),
        "target_name": str(target_name),
        "detail": str(detail),
        "old_value": str(old_value),
        "new_value": str(new_value),
        "status": str(status),
        "retention_until_utc": retention_until.isoformat(),
    }
    path = data_dir / "audit_log.csv"
    df = read_csv(path, AUDIT_COLUMNS)
    df.loc[len(df)] = [row[col] for col in AUDIT_COLUMNS]
    save_csv(df, path)
    return event_id


def load_audit_log(data_dir: Path, lookback_days: int = DEFAULT_RETENTION_DAYS) -> pd.DataFrame:
    df = read_csv(data_dir / "audit_log.csv", AUDIT_COLUMNS)
    if df.empty:
        return df
    parsed = pd.to_datetime(df["event_time_utc"], errors="coerce", utc=True)
    cutoff = pd.Timestamp(utc_now() - timedelta(days=int(lookback_days)))
    return df[parsed >= cutoff].copy()


def retention_summary(data_dir: Path, retention_days: int = DEFAULT_RETENTION_DAYS) -> pd.DataFrame:
    audit = read_csv(data_dir / "audit_log.csv", AUDIT_COLUMNS)
    cleanup = read_csv(data_dir / "retention_cleanup_log.csv", RETENTION_COLUMNS)
    now = utc_now()
    oldest_allowed = now - timedelta(days=int(retention_days))
    rows = [
        {"item": "Retention period", "value": f"{retention_days} days", "meaning": "Audit and email activity before this window is removed."},
        {"item": "Oldest retained date", "value": oldest_allowed.date().isoformat(), "meaning": "Events before this UTC date are eligible for cleanup."},
        {"item": "Audit rows retained", "value": len(audit), "meaning": "Rows currently stored in audit_log.csv."},
        {"item": "Cleanup runs logged", "value": len(cleanup), "meaning": "How many retention cleanups have been recorded."},
    ]
    if not cleanup.empty:
        rows.append({"item": "Last cleanup", "value": str(cleanup.iloc[-1].get("cleanup_time_utc", "")), "meaning": "Most recent retention cleanup time in UTC."})
    else:
        rows.append({"item": "Last cleanup", "value": "Not yet run", "meaning": "Cleanup will run automatically once per app session and can be run manually."})
    return pd.DataFrame(rows)


def _filter_by_timestamp(path: Path, columns: list[str], timestamp_column: str, cutoff: pd.Timestamp) -> int:
    if not path.exists():
        return 0
    df = read_csv(path, columns)
    if df.empty or timestamp_column not in df.columns:
        return 0
    parsed = pd.to_datetime(df[timestamp_column], errors="coerce", utc=True)
    keep_mask = parsed.isna() | (parsed >= cutoff)
    removed = int((~keep_mask).sum())
    if removed:
        save_csv(df[keep_mask].copy(), path)
    return removed


def cleanup_cache_files(base_dir: Path, retention_days: int = DEFAULT_RETENTION_DAYS) -> int:
    cutoff_ts = (utc_now() - timedelta(days=int(retention_days))).timestamp()
    deleted = 0
    for folder_name in ["__pycache__", ".pytest_cache"]:
        for path in base_dir.rglob(folder_name):
            try:
                shutil.rmtree(path)
                deleted += 1
            except Exception:
                pass
    for path in [base_dir / ".streamlit" / "cache"]:
        if path.exists() and path.is_dir():
            for item in path.rglob("*"):
                try:
                    if item.is_file() and item.stat().st_mtime < cutoff_ts:
                        item.unlink()
                        deleted += 1
                except Exception:
                    pass
    return deleted


def purge_expired_records(data_dir: Path, retention_days: int = DEFAULT_RETENTION_DAYS, cleanup_cache: bool = True) -> dict:
    initialize_audit_files(data_dir)
    cutoff = pd.Timestamp(utc_now() - timedelta(days=int(retention_days)))
    audit_deleted = _filter_by_timestamp(data_dir / "audit_log.csv", AUDIT_COLUMNS, "event_time_utc", cutoff)
    email_deleted = _filter_by_timestamp(
        data_dir / "email_send_log.csv",
        ["sent_at", "mode", "sender_email", "recipient_count", "subject", "item_count", "status", "error"],
        "sent_at",
        cutoff,
    )
    cp_deleted = _filter_by_timestamp(
        data_dir / "counterparty_change_log.csv",
        ["changed_at", "action", "counterparty_id", "counterparty_name", "detail"],
        "changed_at",
        cutoff,
    )
    cache_deleted = cleanup_cache_files(data_dir.parent, retention_days) if cleanup_cache else 0
    cleanup_row = {
        "cleanup_time_utc": utc_now_iso(),
        "retention_days": int(retention_days),
        "audit_rows_deleted": audit_deleted,
        "email_rows_deleted": email_deleted,
        "counterparty_change_rows_deleted": cp_deleted,
        "cache_items_deleted": cache_deleted,
        "status": "Completed",
    }
    cleanup_path = data_dir / "retention_cleanup_log.csv"
    cleanup_df = read_csv(cleanup_path, RETENTION_COLUMNS)
    cleanup_df.loc[len(cleanup_df)] = [cleanup_row[col] for col in RETENTION_COLUMNS]
    save_csv(cleanup_df, cleanup_path)
    return cleanup_row


def load_retention_log(data_dir: Path) -> pd.DataFrame:
    return read_csv(data_dir / "retention_cleanup_log.csv", RETENTION_COLUMNS)
