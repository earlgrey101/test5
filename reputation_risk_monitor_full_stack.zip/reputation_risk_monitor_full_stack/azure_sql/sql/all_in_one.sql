SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ref') EXEC('CREATE SCHEMA ref');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ops') EXEC('CREATE SCHEMA ops');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'ingest') EXEC('CREATE SCHEMA ingest');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'risk') EXEC('CREATE SCHEMA risk');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'notify') EXEC('CREATE SCHEMA notify');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'audit') EXEC('CREATE SCHEMA audit');
GO

CREATE TABLE ref.Counterparty (
    counterparty_id varchar(20) NOT NULL CONSTRAINT PK_Counterparty PRIMARY KEY,
    source_number int NULL,
    legal_name nvarchar(300) NOT NULL,
    common_name nvarchar(300) NULL,
    ticker nvarchar(40) NULL,
    ticker_exchange_hint nvarchar(80) NULL,
    ticker_status nvarchar(100) NULL,
    counterparty_type nvarchar(150) NULL,
    country nvarchar(120) NULL,
    source_name_status nvarchar(80) NULL,
    importance_tier nvarchar(40) NULL,
    exposure_index decimal(9,4) NULL,
    relationship_owner nvarchar(200) NULL,
    notes nvarchar(1000) NULL,
    active_status varchar(20) NOT NULL CONSTRAINT DF_Counterparty_Active DEFAULT ('Active'),
    search_enabled bit NOT NULL CONSTRAINT DF_Counterparty_Search DEFAULT (1),
    match_risk_level varchar(20) NULL,
    alias_review_required bit NOT NULL CONSTRAINT DF_Counterparty_AliasReview DEFAULT (0),
    created_utc datetime2(3) NOT NULL CONSTRAINT DF_Counterparty_Created DEFAULT (SYSUTCDATETIME()),
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_Counterparty_Updated DEFAULT (SYSUTCDATETIME()),
    row_version rowversion,
    CONSTRAINT CK_Counterparty_Active CHECK (active_status IN ('Active','Inactive')),
    CONSTRAINT CK_Counterparty_Exposure CHECK (exposure_index IS NULL OR exposure_index >= 0)
);
GO

CREATE TABLE ref.CounterpartyAlias (
    alias_id varchar(30) NOT NULL CONSTRAINT PK_CounterpartyAlias PRIMARY KEY,
    counterparty_id varchar(20) NOT NULL,
    alias_text nvarchar(300) NOT NULL,
    alias_category nvarchar(80) NOT NULL,
    match_strength varchar(20) NOT NULL,
    requires_context bit NOT NULL CONSTRAINT DF_Alias_Context DEFAULT (0),
    dangerous_short_alias bit NOT NULL CONSTRAINT DF_Alias_Dangerous DEFAULT (0),
    active_status varchar(20) NOT NULL CONSTRAINT DF_Alias_Active DEFAULT ('Active'),
    review_status nvarchar(80) NULL,
    notes nvarchar(500) NULL,
    created_utc datetime2(3) NOT NULL CONSTRAINT DF_Alias_Created DEFAULT (SYSUTCDATETIME()),
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_Alias_Updated DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Alias_Counterparty FOREIGN KEY (counterparty_id) REFERENCES ref.Counterparty(counterparty_id),
    CONSTRAINT CK_Alias_Strength CHECK (match_strength IN ('Strong','Medium','Weak')),
    CONSTRAINT CK_Alias_Active CHECK (active_status IN ('Active','Inactive'))
);
GO

CREATE UNIQUE INDEX UX_Alias_Counterparty_Text
ON ref.CounterpartyAlias(counterparty_id, alias_text)
WHERE active_status = 'Active';
GO

CREATE INDEX IX_Alias_Search
ON ref.CounterpartyAlias(alias_text, active_status)
INCLUDE(counterparty_id, alias_category, match_strength, requires_context, dangerous_short_alias);
GO

CREATE TABLE ref.CounterpartyExclusion (
    exclusion_id varchar(30) NOT NULL CONSTRAINT PK_CounterpartyExclusion PRIMARY KEY,
    counterparty_id varchar(20) NOT NULL,
    alias_text nvarchar(300) NOT NULL,
    do_not_match_terms nvarchar(1000) NULL,
    require_context_terms nvarchar(1000) NULL,
    active_status varchar(20) NOT NULL CONSTRAINT DF_Exclusion_Active DEFAULT ('Active'),
    notes nvarchar(500) NULL,
    created_utc datetime2(3) NOT NULL CONSTRAINT DF_Exclusion_Created DEFAULT (SYSUTCDATETIME()),
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_Exclusion_Updated DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Exclusion_Counterparty FOREIGN KEY (counterparty_id) REFERENCES ref.Counterparty(counterparty_id),
    CONSTRAINT CK_Exclusion_Active CHECK (active_status IN ('Active','Inactive'))
);
GO

CREATE TABLE ref.RiskTheme (
    risk_theme_id smallint IDENTITY(1,1) NOT NULL CONSTRAINT PK_RiskTheme PRIMARY KEY,
    theme_code varchar(50) NOT NULL CONSTRAINT UQ_RiskTheme_Code UNIQUE,
    theme_name nvarchar(150) NOT NULL,
    description nvarchar(1000) NULL,
    active_status bit NOT NULL CONSTRAINT DF_RiskTheme_Active DEFAULT (1)
);
GO

CREATE TABLE ref.ClaimStrength (
    claim_strength_id tinyint NOT NULL CONSTRAINT PK_ClaimStrength PRIMARY KEY,
    claim_code varchar(50) NOT NULL CONSTRAINT UQ_ClaimStrength_Code UNIQUE,
    claim_name nvarchar(150) NOT NULL,
    strength_rank tinyint NOT NULL,
    description nvarchar(1000) NULL,
    active_status bit NOT NULL CONSTRAINT DF_ClaimStrength_Active DEFAULT (1),
    CONSTRAINT CK_ClaimStrength_Rank CHECK (strength_rank BETWEEN 1 AND 5)
);
GO

CREATE TABLE ref.SourceQuality (
    source_quality_id tinyint NOT NULL CONSTRAINT PK_SourceQuality PRIMARY KEY,
    quality_code varchar(30) NOT NULL CONSTRAINT UQ_SourceQuality_Code UNIQUE,
    quality_name nvarchar(100) NOT NULL,
    quality_rank tinyint NOT NULL,
    description nvarchar(1000) NULL,
    active_status bit NOT NULL CONSTRAINT DF_SourceQuality_Active DEFAULT (1),
    CONSTRAINT CK_SourceQuality_Rank CHECK (quality_rank BETWEEN 1 AND 5)
);
GO

CREATE TABLE ref.DashboardCategory (
    dashboard_category_id tinyint NOT NULL CONSTRAINT PK_DashboardCategory PRIMARY KEY,
    category_code varchar(30) NOT NULL CONSTRAINT UQ_DashboardCategory_Code UNIQUE,
    category_name nvarchar(100) NOT NULL,
    display_order tinyint NOT NULL,
    description nvarchar(1000) NULL
);
GO

CREATE TABLE ref.SourceDomain (
    source_domain_id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SourceDomain PRIMARY KEY,
    domain_name nvarchar(255) NOT NULL CONSTRAINT UQ_SourceDomain_Name UNIQUE,
    source_title nvarchar(300) NULL,
    source_quality_id tinyint NOT NULL,
    active_status bit NOT NULL CONSTRAINT DF_SourceDomain_Active DEFAULT (1),
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_SourceDomain_Updated DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_SourceDomain_Quality FOREIGN KEY (source_quality_id) REFERENCES ref.SourceQuality(source_quality_id)
);
GO

CREATE TABLE ops.SystemSetting (
    setting_key varchar(100) NOT NULL CONSTRAINT PK_SystemSetting PRIMARY KEY,
    setting_value nvarchar(1000) NOT NULL,
    value_type varchar(30) NOT NULL,
    description nvarchar(1000) NULL,
    updated_by nvarchar(320) NULL,
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_SystemSetting_Updated DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT CK_SystemSetting_Type CHECK (value_type IN ('BIT','INT','DECIMAL','STRING','JSON'))
);
GO

CREATE TABLE ops.RiskThreshold (
    threshold_key varchar(100) NOT NULL CONSTRAINT PK_RiskThreshold PRIMARY KEY,
    threshold_value decimal(18,6) NOT NULL,
    description nvarchar(1000) NULL,
    updated_by nvarchar(320) NULL,
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_RiskThreshold_Updated DEFAULT (SYSUTCDATETIME())
);
GO

CREATE TABLE ops.IngestionRun (
    run_id uniqueidentifier NOT NULL CONSTRAINT PK_IngestionRun PRIMARY KEY,
    run_mode varchar(20) NOT NULL,
    run_status varchar(30) NOT NULL,
    requested_by nvarchar(320) NOT NULL,
    request_ip nvarchar(64) NULL,
    request_session_id nvarchar(128) NULL,
    started_utc datetime2(3) NOT NULL,
    completed_utc datetime2(3) NULL,
    source_rows_collected int NOT NULL CONSTRAINT DF_Run_Collected DEFAULT (0),
    junk_rows_rejected int NOT NULL CONSTRAINT DF_Run_Junk DEFAULT (0),
    duplicate_url_rows int NOT NULL CONSTRAINT DF_Run_DupUrl DEFAULT (0),
    new_article_rows int NOT NULL CONSTRAINT DF_Run_NewArticle DEFAULT (0),
    existing_article_rows int NOT NULL CONSTRAINT DF_Run_ExistingArticle DEFAULT (0),
    new_story_rows int NOT NULL CONSTRAINT DF_Run_NewStory DEFAULT (0),
    article_rows_processed int NOT NULL CONSTRAINT DF_Run_Processed DEFAULT (0),
    match_rows_created int NOT NULL CONSTRAINT DF_Run_Matches DEFAULT (0),
    priority_items_created int NOT NULL CONSTRAINT DF_Run_Priority DEFAULT (0),
    review_items_created int NOT NULL CONSTRAINT DF_Run_Review DEFAULT (0),
    reference_items_created int NOT NULL CONSTRAINT DF_Run_Reference DEFAULT (0),
    error_message nvarchar(4000) NULL,
    CONSTRAINT CK_Run_Mode CHECK (run_mode IN ('MANUAL','AUTOMATED')),
    CONSTRAINT CK_Run_Status CHECK (run_status IN ('REQUESTED','COLLECTING','PROCESSING','COMPLETED','FAILED','CANCELLED'))
);
GO

CREATE INDEX IX_IngestionRun_StatusDate ON ops.IngestionRun(run_status, started_utc DESC);
GO

CREATE TABLE ops.RetentionCleanupRun (
    cleanup_run_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_RetentionCleanupRun PRIMARY KEY,
    started_utc datetime2(3) NOT NULL,
    completed_utc datetime2(3) NULL,
    raw_articles_deleted int NOT NULL CONSTRAINT DF_Cleanup_Raw DEFAULT (0),
    stories_deleted int NOT NULL CONSTRAINT DF_Cleanup_Stories DEFAULT (0),
    stage_rows_deleted int NOT NULL CONSTRAINT DF_Cleanup_Stage DEFAULT (0),
    rejection_rows_deleted int NOT NULL CONSTRAINT DF_Cleanup_Rejection DEFAULT (0),
    audit_rows_deleted int NOT NULL CONSTRAINT DF_Cleanup_Audit DEFAULT (0),
    refresh_runs_deleted int NOT NULL CONSTRAINT DF_Cleanup_Runs DEFAULT (0),
    status varchar(20) NOT NULL,
    error_message nvarchar(4000) NULL,
    CONSTRAINT CK_Cleanup_Status CHECK (status IN ('RUNNING','COMPLETED','FAILED'))
);
GO

CREATE TABLE ingest.ArticleStage (
    stage_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ArticleStage PRIMARY KEY,
    run_id uniqueidentifier NOT NULL,
    raw_url nvarchar(2048) NULL,
    canonical_url nvarchar(2048) NULL,
    external_story_id nvarchar(300) NULL,
    raw_title nvarchar(1000) NULL,
    raw_snippet nvarchar(4000) NULL,
    domain_name nvarchar(255) NULL,
    source_title nvarchar(300) NULL,
    feed_source nvarchar(100) NULL,
    source_query nvarchar(500) NULL,
    published_utc datetime2(3) NULL,
    collected_utc datetime2(3) NOT NULL CONSTRAINT DF_Stage_Collected DEFAULT (SYSUTCDATETIME()),
    processing_status varchar(30) NOT NULL CONSTRAINT DF_Stage_Status DEFAULT ('COLLECTED'),
    junk_reason_code varchar(100) NULL,
    duplicate_reason_code varchar(100) NULL,
    CONSTRAINT FK_Stage_Run FOREIGN KEY (run_id) REFERENCES ops.IngestionRun(run_id),
    CONSTRAINT CK_Stage_Status CHECK (processing_status IN ('COLLECTED','REJECTED_JUNK','DUPLICATE_URL','ACCEPTED','FAILED'))
);
GO

CREATE INDEX IX_Stage_RunStatus ON ingest.ArticleStage(run_id, processing_status);
GO

CREATE TABLE ingest.ArticleRejection (
    rejection_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ArticleRejection PRIMARY KEY,
    stage_id bigint NOT NULL,
    run_id uniqueidentifier NOT NULL,
    rejection_type varchar(30) NOT NULL,
    reason_code varchar(100) NOT NULL,
    reason_detail nvarchar(1000) NULL,
    rejected_utc datetime2(3) NOT NULL CONSTRAINT DF_Rejection_Time DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Rejection_Stage FOREIGN KEY (stage_id) REFERENCES ingest.ArticleStage(stage_id),
    CONSTRAINT FK_Rejection_Run FOREIGN KEY (run_id) REFERENCES ops.IngestionRun(run_id),
    CONSTRAINT CK_Rejection_Type CHECK (rejection_type IN ('JUNK','DUPLICATE_URL','PROCESSING_ERROR'))
);
GO

CREATE TABLE ingest.Story (
    story_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Story PRIMARY KEY,
    story_hash binary(32) NOT NULL,
    canonical_title nvarchar(1000) NOT NULL,
    external_story_id nvarchar(300) NULL,
    first_seen_utc datetime2(3) NOT NULL,
    last_seen_utc datetime2(3) NOT NULL,
    source_count int NOT NULL CONSTRAINT DF_Story_SourceCount DEFAULT (1),
    active_status bit NOT NULL CONSTRAINT DF_Story_Active DEFAULT (1)
);
GO

CREATE UNIQUE INDEX UX_Story_Hash ON ingest.Story(story_hash);
GO

CREATE TABLE ingest.Article (
    article_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Article PRIMARY KEY,
    story_id bigint NOT NULL,
    canonical_url nvarchar(2048) NOT NULL,
    canonical_url_hash binary(32) NOT NULL,
    title nvarchar(1000) NOT NULL,
    snippet nvarchar(4000) NULL,
    domain_name nvarchar(255) NULL,
    source_title nvarchar(300) NULL,
    feed_source nvarchar(100) NULL,
    source_query nvarchar(500) NULL,
    published_utc datetime2(3) NULL,
    first_seen_utc datetime2(3) NOT NULL,
    last_seen_utc datetime2(3) NOT NULL,
    first_seen_run_id uniqueidentifier NOT NULL,
    last_seen_run_id uniqueidentifier NOT NULL,
    source_quality_id tinyint NULL,
    active_status bit NOT NULL CONSTRAINT DF_Article_Active DEFAULT (1),
    CONSTRAINT FK_Article_Story FOREIGN KEY (story_id) REFERENCES ingest.Story(story_id),
    CONSTRAINT FK_Article_FirstRun FOREIGN KEY (first_seen_run_id) REFERENCES ops.IngestionRun(run_id),
    CONSTRAINT FK_Article_LastRun FOREIGN KEY (last_seen_run_id) REFERENCES ops.IngestionRun(run_id),
    CONSTRAINT FK_Article_SourceQuality FOREIGN KEY (source_quality_id) REFERENCES ref.SourceQuality(source_quality_id)
);
GO

CREATE UNIQUE INDEX UX_Article_UrlHash ON ingest.Article(canonical_url_hash);
CREATE INDEX IX_Article_ActiveDate ON ingest.Article(active_status, first_seen_utc DESC);
CREATE INDEX IX_Article_Story ON ingest.Article(story_id, first_seen_utc DESC);
GO

CREATE TABLE risk.ArticleCounterpartyMatch (
    match_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ArticleCounterpartyMatch PRIMARY KEY,
    article_id bigint NOT NULL,
    run_id uniqueidentifier NOT NULL,
    counterparty_id varchar(20) NOT NULL,
    alias_id varchar(30) NULL,
    alias_text nvarchar(300) NULL,
    match_method varchar(50) NOT NULL,
    entity_match_score decimal(9,4) NOT NULL,
    entity_match_band varchar(20) NOT NULL,
    evidence_text nvarchar(1000) NULL,
    token_distance int NULL,
    context_terms_found nvarchar(1000) NULL,
    exclusion_triggered bit NOT NULL CONSTRAINT DF_Match_Exclusion DEFAULT (0),
    exclusion_reason nvarchar(1000) NULL,
    human_review_required bit NOT NULL CONSTRAINT DF_Match_Review DEFAULT (0),
    model_version nvarchar(100) NOT NULL,
    processed_utc datetime2(3) NOT NULL CONSTRAINT DF_Match_Processed DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Match_Article FOREIGN KEY (article_id) REFERENCES ingest.Article(article_id) ON DELETE CASCADE,
    CONSTRAINT FK_Match_Run FOREIGN KEY (run_id) REFERENCES ops.IngestionRun(run_id),
    CONSTRAINT FK_Match_Counterparty FOREIGN KEY (counterparty_id) REFERENCES ref.Counterparty(counterparty_id),
    CONSTRAINT FK_Match_Alias FOREIGN KEY (alias_id) REFERENCES ref.CounterpartyAlias(alias_id),
    CONSTRAINT UQ_Match_ArticleCounterparty UNIQUE(article_id, counterparty_id),
    CONSTRAINT CK_Match_Score CHECK (entity_match_score BETWEEN 0 AND 100),
    CONSTRAINT CK_Match_Band CHECK (entity_match_band IN ('High','Medium','Low'))
);
GO

CREATE INDEX IX_Match_Run ON risk.ArticleCounterpartyMatch(run_id, counterparty_id);
CREATE INDEX IX_Match_Counterparty ON risk.ArticleCounterpartyMatch(counterparty_id, processed_utc DESC);
GO

CREATE TABLE risk.ArticleClassification (
    classification_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ArticleClassification PRIMARY KEY,
    match_id bigint NOT NULL CONSTRAINT UQ_Classification_Match UNIQUE,
    risk_theme_id smallint NOT NULL,
    theme_confidence_score decimal(9,4) NOT NULL,
    theme_evidence_text nvarchar(1000) NULL,
    claim_strength_id tinyint NOT NULL,
    claim_confidence_score decimal(9,4) NOT NULL,
    claim_evidence_text nvarchar(1000) NULL,
    risk_term_near_entity bit NOT NULL,
    is_context_only bit NOT NULL,
    classification_version nvarchar(100) NOT NULL,
    classified_utc datetime2(3) NOT NULL CONSTRAINT DF_Classification_Time DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Classification_Match FOREIGN KEY (match_id) REFERENCES risk.ArticleCounterpartyMatch(match_id) ON DELETE CASCADE,
    CONSTRAINT FK_Classification_Theme FOREIGN KEY (risk_theme_id) REFERENCES ref.RiskTheme(risk_theme_id),
    CONSTRAINT FK_Classification_Claim FOREIGN KEY (claim_strength_id) REFERENCES ref.ClaimStrength(claim_strength_id),
    CONSTRAINT CK_Theme_Confidence CHECK (theme_confidence_score BETWEEN 0 AND 100),
    CONSTRAINT CK_Claim_Confidence CHECK (claim_confidence_score BETWEEN 0 AND 100)
);
GO

CREATE TABLE risk.ArticleScore (
    score_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ArticleScore PRIMARY KEY,
    match_id bigint NOT NULL CONSTRAINT UQ_Score_Match UNIQUE,
    severity_score decimal(9,4) NOT NULL,
    confidence_score decimal(9,4) NOT NULL,
    source_quality_score decimal(9,4) NOT NULL,
    claim_strength_score decimal(9,4) NOT NULL,
    recency_multiplier decimal(9,6) NOT NULL,
    exposure_multiplier decimal(9,6) NOT NULL,
    raw_score decimal(9,4) NOT NULL,
    final_score decimal(9,4) NOT NULL,
    scoring_version nvarchar(100) NOT NULL,
    scored_utc datetime2(3) NOT NULL CONSTRAINT DF_Score_Time DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Score_Match FOREIGN KEY (match_id) REFERENCES risk.ArticleCounterpartyMatch(match_id) ON DELETE CASCADE,
    CONSTRAINT CK_Severity_Score CHECK (severity_score BETWEEN 0 AND 100),
    CONSTRAINT CK_Confidence_Score CHECK (confidence_score BETWEEN 0 AND 100),
    CONSTRAINT CK_Source_Score CHECK (source_quality_score BETWEEN 0 AND 100),
    CONSTRAINT CK_Claim_Score CHECK (claim_strength_score BETWEEN 0 AND 100),
    CONSTRAINT CK_Exposure_Multiplier CHECK (exposure_multiplier BETWEEN 1 AND 2),
    CONSTRAINT CK_Final_Score CHECK (final_score BETWEEN 0 AND 100)
);
GO

CREATE TABLE risk.GateDecision (
    gate_decision_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_GateDecision PRIMARY KEY,
    match_id bigint NOT NULL CONSTRAINT UQ_GateDecision_Match UNIQUE,
    passed_priority_score bit NOT NULL,
    passed_priority_confidence bit NOT NULL,
    passed_entity_match bit NOT NULL,
    passed_source_quality bit NOT NULL,
    passed_claim_strength bit NOT NULL,
    passed_proximity bit NOT NULL,
    passed_context_check bit NOT NULL,
    passed_exclusion_check bit NOT NULL,
    priority_eligible bit NOT NULL,
    final_category_id tinyint NOT NULL,
    reason_codes nvarchar(2000) NOT NULL,
    gate_version nvarchar(100) NOT NULL,
    decided_utc datetime2(3) NOT NULL CONSTRAINT DF_GateDecision_Time DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_GateDecision_Match FOREIGN KEY (match_id) REFERENCES risk.ArticleCounterpartyMatch(match_id) ON DELETE CASCADE,
    CONSTRAINT FK_GateDecision_Category FOREIGN KEY (final_category_id) REFERENCES ref.DashboardCategory(dashboard_category_id),
    CONSTRAINT CK_GateDecision_ReasonJson CHECK (ISJSON(reason_codes) = 1)
);
GO

CREATE TABLE risk.DashboardPlacement (
    placement_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DashboardPlacement PRIMARY KEY,
    match_id bigint NOT NULL CONSTRAINT UQ_DashboardPlacement_Match UNIQUE,
    dashboard_category_id tinyint NOT NULL,
    placement_status varchar(20) NOT NULL CONSTRAINT DF_Placement_Status DEFAULT ('Active'),
    placed_utc datetime2(3) NOT NULL CONSTRAINT DF_Placement_Time DEFAULT (SYSUTCDATETIME()),
    last_changed_utc datetime2(3) NOT NULL CONSTRAINT DF_Placement_Changed DEFAULT (SYSUTCDATETIME()),
    suppressed_until_utc datetime2(3) NULL,
    CONSTRAINT FK_Placement_Match FOREIGN KEY (match_id) REFERENCES risk.ArticleCounterpartyMatch(match_id) ON DELETE CASCADE,
    CONSTRAINT FK_Placement_Category FOREIGN KEY (dashboard_category_id) REFERENCES ref.DashboardCategory(dashboard_category_id),
    CONSTRAINT CK_Placement_Status CHECK (placement_status IN ('Active','Suppressed','Resolved'))
);
GO

CREATE INDEX IX_Placement_Category ON risk.DashboardPlacement(dashboard_category_id, placement_status, placed_utc DESC);
GO

CREATE TABLE notify.EmailRecipient (
    recipient_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_EmailRecipient PRIMARY KEY,
    display_name nvarchar(200) NOT NULL,
    email_address nvarchar(320) NOT NULL,
    active_status varchar(20) NOT NULL CONSTRAINT DF_EmailRecipient_Active DEFAULT ('Active'),
    added_by nvarchar(320) NOT NULL,
    added_utc datetime2(3) NOT NULL CONSTRAINT DF_EmailRecipient_Added DEFAULT (SYSUTCDATETIME()),
    removed_by nvarchar(320) NULL,
    removed_utc datetime2(3) NULL,
    CONSTRAINT UQ_EmailRecipient_Email UNIQUE(email_address),
    CONSTRAINT CK_EmailRecipient_Domain CHECK (LOWER(RIGHT(email_address, 11)) = '@paypal.com'),
    CONSTRAINT CK_EmailRecipient_Active CHECK (active_status IN ('Active','Inactive'))
);
GO

CREATE TABLE notify.EmailBatch (
    email_batch_id uniqueidentifier NOT NULL CONSTRAINT PK_EmailBatch PRIMARY KEY,
    run_id uniqueidentifier NULL,
    sender_email nvarchar(320) NULL,
    subject_line nvarchar(500) NOT NULL,
    batch_status varchar(30) NOT NULL,
    created_by nvarchar(320) NOT NULL,
    created_utc datetime2(3) NOT NULL CONSTRAINT DF_EmailBatch_Created DEFAULT (SYSUTCDATETIME()),
    sent_utc datetime2(3) NULL,
    error_message nvarchar(4000) NULL,
    CONSTRAINT FK_EmailBatch_Run FOREIGN KEY (run_id) REFERENCES ops.IngestionRun(run_id) ON DELETE SET NULL,
    CONSTRAINT CK_EmailBatch_Status CHECK (batch_status IN ('PREVIEW','QUEUED','SENT','FAILED','CANCELLED'))
);
GO

CREATE TABLE notify.EmailBatchRecipient (
    email_batch_id uniqueidentifier NOT NULL,
    recipient_id bigint NOT NULL,
    delivery_type varchar(10) NOT NULL CONSTRAINT DF_EmailBatchRecipient_Type DEFAULT ('BCC'),
    CONSTRAINT PK_EmailBatchRecipient PRIMARY KEY(email_batch_id, recipient_id),
    CONSTRAINT FK_EmailBatchRecipient_Batch FOREIGN KEY (email_batch_id) REFERENCES notify.EmailBatch(email_batch_id) ON DELETE CASCADE,
    CONSTRAINT FK_EmailBatchRecipient_Recipient FOREIGN KEY (recipient_id) REFERENCES notify.EmailRecipient(recipient_id),
    CONSTRAINT CK_EmailBatchRecipient_Type CHECK (delivery_type = 'BCC')
);
GO

CREATE TABLE notify.EmailBatchItem (
    email_batch_id uniqueidentifier NOT NULL,
    match_id bigint NOT NULL,
    CONSTRAINT PK_EmailBatchItem PRIMARY KEY(email_batch_id, match_id),
    CONSTRAINT FK_EmailBatchItem_Batch FOREIGN KEY (email_batch_id) REFERENCES notify.EmailBatch(email_batch_id) ON DELETE CASCADE,
    CONSTRAINT FK_EmailBatchItem_Match FOREIGN KEY (match_id) REFERENCES risk.ArticleCounterpartyMatch(match_id) ON DELETE CASCADE
);
GO

CREATE TABLE notify.EmailDeliveryLog (
    email_delivery_log_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_EmailDeliveryLog PRIMARY KEY,
    email_batch_id uniqueidentifier NOT NULL,
    provider_message_id nvarchar(500) NULL,
    delivery_status varchar(30) NOT NULL,
    attempted_utc datetime2(3) NOT NULL CONSTRAINT DF_EmailDelivery_Attempt DEFAULT (SYSUTCDATETIME()),
    error_message nvarchar(4000) NULL,
    CONSTRAINT FK_EmailDelivery_Batch FOREIGN KEY (email_batch_id) REFERENCES notify.EmailBatch(email_batch_id),
    CONSTRAINT CK_EmailDelivery_Status CHECK (delivery_status IN ('QUEUED','SENT','FAILED'))
);
GO

CREATE TABLE audit.Event (
    audit_event_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditEvent PRIMARY KEY,
    event_utc datetime2(3) NOT NULL CONSTRAINT DF_AuditEvent_Time DEFAULT (SYSUTCDATETIME()),
    actor_name nvarchar(200) NULL,
    actor_email nvarchar(320) NULL,
    actor_ip nvarchar(64) NULL,
    session_id nvarchar(128) NULL,
    event_type varchar(80) NOT NULL,
    entity_type varchar(80) NULL,
    entity_id nvarchar(200) NULL,
    action_name nvarchar(100) NOT NULL,
    old_values nvarchar(max) NULL,
    new_values nvarchar(max) NULL,
    run_id uniqueidentifier NULL,
    success_flag bit NOT NULL CONSTRAINT DF_AuditEvent_Success DEFAULT (1),
    error_message nvarchar(4000) NULL,
    CONSTRAINT FK_AuditEvent_Run FOREIGN KEY (run_id) REFERENCES ops.IngestionRun(run_id),
    CONSTRAINT CK_AuditEvent_OldJson CHECK (old_values IS NULL OR ISJSON(old_values) = 1),
    CONSTRAINT CK_AuditEvent_NewJson CHECK (new_values IS NULL OR ISJSON(new_values) = 1)
);
GO

CREATE INDEX IX_AuditEvent_Date ON audit.Event(event_utc DESC);
CREATE INDEX IX_AuditEvent_Actor ON audit.Event(actor_email, event_utc DESC);
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

MERGE ref.SourceQuality AS target
USING (VALUES
    (1,'UNKNOWN','Unknown',1,'Unclassified or insufficient source information'),
    (2,'LOWER','Lower quality',2,'Unknown, weak, or low-reliability source'),
    (3,'ESTABLISHED','Established',3,'Established publisher with normal review controls'),
    (4,'TRUSTED','Trusted',4,'Trusted major news or specialist source'),
    (5,'OFFICIAL','Official',5,'Regulator, court, government, or company filing source')
) AS source(source_quality_id,quality_code,quality_name,quality_rank,description)
ON target.source_quality_id = source.source_quality_id
WHEN MATCHED THEN UPDATE SET quality_code=source.quality_code, quality_name=source.quality_name, quality_rank=source.quality_rank, description=source.description
WHEN NOT MATCHED THEN INSERT(source_quality_id,quality_code,quality_name,quality_rank,description) VALUES(source.source_quality_id,source.quality_code,source.quality_name,source.quality_rank,source.description);
GO

MERGE ref.ClaimStrength AS target
USING (VALUES
    (1,'NO_SERIOUS_CLAIM','No serious claim detected',1,'Ordinary business context or no material allegation'),
    (2,'OPINION_OR_COMMENTARY','Opinion or commentary',2,'Analysis, opinion, commentary, or market discussion'),
    (3,'REPORTED_DEVELOPMENT','Reported legal or regulatory development',3,'A reported lawsuit, settlement, review, or regulatory development'),
    (4,'TRUSTED_REPORTED_INVESTIGATION','Trusted source reports investigation',4,'A trusted source reports a probe or serious allegation'),
    (5,'OFFICIAL_OR_CONFIRMED','Official or confirmed action',5,'Official filing, regulator, court action, or company confirmation')
) AS source(claim_strength_id,claim_code,claim_name,strength_rank,description)
ON target.claim_strength_id = source.claim_strength_id
WHEN MATCHED THEN UPDATE SET claim_code=source.claim_code, claim_name=source.claim_name, strength_rank=source.strength_rank, description=source.description
WHEN NOT MATCHED THEN INSERT(claim_strength_id,claim_code,claim_name,strength_rank,description) VALUES(source.claim_strength_id,source.claim_code,source.claim_name,source.strength_rank,source.description);
GO

MERGE ref.DashboardCategory AS target
USING (VALUES
    (1,'PRIORITY','Priority items',1,'Strong, well-supported items that meet the top review gates'),
    (2,'REVIEW','Review items',2,'Potentially relevant items that need additional review or confirmation'),
    (3,'REFERENCE','Reference items',3,'Background, low-confidence, context-only, or non-actionable items')
) AS source(dashboard_category_id,category_code,category_name,display_order,description)
ON target.dashboard_category_id = source.dashboard_category_id
WHEN MATCHED THEN UPDATE SET category_code=source.category_code, category_name=source.category_name, display_order=source.display_order, description=source.description
WHEN NOT MATCHED THEN INSERT(dashboard_category_id,category_code,category_name,display_order,description) VALUES(source.dashboard_category_id,source.category_code,source.category_name,source.display_order,source.description);
GO

MERGE ref.RiskTheme AS target
USING (VALUES
    ('REGULATORY_LEGAL','Regulatory or legal','Investigations, enforcement, litigation, settlements, or regulatory action'),
    ('FRAUD_MISCONDUCT','Fraud or misconduct','Fraud, deception, corruption, sanctions evasion, or misconduct'),
    ('CYBER_PRIVACY','Cyber or data privacy','Cyber incidents, data breach, privacy failures, or security compromise'),
    ('CREDIT_LIQUIDITY','Credit or liquidity stress','Default, downgrade, liquidity pressure, redemption pressure, funding stress, or bankruptcy'),
    ('OPERATIONS_PAYMENTS','Operational or payment disruption','Payment outage, settlement delay, processing failure, refund backlog, or operational disruption'),
    ('CONSUMER_TRUST','Consumer trust','Consumer harm, complaints, public backlash, or trust erosion'),
    ('SANCTIONS_GEOPOLITICAL','Sanctions or geopolitical','Sanctions, export controls, conflict exposure, or geopolitical restrictions'),
    ('ORDINARY_CONTEXT','Ordinary business context','Routine business news without an adverse risk signal')
) AS source(theme_code,theme_name,description)
ON target.theme_code = source.theme_code
WHEN MATCHED THEN UPDATE SET theme_name=source.theme_name, description=source.description, active_status=1
WHEN NOT MATCHED THEN INSERT(theme_code,theme_name,description) VALUES(source.theme_code,source.theme_name,source.description);
GO

MERGE ops.SystemSetting AS target
USING (VALUES
    ('MANUAL_REFRESH_ENABLED','1','BIT','Allow a user-initiated refresh from the dashboard'),
    ('AUTO_SCRAPE_APPROVED','0','BIT','Automatic article collection is blocked unless this is explicitly approved'),
    ('RAW_ARTICLE_RETENTION_DAYS','120','INT','Number of days accepted article rows are retained'),
    ('DERIVED_RESULT_RETENTION_DAYS','120','INT','Number of days matches, classifications, scores, gates, and placements are retained'),
    ('STAGE_REJECTION_RETENTION_DAYS','30','INT','Number of days staging and rejected rows are retained'),
    ('AUDIT_RETENTION_DAYS','120','INT','Number of days application audit rows are retained'),
    ('REFRESH_RUN_RETENTION_DAYS','365','INT','Number of days refresh summaries are retained'),
    ('EMAIL_ENABLED','0','BIT','Email sending remains disabled until sender and approved delivery method are configured'),
    ('GENERAL_SENDER_EMAIL','TBD','STRING','General sender address used for Priority item emails')
) AS source(setting_key,setting_value,value_type,description)
ON target.setting_key = source.setting_key
WHEN MATCHED THEN UPDATE SET setting_value=source.setting_value, value_type=source.value_type, description=source.description
WHEN NOT MATCHED THEN INSERT(setting_key,setting_value,value_type,description) VALUES(source.setting_key,source.setting_value,source.value_type,source.description);
GO

MERGE ops.RiskThreshold AS target
USING (VALUES
    ('PRIORITY_SCORE_MIN',60.0,'Minimum final score for Priority eligibility'),
    ('PRIORITY_CONFIDENCE_MIN',60.0,'Minimum article confidence for Priority eligibility'),
    ('PRIORITY_ENTITY_MATCH_MIN',80.0,'Minimum entity-match confidence for Priority eligibility'),
    ('PRIORITY_SOURCE_QUALITY_RANK_MIN',4.0,'Minimum source-quality rank for Priority eligibility'),
    ('PRIORITY_CLAIM_STRENGTH_RANK_MIN',3.0,'Minimum claim-strength rank for Priority eligibility'),
    ('REVIEW_SCORE_MIN',40.0,'Minimum final score for Review placement'),
    ('REVIEW_ENTITY_MATCH_MIN',50.0,'Minimum entity-match confidence for Review placement'),
    ('RISK_TERM_DISTANCE_MAX',12.0,'Maximum token distance used by the matching/classification layer'),
    ('EXPOSURE_MULTIPLIER_MAX',1.30,'Maximum allowed exposure multiplier')
) AS source(threshold_key,threshold_value,description)
ON target.threshold_key = source.threshold_key
WHEN MATCHED THEN UPDATE SET threshold_value=source.threshold_value, description=source.description
WHEN NOT MATCHED THEN INSERT(threshold_key,threshold_value,description) VALUES(source.threshold_key,source.threshold_value,source.description);
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

CREATE OR ALTER PROCEDURE audit.sp_SetSessionActor
    @actor_name nvarchar(200) = NULL,
    @actor_email nvarchar(320) = NULL,
    @actor_ip nvarchar(64) = NULL,
    @session_id nvarchar(128) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    EXEC sys.sp_set_session_context @key=N'actor_name', @value=@actor_name;
    EXEC sys.sp_set_session_context @key=N'actor_email', @value=@actor_email;
    EXEC sys.sp_set_session_context @key=N'actor_ip', @value=@actor_ip;
    EXEC sys.sp_set_session_context @key=N'session_id', @value=@session_id;
END;
GO

CREATE OR ALTER PROCEDURE audit.sp_LogEvent
    @event_type varchar(80),
    @entity_type varchar(80) = NULL,
    @entity_id nvarchar(200) = NULL,
    @action_name nvarchar(100),
    @old_values nvarchar(max) = NULL,
    @new_values nvarchar(max) = NULL,
    @run_id uniqueidentifier = NULL,
    @success_flag bit = 1,
    @error_message nvarchar(4000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.Event(
        actor_name, actor_email, actor_ip, session_id,
        event_type, entity_type, entity_id, action_name,
        old_values, new_values, run_id, success_flag, error_message
    )
    VALUES(
        CONVERT(nvarchar(200),SESSION_CONTEXT(N'actor_name')),
        CONVERT(nvarchar(320),SESSION_CONTEXT(N'actor_email')),
        CONVERT(nvarchar(64),SESSION_CONTEXT(N'actor_ip')),
        CONVERT(nvarchar(128),SESSION_CONTEXT(N'session_id')),
        @event_type,@entity_type,@entity_id,@action_name,
        @old_values,@new_values,@run_id,@success_flag,@error_message
    );
END;
GO

CREATE OR ALTER PROCEDURE ops.sp_StartIngestionRun
    @run_mode varchar(20),
    @requested_by nvarchar(320),
    @request_ip nvarchar(64) = NULL,
    @request_session_id nvarchar(128) = NULL,
    @run_id uniqueidentifier OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @manual_enabled bit = TRY_CONVERT(bit,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='MANUAL_REFRESH_ENABLED'));
    DECLARE @auto_approved bit = TRY_CONVERT(bit,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='AUTO_SCRAPE_APPROVED'));

    IF @run_mode NOT IN ('MANUAL','AUTOMATED') THROW 50001, 'Invalid run mode.', 1;
    IF @run_mode='MANUAL' AND ISNULL(@manual_enabled,0)=0 THROW 50002, 'Manual refresh is disabled.', 1;
    IF @run_mode='AUTOMATED' AND ISNULL(@auto_approved,0)=0 THROW 50003, 'Automatic scraping is not approved.', 1;
    IF EXISTS (SELECT 1 FROM ops.IngestionRun WHERE run_status IN ('REQUESTED','COLLECTING','PROCESSING'))
        THROW 50004, 'Another refresh is already running.', 1;

    SET @run_id = NEWID();

    INSERT ops.IngestionRun(run_id,run_mode,run_status,requested_by,request_ip,request_session_id,started_utc)
    VALUES(@run_id,@run_mode,'REQUESTED',@requested_by,@request_ip,@request_session_id,SYSUTCDATETIME());

    EXEC audit.sp_LogEvent
        @event_type='REFRESH',
        @entity_type='INGESTION_RUN',
        @entity_id=CONVERT(nvarchar(36),@run_id),
        @action_name='START_REFRESH',
        @run_id=@run_id;
END;
GO

CREATE OR ALTER PROCEDURE ops.sp_UpdateRunStatus
    @run_id uniqueidentifier,
    @run_status varchar(30),
    @error_message nvarchar(4000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE ops.IngestionRun
    SET run_status=@run_status,
        error_message=@error_message,
        completed_utc=CASE WHEN @run_status IN ('COMPLETED','FAILED','CANCELLED') THEN SYSUTCDATETIME() ELSE completed_utc END
    WHERE run_id=@run_id;
END;
GO

CREATE OR ALTER PROCEDURE ingest.sp_AddStageArticle
    @run_id uniqueidentifier,
    @raw_url nvarchar(2048),
    @canonical_url nvarchar(2048),
    @external_story_id nvarchar(300),
    @raw_title nvarchar(1000),
    @raw_snippet nvarchar(4000),
    @domain_name nvarchar(255),
    @source_title nvarchar(300),
    @feed_source nvarchar(100),
    @source_query nvarchar(500),
    @published_utc datetime2(3),
    @stage_id bigint OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT ingest.ArticleStage(
        run_id,raw_url,canonical_url,external_story_id,raw_title,raw_snippet,
        domain_name,source_title,feed_source,source_query,published_utc
    )
    VALUES(
        @run_id,@raw_url,@canonical_url,@external_story_id,@raw_title,@raw_snippet,
        @domain_name,@source_title,@feed_source,@source_query,@published_utc
    );
    SET @stage_id=SCOPE_IDENTITY();
END;
GO

CREATE OR ALTER PROCEDURE ingest.sp_RejectStageArticle
    @stage_id bigint,
    @run_id uniqueidentifier,
    @rejection_type varchar(30),
    @reason_code varchar(100),
    @reason_detail nvarchar(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE ingest.ArticleStage
    SET processing_status=CASE WHEN @rejection_type='JUNK' THEN 'REJECTED_JUNK' WHEN @rejection_type='DUPLICATE_URL' THEN 'DUPLICATE_URL' ELSE 'FAILED' END,
        junk_reason_code=CASE WHEN @rejection_type='JUNK' THEN @reason_code ELSE junk_reason_code END,
        duplicate_reason_code=CASE WHEN @rejection_type='DUPLICATE_URL' THEN @reason_code ELSE duplicate_reason_code END
    WHERE stage_id=@stage_id AND run_id=@run_id;

    INSERT ingest.ArticleRejection(stage_id,run_id,rejection_type,reason_code,reason_detail)
    VALUES(@stage_id,@run_id,@rejection_type,@reason_code,@reason_detail);
END;
GO

CREATE OR ALTER PROCEDURE ingest.sp_UpsertAcceptedArticle
    @stage_id bigint,
    @run_id uniqueidentifier,
    @canonical_url nvarchar(2048),
    @story_key nvarchar(1000),
    @external_story_id nvarchar(300),
    @title nvarchar(1000),
    @snippet nvarchar(4000),
    @domain_name nvarchar(255),
    @source_title nvarchar(300),
    @feed_source nvarchar(100),
    @source_query nvarchar(500),
    @published_utc datetime2(3),
    @source_quality_id tinyint = NULL,
    @article_id bigint OUTPUT,
    @story_id bigint OUTPUT,
    @result_code varchar(30) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @url_hash binary(32)=HASHBYTES('SHA2_256',LOWER(CONVERT(varchar(8000),@canonical_url)));
    DECLARE @story_hash binary(32)=HASHBYTES('SHA2_256',LOWER(CONVERT(varchar(8000),@story_key)));
    DECLARE @now datetime2(3)=SYSUTCDATETIME();

    BEGIN TRANSACTION;

    SELECT @story_id=story_id FROM ingest.Story WITH (UPDLOCK,HOLDLOCK) WHERE story_hash=@story_hash;
    IF @story_id IS NULL
    BEGIN
        INSERT ingest.Story(story_hash,canonical_title,external_story_id,first_seen_utc,last_seen_utc,source_count)
        VALUES(@story_hash,@title,@external_story_id,@now,@now,1);
        SET @story_id=SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE ingest.Story SET last_seen_utc=@now WHERE story_id=@story_id;
    END

    SELECT @article_id=article_id FROM ingest.Article WITH (UPDLOCK,HOLDLOCK) WHERE canonical_url_hash=@url_hash;
    IF @article_id IS NULL
    BEGIN
        INSERT ingest.Article(
            story_id,canonical_url,canonical_url_hash,title,snippet,domain_name,source_title,
            feed_source,source_query,published_utc,first_seen_utc,last_seen_utc,
            first_seen_run_id,last_seen_run_id,source_quality_id
        )
        VALUES(
            @story_id,@canonical_url,@url_hash,@title,@snippet,@domain_name,@source_title,
            @feed_source,@source_query,@published_utc,@now,@now,@run_id,@run_id,@source_quality_id
        );
        SET @article_id=SCOPE_IDENTITY();
        SET @result_code=CASE WHEN (SELECT COUNT(*) FROM ingest.Article WHERE story_id=@story_id)=1 THEN 'NEW_ARTICLE_NEW_STORY' ELSE 'NEW_ARTICLE_EXISTING_STORY' END;
        UPDATE ingest.Story
        SET source_count=(SELECT COUNT(*) FROM ingest.Article WHERE story_id=@story_id)
        WHERE story_id=@story_id;
    END
    ELSE
    BEGIN
        UPDATE ingest.Article
        SET last_seen_utc=@now,last_seen_run_id=@run_id,active_status=1
        WHERE article_id=@article_id;
        SET @result_code='EXISTING_URL';
    END

    UPDATE ingest.ArticleStage SET processing_status='ACCEPTED' WHERE stage_id=@stage_id;
    COMMIT TRANSACTION;
END;
GO

CREATE OR ALTER PROCEDURE risk.sp_SaveMatch
    @article_id bigint,
    @run_id uniqueidentifier,
    @counterparty_id varchar(20),
    @alias_id varchar(30) = NULL,
    @alias_text nvarchar(300) = NULL,
    @match_method varchar(50),
    @entity_match_score decimal(9,4),
    @entity_match_band varchar(20),
    @evidence_text nvarchar(1000) = NULL,
    @token_distance int = NULL,
    @context_terms_found nvarchar(1000) = NULL,
    @exclusion_triggered bit = 0,
    @exclusion_reason nvarchar(1000) = NULL,
    @human_review_required bit = 0,
    @model_version nvarchar(100),
    @match_id bigint OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    MERGE risk.ArticleCounterpartyMatch AS target
    USING (SELECT @article_id article_id,@counterparty_id counterparty_id) AS source
    ON target.article_id=source.article_id AND target.counterparty_id=source.counterparty_id
    WHEN MATCHED THEN UPDATE SET
        run_id=@run_id,alias_id=@alias_id,alias_text=@alias_text,match_method=@match_method,
        entity_match_score=@entity_match_score,entity_match_band=@entity_match_band,
        evidence_text=@evidence_text,token_distance=@token_distance,context_terms_found=@context_terms_found,
        exclusion_triggered=@exclusion_triggered,exclusion_reason=@exclusion_reason,
        human_review_required=@human_review_required,model_version=@model_version,processed_utc=SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT(
        article_id,run_id,counterparty_id,alias_id,alias_text,match_method,entity_match_score,
        entity_match_band,evidence_text,token_distance,context_terms_found,exclusion_triggered,
        exclusion_reason,human_review_required,model_version
    ) VALUES(
        @article_id,@run_id,@counterparty_id,@alias_id,@alias_text,@match_method,@entity_match_score,
        @entity_match_band,@evidence_text,@token_distance,@context_terms_found,@exclusion_triggered,
        @exclusion_reason,@human_review_required,@model_version
    );
    SELECT @match_id=match_id FROM risk.ArticleCounterpartyMatch WHERE article_id=@article_id AND counterparty_id=@counterparty_id;
END;
GO

CREATE OR ALTER PROCEDURE risk.sp_SaveClassificationAndScore
    @match_id bigint,
    @risk_theme_code varchar(50),
    @theme_confidence_score decimal(9,4),
    @theme_evidence_text nvarchar(1000),
    @claim_code varchar(50),
    @claim_confidence_score decimal(9,4),
    @claim_evidence_text nvarchar(1000),
    @risk_term_near_entity bit,
    @is_context_only bit,
    @classification_version nvarchar(100),
    @severity_score decimal(9,4),
    @confidence_score decimal(9,4),
    @source_quality_score decimal(9,4),
    @claim_strength_score decimal(9,4),
    @recency_multiplier decimal(9,6),
    @exposure_multiplier decimal(9,6),
    @raw_score decimal(9,4),
    @final_score decimal(9,4),
    @scoring_version nvarchar(100)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @risk_theme_id smallint=(SELECT risk_theme_id FROM ref.RiskTheme WHERE theme_code=@risk_theme_code AND active_status=1);
    DECLARE @claim_strength_id tinyint=(SELECT claim_strength_id FROM ref.ClaimStrength WHERE claim_code=@claim_code AND active_status=1);
    IF @risk_theme_id IS NULL THROW 50010,'Unknown risk theme code.',1;
    IF @claim_strength_id IS NULL THROW 50011,'Unknown claim code.',1;

    MERGE risk.ArticleClassification AS target
    USING (SELECT @match_id match_id) AS source
    ON target.match_id=source.match_id
    WHEN MATCHED THEN UPDATE SET
        risk_theme_id=@risk_theme_id,theme_confidence_score=@theme_confidence_score,
        theme_evidence_text=@theme_evidence_text,claim_strength_id=@claim_strength_id,
        claim_confidence_score=@claim_confidence_score,claim_evidence_text=@claim_evidence_text,
        risk_term_near_entity=@risk_term_near_entity,is_context_only=@is_context_only,
        classification_version=@classification_version,classified_utc=SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT(
        match_id,risk_theme_id,theme_confidence_score,theme_evidence_text,claim_strength_id,
        claim_confidence_score,claim_evidence_text,risk_term_near_entity,is_context_only,classification_version
    ) VALUES(
        @match_id,@risk_theme_id,@theme_confidence_score,@theme_evidence_text,@claim_strength_id,
        @claim_confidence_score,@claim_evidence_text,@risk_term_near_entity,@is_context_only,@classification_version
    );

    MERGE risk.ArticleScore AS target
    USING (SELECT @match_id match_id) AS source
    ON target.match_id=source.match_id
    WHEN MATCHED THEN UPDATE SET
        severity_score=@severity_score,confidence_score=@confidence_score,source_quality_score=@source_quality_score,
        claim_strength_score=@claim_strength_score,recency_multiplier=@recency_multiplier,
        exposure_multiplier=@exposure_multiplier,raw_score=@raw_score,final_score=@final_score,
        scoring_version=@scoring_version,scored_utc=SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT(
        match_id,severity_score,confidence_score,source_quality_score,claim_strength_score,
        recency_multiplier,exposure_multiplier,raw_score,final_score,scoring_version
    ) VALUES(
        @match_id,@severity_score,@confidence_score,@source_quality_score,@claim_strength_score,
        @recency_multiplier,@exposure_multiplier,@raw_score,@final_score,@scoring_version
    );
END;
GO

CREATE OR ALTER PROCEDURE risk.sp_ApplyHardGatesForRun
    @run_id uniqueidentifier,
    @gate_version nvarchar(100)='gate-v1'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @priority_score decimal(18,6)=(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='PRIORITY_SCORE_MIN');
    DECLARE @priority_conf decimal(18,6)=(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='PRIORITY_CONFIDENCE_MIN');
    DECLARE @priority_match decimal(18,6)=(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='PRIORITY_ENTITY_MATCH_MIN');
    DECLARE @priority_source_rank int=CONVERT(int,(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='PRIORITY_SOURCE_QUALITY_RANK_MIN'));
    DECLARE @priority_claim_rank int=CONVERT(int,(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='PRIORITY_CLAIM_STRENGTH_RANK_MIN'));
    DECLARE @review_score decimal(18,6)=(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='REVIEW_SCORE_MIN');
    DECLARE @review_match decimal(18,6)=(SELECT threshold_value FROM ops.RiskThreshold WHERE threshold_key='REVIEW_ENTITY_MATCH_MIN');

    ;WITH base AS (
        SELECT
            m.match_id,
            s.final_score,
            s.confidence_score,
            m.entity_match_score,
            ISNULL(sq.quality_rank,1) source_rank,
            cs.strength_rank claim_rank,
            c.risk_term_near_entity,
            c.is_context_only,
            m.exclusion_triggered,
            CASE WHEN s.final_score>=@priority_score THEN 1 ELSE 0 END passed_priority_score,
            CASE WHEN s.confidence_score>=@priority_conf THEN 1 ELSE 0 END passed_priority_confidence,
            CASE WHEN m.entity_match_score>=@priority_match THEN 1 ELSE 0 END passed_entity_match,
            CASE WHEN ISNULL(sq.quality_rank,1)>=@priority_source_rank THEN 1 ELSE 0 END passed_source_quality,
            CASE WHEN cs.strength_rank>=@priority_claim_rank THEN 1 ELSE 0 END passed_claim_strength,
            CASE WHEN c.risk_term_near_entity=1 THEN 1 ELSE 0 END passed_proximity,
            CASE WHEN c.is_context_only=0 THEN 1 ELSE 0 END passed_context_check,
            CASE WHEN m.exclusion_triggered=0 THEN 1 ELSE 0 END passed_exclusion_check
        FROM risk.ArticleCounterpartyMatch m
        JOIN risk.ArticleClassification c ON c.match_id=m.match_id
        JOIN risk.ArticleScore s ON s.match_id=m.match_id
        JOIN ingest.Article a ON a.article_id=m.article_id
        LEFT JOIN ref.SourceQuality sq ON sq.source_quality_id=a.source_quality_id
        JOIN ref.ClaimStrength cs ON cs.claim_strength_id=c.claim_strength_id
        WHERE m.run_id=@run_id
    ), decided AS (
        SELECT *,
            CASE WHEN passed_priority_score=1 AND passed_priority_confidence=1 AND passed_entity_match=1
                      AND passed_source_quality=1 AND passed_claim_strength=1 AND passed_proximity=1
                      AND passed_context_check=1 AND passed_exclusion_check=1
                 THEN 1 ELSE 0 END priority_eligible,
            CASE
                WHEN passed_priority_score=1 AND passed_priority_confidence=1 AND passed_entity_match=1
                     AND passed_source_quality=1 AND passed_claim_strength=1 AND passed_proximity=1
                     AND passed_context_check=1 AND passed_exclusion_check=1 THEN 1
                WHEN final_score>=@review_score AND entity_match_score>=@review_match AND passed_exclusion_check=1 THEN 2
                ELSE 3
            END final_category_id
        FROM base
    )
    MERGE risk.GateDecision AS target
    USING (
        SELECT *,
            (SELECT
                CASE WHEN passed_priority_score=0 THEN 'SCORE_BELOW_PRIORITY' END score_reason,
                CASE WHEN passed_priority_confidence=0 THEN 'CONFIDENCE_BELOW_PRIORITY' END confidence_reason,
                CASE WHEN passed_entity_match=0 THEN 'ENTITY_MATCH_BELOW_PRIORITY' END match_reason,
                CASE WHEN passed_source_quality=0 THEN 'SOURCE_BELOW_PRIORITY' END source_reason,
                CASE WHEN passed_claim_strength=0 THEN 'CLAIM_BELOW_PRIORITY' END claim_reason,
                CASE WHEN passed_proximity=0 THEN 'RISK_TERM_NOT_NEAR_ENTITY' END proximity_reason,
                CASE WHEN passed_context_check=0 THEN 'CONTEXT_ONLY' END context_reason,
                CASE WHEN passed_exclusion_check=0 THEN 'EXCLUSION_TRIGGERED' END exclusion_reason
             FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) reason_codes
        FROM decided
    ) AS source
    ON target.match_id=source.match_id
    WHEN MATCHED THEN UPDATE SET
        passed_priority_score=source.passed_priority_score,
        passed_priority_confidence=source.passed_priority_confidence,
        passed_entity_match=source.passed_entity_match,
        passed_source_quality=source.passed_source_quality,
        passed_claim_strength=source.passed_claim_strength,
        passed_proximity=source.passed_proximity,
        passed_context_check=source.passed_context_check,
        passed_exclusion_check=source.passed_exclusion_check,
        priority_eligible=source.priority_eligible,
        final_category_id=source.final_category_id,
        reason_codes=source.reason_codes,
        gate_version=@gate_version,
        decided_utc=SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT(
        match_id,passed_priority_score,passed_priority_confidence,passed_entity_match,
        passed_source_quality,passed_claim_strength,passed_proximity,passed_context_check,
        passed_exclusion_check,priority_eligible,final_category_id,reason_codes,gate_version
    ) VALUES(
        source.match_id,source.passed_priority_score,source.passed_priority_confidence,source.passed_entity_match,
        source.passed_source_quality,source.passed_claim_strength,source.passed_proximity,source.passed_context_check,
        source.passed_exclusion_check,source.priority_eligible,source.final_category_id,source.reason_codes,@gate_version
    );

    MERGE risk.DashboardPlacement AS target
    USING (
        SELECT gd.match_id,gd.final_category_id
        FROM risk.GateDecision gd
        JOIN risk.ArticleCounterpartyMatch m ON m.match_id=gd.match_id
        WHERE m.run_id=@run_id
    ) AS source
    ON target.match_id=source.match_id
    WHEN MATCHED THEN UPDATE SET dashboard_category_id=source.final_category_id,placement_status='Active',last_changed_utc=SYSUTCDATETIME()
    WHEN NOT MATCHED THEN INSERT(match_id,dashboard_category_id) VALUES(source.match_id,source.final_category_id);
END;
GO

CREATE OR ALTER PROCEDURE ops.sp_CompleteIngestionRun
    @run_id uniqueidentifier,
    @source_rows_collected int,
    @junk_rows_rejected int,
    @duplicate_url_rows int,
    @new_article_rows int,
    @existing_article_rows int,
    @new_story_rows int,
    @article_rows_processed int,
    @match_rows_created int
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @priority int=(SELECT COUNT(*) FROM risk.ArticleCounterpartyMatch m JOIN risk.DashboardPlacement p ON p.match_id=m.match_id WHERE m.run_id=@run_id AND p.dashboard_category_id=1);
    DECLARE @review int=(SELECT COUNT(*) FROM risk.ArticleCounterpartyMatch m JOIN risk.DashboardPlacement p ON p.match_id=m.match_id WHERE m.run_id=@run_id AND p.dashboard_category_id=2);
    DECLARE @reference int=(SELECT COUNT(*) FROM risk.ArticleCounterpartyMatch m JOIN risk.DashboardPlacement p ON p.match_id=m.match_id WHERE m.run_id=@run_id AND p.dashboard_category_id=3);

    UPDATE ops.IngestionRun
    SET run_status='COMPLETED',completed_utc=SYSUTCDATETIME(),
        source_rows_collected=@source_rows_collected,junk_rows_rejected=@junk_rows_rejected,
        duplicate_url_rows=@duplicate_url_rows,new_article_rows=@new_article_rows,
        existing_article_rows=@existing_article_rows,new_story_rows=@new_story_rows,
        article_rows_processed=@article_rows_processed,match_rows_created=@match_rows_created,
        priority_items_created=@priority,review_items_created=@review,reference_items_created=@reference
    WHERE run_id=@run_id;

    EXEC audit.sp_LogEvent
        @event_type='REFRESH',@entity_type='INGESTION_RUN',@entity_id=CONVERT(nvarchar(36),@run_id),
        @action_name='COMPLETE_REFRESH',@run_id=@run_id;
END;
GO

CREATE OR ALTER PROCEDURE ops.sp_PurgeExpiredData
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @cleanup_id bigint;
    DECLARE @raw_days int=TRY_CONVERT(int,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='RAW_ARTICLE_RETENTION_DAYS'));
    DECLARE @stage_days int=TRY_CONVERT(int,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='STAGE_REJECTION_RETENTION_DAYS'));
    DECLARE @audit_days int=TRY_CONVERT(int,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='AUDIT_RETENTION_DAYS'));
    DECLARE @run_days int=TRY_CONVERT(int,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='REFRESH_RUN_RETENTION_DAYS'));
    DECLARE @raw_deleted int=0,@stories_deleted int=0,@stage_deleted int=0,@rejections_deleted int=0,@audit_deleted int=0,@runs_deleted int=0;

    INSERT ops.RetentionCleanupRun(started_utc,status) VALUES(SYSUTCDATETIME(),'RUNNING');
    SET @cleanup_id=SCOPE_IDENTITY();

    BEGIN TRY
        BEGIN TRANSACTION;

        DELETE FROM ingest.Article WHERE last_seen_utc<DATEADD(day,-ISNULL(@raw_days,120),SYSUTCDATETIME());
        SET @raw_deleted=@@ROWCOUNT;

        DELETE FROM ingest.Story WHERE NOT EXISTS(SELECT 1 FROM ingest.Article a WHERE a.story_id=ingest.Story.story_id);
        SET @stories_deleted=@@ROWCOUNT;

        DELETE r FROM ingest.ArticleRejection r
        WHERE r.rejected_utc<DATEADD(day,-ISNULL(@stage_days,30),SYSUTCDATETIME());
        SET @rejections_deleted=@@ROWCOUNT;

        DELETE s FROM ingest.ArticleStage s
        WHERE s.collected_utc<DATEADD(day,-ISNULL(@stage_days,30),SYSUTCDATETIME())
          AND NOT EXISTS(SELECT 1 FROM ingest.ArticleRejection r WHERE r.stage_id=s.stage_id);
        SET @stage_deleted=@@ROWCOUNT;

        DELETE FROM audit.Event WHERE event_utc<DATEADD(day,-ISNULL(@audit_days,120),SYSUTCDATETIME());
        SET @audit_deleted=@@ROWCOUNT;

        DELETE FROM ops.IngestionRun
        WHERE started_utc<DATEADD(day,-ISNULL(@run_days,365),SYSUTCDATETIME())
          AND run_status IN ('COMPLETED','FAILED','CANCELLED')
          AND NOT EXISTS(SELECT 1 FROM ingest.Article a WHERE a.first_seen_run_id=ops.IngestionRun.run_id OR a.last_seen_run_id=ops.IngestionRun.run_id)
          AND NOT EXISTS(SELECT 1 FROM audit.Event e WHERE e.run_id=ops.IngestionRun.run_id);
        SET @runs_deleted=@@ROWCOUNT;

        COMMIT TRANSACTION;

        UPDATE ops.RetentionCleanupRun
        SET completed_utc=SYSUTCDATETIME(),raw_articles_deleted=@raw_deleted,stories_deleted=@stories_deleted,
            stage_rows_deleted=@stage_deleted,rejection_rows_deleted=@rejections_deleted,
            audit_rows_deleted=@audit_deleted,refresh_runs_deleted=@runs_deleted,status='COMPLETED'
        WHERE cleanup_run_id=@cleanup_id;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT>0 ROLLBACK TRANSACTION;
        UPDATE ops.RetentionCleanupRun
        SET completed_utc=SYSUTCDATETIME(),status='FAILED',error_message=ERROR_MESSAGE()
        WHERE cleanup_run_id=@cleanup_id;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE notify.sp_CreatePriorityEmailBatch
    @run_id uniqueidentifier,
    @created_by nvarchar(320),
    @subject_line nvarchar(500),
    @email_batch_id uniqueidentifier OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @sender nvarchar(320)=(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='GENERAL_SENDER_EMAIL');
    SET @email_batch_id=NEWID();

    INSERT notify.EmailBatch(email_batch_id,run_id,sender_email,subject_line,batch_status,created_by)
    VALUES(@email_batch_id,@run_id,@sender,@subject_line,'PREVIEW',@created_by);

    INSERT notify.EmailBatchRecipient(email_batch_id,recipient_id)
    SELECT @email_batch_id,recipient_id FROM notify.EmailRecipient WHERE active_status='Active';

    INSERT notify.EmailBatchItem(email_batch_id,match_id)
    SELECT @email_batch_id,match_id
    FROM risk.vw_DashboardItems
    WHERE run_id=@run_id AND category_code='PRIORITY' AND placement_status='Active';
END;
GO
SET NOCOUNT ON;
GO

CREATE OR ALTER VIEW ops.vw_RefreshStatus
AS
WITH last_success AS (
    SELECT TOP (1) * FROM ops.IngestionRun WHERE run_status='COMPLETED' ORDER BY completed_utc DESC
), active_counts AS (
    SELECT
        COUNT(*) article_count_stored,
        COUNT(DISTINCT story_id) story_count_stored
    FROM ingest.Article
    WHERE active_status=1
      AND last_seen_utc>=DATEADD(day,-TRY_CONVERT(int,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='RAW_ARTICLE_RETENTION_DAYS')),SYSUTCDATETIME())
)
SELECT
    ls.run_id last_successful_run_id,
    ls.completed_utc last_refresh_utc,
    ac.article_count_stored,
    ac.story_count_stored,
    ls.source_rows_collected article_count_collected_last_run,
    ls.article_rows_processed article_count_processed_last_run,
    ls.junk_rows_rejected junk_count_last_run,
    ls.duplicate_url_rows duplicate_url_count_last_run,
    ls.new_article_rows new_article_count_last_run,
    ls.priority_items_created priority_count_last_run,
    ls.review_items_created review_count_last_run,
    ls.reference_items_created reference_count_last_run
FROM active_counts ac
LEFT JOIN last_success ls ON 1=1;
GO

CREATE OR ALTER VIEW risk.vw_DashboardItems
AS
WITH ranked AS (
    SELECT
        p.placement_id,
        p.placement_status,
        dc.category_code,
        dc.category_name,
        p.placed_utc,
        m.match_id,
        m.run_id,
        m.counterparty_id,
        cp.legal_name counterparty_name,
        cp.common_name counterparty_common_name,
        m.alias_text matched_alias,
        m.entity_match_score,
        m.entity_match_band,
        m.evidence_text match_evidence,
        m.human_review_required,
        a.article_id,
        a.story_id,
        a.title,
        a.snippet,
        a.canonical_url,
        a.domain_name,
        a.source_title,
        a.published_utc,
        a.first_seen_utc,
        a.last_seen_utc,
        st.source_count story_source_count,
        rt.theme_code,
        rt.theme_name risk_theme,
        c.theme_confidence_score,
        c.theme_evidence_text,
        cs.claim_code,
        cs.claim_name claim_strength,
        c.claim_confidence_score,
        c.claim_evidence_text,
        s.severity_score,
        s.confidence_score,
        s.raw_score,
        s.final_score,
        gd.priority_eligible,
        gd.reason_codes,
        ROW_NUMBER() OVER (
            PARTITION BY a.story_id,m.counterparty_id
            ORDER BY s.final_score DESC,ISNULL(a.published_utc,a.first_seen_utc) DESC,a.article_id DESC
        ) row_number_within_story
    FROM risk.DashboardPlacement p
    JOIN ref.DashboardCategory dc ON dc.dashboard_category_id=p.dashboard_category_id
    JOIN risk.ArticleCounterpartyMatch m ON m.match_id=p.match_id
    JOIN ref.Counterparty cp ON cp.counterparty_id=m.counterparty_id
    JOIN ingest.Article a ON a.article_id=m.article_id
    JOIN ingest.Story st ON st.story_id=a.story_id
    JOIN risk.ArticleClassification c ON c.match_id=m.match_id
    JOIN ref.RiskTheme rt ON rt.risk_theme_id=c.risk_theme_id
    JOIN ref.ClaimStrength cs ON cs.claim_strength_id=c.claim_strength_id
    JOIN risk.ArticleScore s ON s.match_id=m.match_id
    JOIN risk.GateDecision gd ON gd.match_id=m.match_id
    WHERE a.active_status=1
      AND a.last_seen_utc>=DATEADD(day,-TRY_CONVERT(int,(SELECT setting_value FROM ops.SystemSetting WHERE setting_key='RAW_ARTICLE_RETENTION_DAYS')),SYSUTCDATETIME())
)
SELECT
    placement_id,placement_status,category_code,category_name,placed_utc,match_id,run_id,
    counterparty_id,counterparty_name,counterparty_common_name,matched_alias,entity_match_score,
    entity_match_band,match_evidence,human_review_required,article_id,story_id,title,snippet,
    canonical_url,domain_name,source_title,published_utc,first_seen_utc,last_seen_utc,story_source_count,
    theme_code,risk_theme,theme_confidence_score,theme_evidence_text,claim_code,claim_strength,
    claim_confidence_score,claim_evidence_text,severity_score,confidence_score,raw_score,final_score,
    priority_eligible,reason_codes
FROM ranked
WHERE row_number_within_story=1;
GO

CREATE OR ALTER VIEW risk.vw_DashboardSummary
AS
SELECT
    COUNT(*) total_items,
    SUM(CASE WHEN category_code='PRIORITY' THEN 1 ELSE 0 END) priority_items,
    SUM(CASE WHEN category_code='REVIEW' THEN 1 ELSE 0 END) review_items,
    SUM(CASE WHEN category_code='REFERENCE' THEN 1 ELSE 0 END) reference_items,
    COUNT(DISTINCT counterparty_id) counterparties_with_current_items,
    MAX(placed_utc) latest_placement_utc
FROM risk.vw_DashboardItems
WHERE placement_status='Active';
GO

CREATE OR ALTER VIEW risk.vw_CurrentPriorityItems
AS
SELECT * FROM risk.vw_DashboardItems
WHERE category_code='PRIORITY' AND placement_status='Active';
GO

CREATE OR ALTER VIEW audit.vw_Last120Days
AS
SELECT * FROM audit.Event
WHERE event_utc>=DATEADD(day,-120,SYSUTCDATETIME());
GO

CREATE OR ALTER VIEW ref.vw_ActiveCounterpartyMatchingData
AS
SELECT
    cp.counterparty_id,cp.legal_name,cp.common_name,cp.ticker,cp.counterparty_type,
    cp.country,cp.importance_tier,cp.exposure_index,cp.match_risk_level,
    a.alias_id,a.alias_text,a.alias_category,a.match_strength,a.requires_context,a.dangerous_short_alias,
    e.exclusion_id,e.do_not_match_terms,e.require_context_terms
FROM ref.Counterparty cp
JOIN ref.CounterpartyAlias a ON a.counterparty_id=cp.counterparty_id AND a.active_status='Active'
LEFT JOIN ref.CounterpartyExclusion e ON e.counterparty_id=cp.counterparty_id AND e.alias_text=a.alias_text AND e.active_status='Active'
WHERE cp.active_status='Active' AND cp.search_enabled=1;
GO
SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name='risk_app_reader') CREATE ROLE risk_app_reader;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name='risk_app_writer') CREATE ROLE risk_app_writer;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name='risk_admin') CREATE ROLE risk_admin;
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name='risk_notifier') CREATE ROLE risk_notifier;
GO

GRANT SELECT ON OBJECT::ops.vw_RefreshStatus TO risk_app_reader;
GRANT SELECT ON OBJECT::risk.vw_DashboardItems TO risk_app_reader;
GRANT SELECT ON OBJECT::risk.vw_DashboardSummary TO risk_app_reader;
GRANT SELECT ON OBJECT::risk.vw_CurrentPriorityItems TO risk_app_reader;
GRANT SELECT ON OBJECT::ref.vw_ActiveCounterpartyMatchingData TO risk_app_reader;
GRANT SELECT ON SCHEMA::ref TO risk_app_reader;
GO

GRANT EXECUTE ON OBJECT::audit.sp_SetSessionActor TO risk_app_writer;
GRANT EXECUTE ON OBJECT::audit.sp_LogEvent TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ops.sp_StartIngestionRun TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ops.sp_UpdateRunStatus TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ops.sp_CompleteIngestionRun TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ops.sp_PurgeExpiredData TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ingest.sp_AddStageArticle TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ingest.sp_RejectStageArticle TO risk_app_writer;
GRANT EXECUTE ON OBJECT::ingest.sp_UpsertAcceptedArticle TO risk_app_writer;
GRANT EXECUTE ON OBJECT::risk.sp_SaveMatch TO risk_app_writer;
GRANT EXECUTE ON OBJECT::risk.sp_SaveClassificationAndScore TO risk_app_writer;
GRANT EXECUTE ON OBJECT::risk.sp_ApplyHardGatesForRun TO risk_app_writer;
GRANT SELECT ON OBJECT::ref.vw_ActiveCounterpartyMatchingData TO risk_app_writer;
GO

GRANT SELECT,INSERT,UPDATE ON OBJECT::notify.EmailRecipient TO risk_notifier;
GRANT SELECT ON OBJECT::risk.vw_CurrentPriorityItems TO risk_notifier;
GRANT EXECUTE ON OBJECT::notify.sp_CreatePriorityEmailBatch TO risk_notifier;
GRANT INSERT,UPDATE,SELECT ON SCHEMA::notify TO risk_notifier;
GO

GRANT CONTROL ON DATABASE::CURRENT TO risk_admin;
GO
SET NOCOUNT ON;
GO

CREATE OR ALTER TRIGGER ops.tr_SystemSetting_Audit
ON ops.SystemSetting
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.Event(
        actor_name,actor_email,actor_ip,session_id,event_type,entity_type,entity_id,
        action_name,old_values,new_values,success_flag
    )
    SELECT
        CONVERT(nvarchar(200),SESSION_CONTEXT(N'actor_name')),
        CONVERT(nvarchar(320),SESSION_CONTEXT(N'actor_email')),
        CONVERT(nvarchar(64),SESSION_CONTEXT(N'actor_ip')),
        CONVERT(nvarchar(128),SESSION_CONTEXT(N'session_id')),
        'SETTINGS','SYSTEM_SETTING',COALESCE(i.setting_key,d.setting_key),
        CASE WHEN i.setting_key IS NOT NULL AND d.setting_key IS NOT NULL THEN 'UPDATE'
             WHEN i.setting_key IS NOT NULL THEN 'INSERT' ELSE 'DELETE' END,
        CASE WHEN d.setting_key IS NULL THEN NULL ELSE (SELECT d.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        CASE WHEN i.setting_key IS NULL THEN NULL ELSE (SELECT i.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        1
    FROM inserted i
    FULL OUTER JOIN deleted d ON d.setting_key=i.setting_key;
END;
GO

CREATE OR ALTER TRIGGER ops.tr_RiskThreshold_Audit
ON ops.RiskThreshold
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.Event(
        actor_name,actor_email,actor_ip,session_id,event_type,entity_type,entity_id,
        action_name,old_values,new_values,success_flag
    )
    SELECT
        CONVERT(nvarchar(200),SESSION_CONTEXT(N'actor_name')),
        CONVERT(nvarchar(320),SESSION_CONTEXT(N'actor_email')),
        CONVERT(nvarchar(64),SESSION_CONTEXT(N'actor_ip')),
        CONVERT(nvarchar(128),SESSION_CONTEXT(N'session_id')),
        'SETTINGS','RISK_THRESHOLD',COALESCE(i.threshold_key,d.threshold_key),
        CASE WHEN i.threshold_key IS NOT NULL AND d.threshold_key IS NOT NULL THEN 'UPDATE'
             WHEN i.threshold_key IS NOT NULL THEN 'INSERT' ELSE 'DELETE' END,
        CASE WHEN d.threshold_key IS NULL THEN NULL ELSE (SELECT d.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        CASE WHEN i.threshold_key IS NULL THEN NULL ELSE (SELECT i.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        1
    FROM inserted i
    FULL OUTER JOIN deleted d ON d.threshold_key=i.threshold_key;
END;
GO

CREATE OR ALTER TRIGGER ref.tr_Counterparty_Audit
ON ref.Counterparty
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.Event(
        actor_name,actor_email,actor_ip,session_id,event_type,entity_type,entity_id,
        action_name,old_values,new_values,success_flag
    )
    SELECT
        CONVERT(nvarchar(200),SESSION_CONTEXT(N'actor_name')),
        CONVERT(nvarchar(320),SESSION_CONTEXT(N'actor_email')),
        CONVERT(nvarchar(64),SESSION_CONTEXT(N'actor_ip')),
        CONVERT(nvarchar(128),SESSION_CONTEXT(N'session_id')),
        'ADMIN','COUNTERPARTY',COALESCE(i.counterparty_id,d.counterparty_id),
        CASE WHEN i.counterparty_id IS NOT NULL AND d.counterparty_id IS NOT NULL THEN 'UPDATE'
             WHEN i.counterparty_id IS NOT NULL THEN 'INSERT' ELSE 'DELETE' END,
        CASE WHEN d.counterparty_id IS NULL THEN NULL ELSE (SELECT d.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        CASE WHEN i.counterparty_id IS NULL THEN NULL ELSE (SELECT i.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        1
    FROM inserted i
    FULL OUTER JOIN deleted d ON d.counterparty_id=i.counterparty_id;
END;
GO

CREATE OR ALTER TRIGGER ref.tr_CounterpartyAlias_Audit
ON ref.CounterpartyAlias
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.Event(
        actor_name,actor_email,actor_ip,session_id,event_type,entity_type,entity_id,
        action_name,old_values,new_values,success_flag
    )
    SELECT
        CONVERT(nvarchar(200),SESSION_CONTEXT(N'actor_name')),
        CONVERT(nvarchar(320),SESSION_CONTEXT(N'actor_email')),
        CONVERT(nvarchar(64),SESSION_CONTEXT(N'actor_ip')),
        CONVERT(nvarchar(128),SESSION_CONTEXT(N'session_id')),
        'ADMIN','COUNTERPARTY_ALIAS',COALESCE(i.alias_id,d.alias_id),
        CASE WHEN i.alias_id IS NOT NULL AND d.alias_id IS NOT NULL THEN 'UPDATE'
             WHEN i.alias_id IS NOT NULL THEN 'INSERT' ELSE 'DELETE' END,
        CASE WHEN d.alias_id IS NULL THEN NULL ELSE (SELECT d.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        CASE WHEN i.alias_id IS NULL THEN NULL ELSE (SELECT i.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        1
    FROM inserted i
    FULL OUTER JOIN deleted d ON d.alias_id=i.alias_id;
END;
GO

CREATE OR ALTER TRIGGER notify.tr_EmailRecipient_Audit
ON notify.EmailRecipient
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT audit.Event(
        actor_name,actor_email,actor_ip,session_id,event_type,entity_type,entity_id,
        action_name,old_values,new_values,success_flag
    )
    SELECT
        CONVERT(nvarchar(200),SESSION_CONTEXT(N'actor_name')),
        CONVERT(nvarchar(320),SESSION_CONTEXT(N'actor_email')),
        CONVERT(nvarchar(64),SESSION_CONTEXT(N'actor_ip')),
        CONVERT(nvarchar(128),SESSION_CONTEXT(N'session_id')),
        'EMAIL','EMAIL_RECIPIENT',CONVERT(nvarchar(200),COALESCE(i.recipient_id,d.recipient_id)),
        CASE WHEN i.recipient_id IS NOT NULL AND d.recipient_id IS NOT NULL THEN 'UPDATE'
             WHEN i.recipient_id IS NOT NULL THEN 'INSERT' ELSE 'DELETE' END,
        CASE WHEN d.recipient_id IS NULL THEN NULL ELSE (SELECT d.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        CASE WHEN i.recipient_id IS NULL THEN NULL ELSE (SELECT i.* FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) END,
        1
    FROM inserted i
    FULL OUTER JOIN deleted d ON d.recipient_id=i.recipient_id;
END;
GO
SET NOCOUNT ON;
GO

EXEC ops.sp_PurgeExpiredData;
GO

-- For Azure SQL Database, schedule only this procedure with Azure Elastic Jobs if guaranteed daily cleanup is required.
-- Do not schedule the ingestion procedure unless automatic scraping has been separately approved.
