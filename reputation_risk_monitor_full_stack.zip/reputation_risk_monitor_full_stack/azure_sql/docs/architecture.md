# Processing flow

```mermaid
flowchart LR
    A[Streamlit Refresh button] --> B[Start ingestion run]
    B --> C[Collect article metadata]
    C --> D[Stage every collected row]
    D --> E{Obvious junk?}
    E -- Yes --> F[Rejection log]
    E -- No --> G[Canonical URL and story key]
    G --> H{URL already stored?}
    H -- Yes --> I[Update last seen and count duplicate]
    H -- No --> J[Store article and group under story]
    J --> K[Load active counterparties aliases exclusions]
    K --> L[Entity matching and match confidence]
    L --> M[Risk theme and claim strength]
    M --> N[Component scores]
    N --> O[SQL hard gates]
    O --> P[Priority Review Reference]
    P --> Q[Dashboard views]
    P --> R[Optional BCC email batch]
    Q --> S[Last refresh stored count processed count]
    B --> T[120-day retention purge]
    O --> T
```

## Responsibility split

| Layer | Responsibility |
|---|---|
| Streamlit | User-triggered refresh, filters, display, email preview |
| Python collection | RSS/API collection and URL normalization |
| Python model | Alias matching, evidence extraction, risk theme, claim strength, component scoring |
| Azure SQL | Durable data, dedupe, 120-day retention, hard gates, categories, dashboard views, audit, email queue |
| Email service | Sends an approved BCC batch from the configured general mailbox |

## Dedupe behavior

- The article URL hash is unique, so the same URL is stored once.
- The story hash groups different URLs that describe the same story.
- The dashboard displays article-counterparty results, but story IDs can be used to suppress repeated syndicated coverage.
- Duplicate attempts remain counted in the ingestion run and may be retained briefly in staging for diagnostics.
