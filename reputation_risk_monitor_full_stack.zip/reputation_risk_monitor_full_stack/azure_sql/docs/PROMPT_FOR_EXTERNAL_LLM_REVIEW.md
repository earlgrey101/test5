# Prompt for an external LLM to review the counterparty risk monitoring project

You are reviewing a self-initiated proof-of-concept project for Financial Risk Oversight and Enterprise Risk Management in a large financial technology company. Act as a combined senior data architect, Azure SQL engineer, Python engineer, model-risk reviewer, information-security reviewer, operational-risk practitioner, and senior risk-product reviewer.

Your job is to explain the project completely, inspect the supplied files carefully, identify what is implemented versus merely scaffolded, evaluate its business value and risks, find code or architecture problems, and recommend a practical path from prototype to a controlled internal pilot.

Do not give generic praise. Be specific, critical, and evidence-based. Cite file paths and line numbers whenever possible. Do not assume that a feature exists merely because it is mentioned in a README. If a referenced file, function, integration, or control is absent, say so explicitly.

## 1. Business and project context

This project began as a small external-risk news monitor covering PayPal, KKR, and Blue Owl. It later expanded into a proposed portfolio-scale monitor for approximately 373 counterparties. The broader dashboard has been developed separately in Streamlit and includes counterparty management, aliases, exclusions, risk-theme filters, email-recipient administration, audit logs, and local retention logic.

The package attached to this prompt is the next architectural step: an Azure SQL Database design and Python integration scaffold intended to replace CSV-only storage with a durable, auditable database-backed workflow.

The business problem is information lag and fragmentation. External developments involving a counterparty may appear in public news, regulatory sources, court reports, company statements, or market commentary before they manifest in internal financial metrics. The project is intended to help a second-line risk function identify, organize, and prioritize those signals.

The system is not intended to:

- Make legal conclusions.
- Determine guilt or misconduct.
- Replace a counterparty owner, compliance team, legal team, or risk committee.
- Create an official risk rating by itself.
- Infer internal PayPal exposure when no approved exposure data exists.
- Bypass paywalls.
- Treat market movement as causal proof.
- Let an LLM or similarity model create a top-level alert on its own.

The system is intended to:

- Collect public article metadata.
- Remove obvious junk.
- Deduplicate URLs and group related stories.
- Match articles to monitored counterparties.
- Measure the confidence of each entity match.
- Classify a controlled risk theme.
- Classify claim strength.
- calculate component and final scores.
- Apply deterministic hard gates.
- Place results into Priority, Review, or Reference categories.
- Show operational counts and last-refresh information in a dashboard.
- Optionally prepare BCC email batches for Priority items.
- Retain a traceable audit trail.

## 2. Required end-to-end workflow

The intended operational flow is:

1. A user presses a Refresh button in Streamlit.
2. A manual ingestion run is created in Azure SQL.
3. A Python collection function retrieves article metadata such as title, URL, canonical URL, source, domain, snippet, publication time, feed source, source query, and external story ID when available.
4. Every attempted row is staged.
5. Obvious junk is rejected and logged.
6. Unique accepted URLs are inserted or updated.
7. Related URLs are grouped under a story identity.
8. Active counterparties, aliases, and exclusions are loaded.
9. Articles are matched to counterparties.
10. Each match receives an entity-match confidence score and evidence span.
11. Each match is classified into a coded risk theme.
12. Each match receives a controlled claim-strength category.
13. Component scores and a final score are calculated.
14. Azure SQL applies hard escalation gates.
15. Results are assigned to Priority, Review, or Reference.
16. Streamlit reads dashboard-ready SQL views.
17. The dashboard shows last refresh time, articles stored, articles processed during the last run, new articles, duplicate counts, and category counts.
18. If enabled and approved, Priority items can be assembled into a BCC email batch.
19. Retention cleanup removes expired raw and derived records.

Required retention and collection behavior:

- Accepted raw articles are retained for 120 days after their last-seen time.
- Article matches, classifications, scores, gates, and placements are retained for the same effective 120-day period through cascade deletion.
- Staging and rejected rows are retained for 30 days by default.
- Application audit events are retained for 120 days.
- Refresh-run summaries are retained for 365 days by default.
- Duplicate URLs are not stored as separate accepted articles.
- Different URLs concerning the same story may remain as separate source observations but are grouped under a story ID.
- Live collection occurs only when a user clicks Refresh.
- Automatic scraping is blocked unless separately approved.
- Retention cleanup runs before and after a manual refresh.
- A maintenance-only purge may later be scheduled with an approved Azure mechanism without enabling automatic article collection.

## 3. Risk-methodology principles

The intellectual core of the project is the separation of different concepts that should not be collapsed into one opaque score:

- Severity: how serious the underlying event could be.
- Article confidence: how well supported the reported information is.
- Entity-match confidence: how confident the system is that the article concerns the specified counterparty.
- Source quality: the reliability and authority of the publisher or official source.
- Claim strength: whether the item is ordinary context, commentary, a reported development, a trusted-source investigation, or an official/confirmed action.
- Exposure: the importance of the counterparty to the business, if approved internal exposure data becomes available.

The governing principle is:

> Exposure may amplify a credible adverse signal, but exposure must not manufacture risk from benign or weak evidence.

The design uses deterministic hard gates after scoring. A high score alone must not create a Priority item.

Current default SQL thresholds are:

- Priority final-score minimum: 60.
- Priority article-confidence minimum: 60.
- Priority entity-match minimum: 80.
- Priority source-quality rank minimum: 4 out of 5.
- Priority claim-strength rank minimum: 3 out of 5.
- Review final-score minimum: 40.
- Review entity-match minimum: 50.
- Maximum risk-term token distance: 12.
- Maximum exposure multiplier: 1.30.

Current source-quality ranks are:

1. Unknown.
2. Lower quality.
3. Established.
4. Trusted.
5. Official.

Current claim-strength ranks are:

1. No serious claim detected.
2. Opinion or commentary.
3. Reported legal or regulatory development.
4. Trusted source reports investigation.
5. Official or confirmed action.

Current coded risk themes are:

- Regulatory or legal.
- Fraud or misconduct.
- Cyber or data privacy.
- Credit or liquidity stress.
- Operational or payment disruption.
- Consumer trust.
- Sanctions or geopolitical.
- Ordinary business context.

Current dashboard categories are:

- Priority items: strong, well-supported items that meet every top-level gate.
- Review items: potentially relevant items that need additional confirmation or human review.
- Reference items: background, low-confidence, weak-match, context-only, duplicate, or non-actionable items.

## 4. Current package contents

Inspect all supplied files. The current package contains:

```text
README.md
architecture.md
data_dictionary.csv
sql/all_in_one.sql
python/azure_sql_repository.py
python/refresh_pipeline.py
python/streamlit_refresh_example.py
```

The package does not currently contain the complete Streamlit dashboard, the 373-counterparty seed CSV files, a production collector, a completed entity matcher, a completed classifier/scorer, an email provider integration, automated tests, a requirements file, an environment-variable example file, or separate numbered SQL deployment scripts.

This distinction is important. The current package is an architecture and integration scaffold, not a finished production system.

## 5. File-by-file purpose and expected relationships

### `README.md`

This is the primary project overview. It describes:

- The recommended architecture.
- Database schemas.
- Retention rules.
- A deployment order.
- Python integration.
- Expected manual-refresh behavior.

Check whether every file and capability referenced in the README actually exists. The README currently refers to numbered SQL files and a seed-data loader, while the supplied package appears to include only `sql/all_in_one.sql` and three Python files. Treat this as a documentation/package-consistency issue to verify.

### `architecture.md`

This contains:

- A Mermaid flow diagram from Refresh through collection, staging, junk filtering, deduplication, matching, classification, scoring, gates, dashboard placement, email preparation, and retention.
- A responsibility split between Streamlit, Python collection/model logic, Azure SQL, and an external email service.
- URL-level and story-level deduplication principles.

Evaluate whether the responsibility split is appropriate and whether any responsibilities should move between Python, Azure SQL, and the user interface.

### `data_dictionary.csv`

This is a short schema/table-purpose/retention summary. Verify that it is complete and consistent with the actual SQL script.

### `sql/all_in_one.sql`

This is the central Azure SQL Database script. It creates six schemas:

- `ref`: reference and master data.
- `ops`: system settings, thresholds, ingestion runs, and retention runs.
- `ingest`: staging, rejection, stories, and accepted articles.
- `risk`: entity matches, classifications, scores, gates, and placements.
- `notify`: recipients and email-batch records.
- `audit`: actor and system event history.

It includes table definitions, reference seeds, settings, thresholds, stored procedures, views, database roles/grants, and audit triggers.

Review it for Azure SQL compatibility, syntax correctness, idempotency, transaction safety, concurrency behavior, indexing, data types, cascade behavior, least privilege, retention correctness, and performance.

### `python/azure_sql_repository.py`

This file is the database-access layer.

Key elements:

- `DatabaseConfig`: loads Azure SQL server/database/authentication settings from environment variables and creates a connection string.
- `AzureSqlRepository.connection()`: manages transactions and connection closure.
- `_set_actor()`: places actor metadata into SQL session context.
- `start_manual_run()`: creates a manual ingestion run.
- `update_run_status()`: updates run state and errors.
- `add_stage_article()`: stores a collected row before acceptance/rejection.
- `reject_stage_article()`: logs a rejected row.
- `upsert_article()`: creates or updates an accepted article/story record.
- `load_matching_reference()`: loads active counterparties, aliases, exclusions, and related reference data.
- `save_match()`: saves article-counterparty match evidence.
- `save_classification_and_score()`: saves theme, claim, and scoring output.
- `apply_gates()`: invokes SQL hard gates.
- `complete_run()`: writes final run counts.
- `purge_expired()`: invokes retention cleanup.
- `refresh_status()`: reads last-refresh and article-count information.
- `dashboard_items()`: reads active dashboard rows and optionally filters by category.

Review parameter binding, connection handling, transaction scope, retry behavior, authentication suitability, exception handling, bulk-insert performance, and protection against partial runs.

### `python/refresh_pipeline.py`

This file is the refresh orchestrator.

Key elements:

- `RefreshResult`: returns run ID and run counters.
- `canonicalize_url()`: normalizes URLs and removes common tracking parameters.
- `story_key()`: creates a normalized title-based story key.
- `obvious_junk_reason()`: rejects feed errors, missing/short titles, invalid URLs, and obvious error pages.
- `run_manual_refresh()`: runs the complete collection-to-gating workflow.

`run_manual_refresh()` accepts three dependency-injected callables:

- `collect_articles()`.
- `match_article(article, reference_data)`.
- `classify_and_score(article, match)`.

Those callables are not implemented in this package. They are expected integration points. Explain the consequences of this and recommend an interface contract and test strategy for each.

The pipeline currently processes rows one at a time and uses many database calls. Evaluate scalability and whether staging/bulk operations would be more appropriate.

### `python/streamlit_refresh_example.py`

This is an example of dashboard integration rather than the full dashboard.

It:

- Creates an Azure SQL repository from environment variables.
- Displays articles stored, processed during the last run, new during the last run, and the last refresh time in UTC.
- Runs `run_manual_refresh()` when the user clicks the Refresh button.
- Loads dashboard items into a pandas DataFrame.

Review user experience, failure handling, authorization, session identity, IP handling, concurrency, refresh-button locking, timeouts, progress reporting, and duplicate clicks.

## 6. Database object map

### Reference schema: `ref`

#### `ref.Counterparty`

Master record for each monitored counterparty. It includes legal/common names, ticker data, type, country, optional importance/exposure/owner data, active/search flags, match-risk level, alias-review flag, timestamps, and row version.

#### `ref.CounterpartyAlias`

Stores legal names, common names, tickers, brands, subsidiaries, and other matchable aliases. It records match strength, whether context is required, whether the alias is dangerously short, active state, and review status.

#### `ref.CounterpartyExclusion`

Stores do-not-match terms and required context for ambiguous names and aliases.

#### `ref.RiskTheme`

Controlled risk-theme taxonomy.

#### `ref.ClaimStrength`

Controlled claim-strength taxonomy with ranks from one to five.

#### `ref.SourceQuality`

Controlled source-quality taxonomy with ranks from one to five.

#### `ref.DashboardCategory`

Controlled Priority, Review, and Reference categories.

#### `ref.SourceDomain`

Maps publisher domains to a source-quality category.

### Operations schema: `ops`

#### `ops.SystemSetting`

Stores typed application settings, including retention, manual/automatic collection approval, email enablement, and sender email.

#### `ops.RiskThreshold`

Stores numeric hard-gate and scoring thresholds.

#### `ops.IngestionRun`

One record per manual or approved automated refresh, including actor/session metadata, status, timestamps, counters, and errors.

#### `ops.RetentionCleanupRun`

Records each cleanup attempt and deletion counts.

### Ingestion schema: `ingest`

#### `ingest.ArticleStage`

Stores every attempted collected row before acceptance or rejection.

#### `ingest.ArticleRejection`

Stores junk, duplicate, and processing-error decisions.

#### `ingest.Story`

Groups separate URLs concerning the same normalized story.

#### `ingest.Article`

Stores accepted unique article metadata. URL hash is unique. Each article belongs to one story and records first/last seen times and runs.

### Risk schema: `risk`

#### `risk.ArticleCounterpartyMatch`

Stores one article-counterparty match, the alias used, match method, match score/band, evidence, token distance, context, exclusions, review requirement, and model version.

The SQL design enforces one match for a given article and counterparty. Review whether this constraint supports reprocessing/versioning needs or whether model-run history should be retained separately.

#### `risk.ArticleClassification`

Stores one theme/claim classification per match, evidence, confidence scores, proximity/context flags, and classification version.

#### `risk.ArticleScore`

Stores severity, confidence, source, claim, recency, exposure, raw score, final score, and scoring version.

#### `risk.GateDecision`

Stores each deterministic gate result, final category, reason codes in JSON, gate version, and decision time.

#### `risk.DashboardPlacement`

Stores the active/suppressed/resolved dashboard state for each match.

### Notification schema: `notify`

#### `notify.EmailRecipient`

Stores display name, `@paypal.com` email address, active/inactive state, and add/remove metadata. The database enforces the email domain.

#### `notify.EmailBatch`

Stores a Priority email preview/queue/send record.

#### `notify.EmailBatchRecipient`

Links active recipients to a batch and enforces BCC-only delivery type.

#### `notify.EmailBatchItem`

Links Priority matches to an email batch.

#### `notify.EmailDeliveryLog`

Stores provider message IDs, send status, timestamps, and errors.

### Audit schema: `audit`

#### `audit.Event`

Stores UTC event time, actor name/email/IP/session, event/entity/action, old/new JSON, run ID, success flag, and errors.

Audit triggers currently exist for system settings, thresholds, counterparties, aliases, and email recipients. Review whether exclusions, source-domain changes, email batches, suppression/resolution decisions, and other administrative actions also require triggers or explicit logging.

## 7. Stored procedures and views

Explain and review the following procedures:

- `audit.sp_SetSessionActor`.
- `audit.sp_LogEvent`.
- `ops.sp_StartIngestionRun`.
- `ops.sp_UpdateRunStatus`.
- `ingest.sp_AddStageArticle`.
- `ingest.sp_RejectStageArticle`.
- `ingest.sp_UpsertAcceptedArticle`.
- `risk.sp_SaveMatch`.
- `risk.sp_SaveClassificationAndScore`.
- `risk.sp_ApplyHardGatesForRun`.
- `ops.sp_CompleteIngestionRun`.
- `ops.sp_PurgeExpiredData`.
- `notify.sp_CreatePriorityEmailBatch`.

Explain and review the following views:

- `ops.vw_RefreshStatus`.
- `risk.vw_DashboardItems`.
- `risk.vw_DashboardSummary`.
- `risk.vw_CurrentPriorityItems`.
- `audit.vw_Last120Days`.
- `ref.vw_ActiveCounterpartyMatchingData`.

Pay special attention to:

- Whether story-level consolidation in `risk.vw_DashboardItems` behaves as intended.
- Whether last-seen-based retention is correctly implemented.
- Whether refresh counts accurately distinguish collected, rejected, duplicate, accepted, processed, matched, and categorized rows.
- Whether the gate logic handles missing source quality correctly.
- Whether the Review fallback is too permissive or too restrictive.
- Whether a context-only item or weak source can ever become Priority.
- Whether repeated processing should update or version existing matches/classifications.
- Whether email batches can accidentally include stale or previously emailed Priority items.

## 8. Security and identity design

The SQL script defines these database roles:

- `risk_app_reader`.
- `risk_app_writer`.
- `risk_notifier`.
- `risk_admin`.

Review least privilege. In particular, assess whether granting `CONTROL` on the database to `risk_admin` is appropriate and whether broad schema-level grants should be narrowed.

The Python configuration currently uses the `mssql-python` package and an environment-configured Microsoft Entra authentication method, defaulting to interactive authentication for local development.

Review:

- Whether this driver and authentication mode are appropriate for local development and Azure-hosted execution.
- Managed identity or service-principal alternatives.
- Azure SQL firewall/private endpoint requirements.
- Secret handling.
- TLS settings.
- Row-level or column-level security needs.
- Whether actor identity should come from authenticated application claims instead of user-entered fields.
- Limitations of capturing client IP in local Streamlit.
- Native Azure SQL Auditing versus the custom `audit.Event` table.
- Retention expectations for application audit versus security/compliance audit.

## 9. Business impact to assess

Evaluate the likely business value of this system for a second-line risk function:

- Earlier identification of counterparty developments.
- Reduced manual searching across hundreds of counterparties.
- Consistent treatment of source quality, claim status, and entity confidence.
- Separation of serious items from review noise and background evidence.
- Improved traceability of why an item was or was not escalated.
- Portfolio-level visibility into which counterparties and risk themes are producing current signals.
- Faster routing to risk owners.
- Controlled Priority email preparation.
- Better documentation of settings, administrative changes, and refresh activity.

Also identify possible negative business impacts:

- Alert fatigue.
- False positives from ambiguous aliases.
- False negatives from missing aliases or feeds.
- Overconfidence in a numerical score.
- Duplicate or stale alerts.
- Liability from presenting allegations too strongly.
- Data-licensing or terms-of-service concerns.
- Security concerns if internal counterparty/exposure data is mixed with public hosting.
- Operational dependency on a prototype maintained by one person.

## 10. Model-risk and hallucination controls to assess

The preferred model is a hybrid system:

- Deterministic alias and exclusion rules for entity identity.
- Token-distance and context checks.
- Controlled source-quality and claim-strength taxonomies.
- Rules or lightweight similarity for risk-theme support.
- Evidence spans copied from the title/snippet.
- Deterministic SQL hard gates for final category placement.
- Human review for ambiguous matches.

A generative LLM, if added later, should be limited to structured assistive tasks and should never be the sole basis of Priority placement.

Review and recommend controls such as:

- JSON-schema-constrained output.
- Required quoted evidence spans.
- Abstention when evidence is insufficient.
- Versioned prompts/models/rules.
- Independent manual labels.
- Precision tracking for Priority items.
- Entity-match accuracy by alias.
- False-positive and false-negative review.
- Shadow mode before email enablement.
- Source and duplicate suppression.
- Reprocessing behavior after model changes.

## 11. Known current limitations and package gaps

Treat the following as known limitations or issues to verify:

1. The SQL has not been executed against a live Azure SQL Database in this environment.
2. Python syntax compilation succeeded, but there are no integration tests.
3. The actual article collector is not included.
4. The actual entity matcher is not included.
5. The actual risk-theme/claim classifier and score calculation are not included.
6. The full Streamlit dashboard is not included in this package.
7. The actual email sender or Microsoft Graph/Outlook integration is not included.
8. Automatic collection remains intentionally disabled by default.
9. The 373 counterparty/alias/exclusion seed files are not present in this ZIP, despite the broader project having generated them separately.
10. The README refers to numbered SQL scripts and a seed-data loader that are not present in the current package.
11. There is no `requirements.txt` or `.env.example` in this package.
12. There are no database migration/version-control tools.
13. There is no CI/CD pipeline.
14. There is no load/performance test for 373 counterparties, large alias sets, or 120 days of articles.
15. There is no independent validation dataset connected to this Azure design.
16. The current story key is based primarily on normalized title text and may over-group or under-group stories.
17. URL canonicalization removes common tracking parameters but may not handle every publisher redirect or canonical-link pattern.
18. Row-by-row database calls may be slow at scale.
19. One-match/one-classification/one-score constraints may make historical reprocessing and model comparison difficult.
20. The email queue does not itself send mail and needs idempotency/cooldown rules.
21. Audit and operational data retention must be approved rather than assumed.
22. Public-news collection sources and licensing have not been finalized.

## 12. Potential extensions to evaluate

Evaluate and prioritize these possible extensions:

- Approved RSS/API/news-provider ingestion.
- Azure Function or internal API for manually triggered collection.
- Bulk staging with table-valued parameters or bulk copy.
- Separate model-run/version tables for reprocessing and comparisons.
- Better story clustering using source-independent fingerprints or embeddings.
- Source-domain management in the dashboard.
- Human-review and adjudication tables.
- Validation metrics by source, alias, counterparty, risk theme, and category.
- Suppression, cooldown, resolution, and re-escalation logic.
- Internal approved exposure metrics.
- Relationship-owner routing.
- Microsoft Graph email delivery from an approved shared mailbox.
- Microsoft Entra group/directory lookup for recipients.
- Managed identity and private endpoints.
- Azure Monitor/Application Insights/Log Analytics integration.
- Native Azure SQL Auditing.
- Elastic Job for retention-only maintenance.
- Data-quality dashboards.
- Operational alerts for failed refreshes.
- Disaster recovery, backups, and point-in-time restore procedures.
- CI/CD and schema migrations.
- Unit, integration, regression, security, and performance tests.

## 13. Specific review questions

Answer all of these:

1. Is Azure SQL Database an appropriate durable store for this workload?
2. Is the split between Python and SQL sensible?
3. Which logic belongs in Python, which belongs in SQL, and which belongs in the UI?
4. Is the schema normalized enough without becoming unnecessarily complex?
5. Are all primary keys, foreign keys, unique constraints, and cascade paths appropriate?
6. Is URL and story deduplication robust enough?
7. Does the retention process safely delete derived records and avoid deleting still-referenced operational records?
8. Are the stored procedures safe under concurrent refreshes?
9. What happens if two users click Refresh at once?
10. What happens if the process fails halfway through?
11. Are row-by-row repository calls acceptable, or should the system use bulk operations?
12. Is the gate design sufficiently conservative?
13. Are the default thresholds defensible, or should they remain illustrative until validated?
14. Are source quality and claim strength modeled correctly?
15. Is the email-recipient domain check correct and sufficient?
16. How should duplicate, stale, suppressed, resolved, and already-emailed items be handled?
17. How should model/rule versions and reprocessing history be stored?
18. How should independent validation be conducted?
19. What are the largest hallucination and entity-resolution risks?
20. What Azure security controls are mandatory before an internal pilot?
21. What current files or functions are missing for a runnable end-to-end system?
22. Which README claims are inconsistent with the actual package?
23. What bugs, SQL syntax issues, Azure incompatibilities, or Python problems exist?
24. What should be removed, simplified, or deferred?
25. What is the smallest credible internal pilot?

## 14. Required response format

Provide your response in this order:

### A. Executive assessment

Give a direct assessment of the project’s strength, business relevance, architectural maturity, and current readiness. State whether it is a design, scaffold, prototype, pilot candidate, or production-ready system.

### B. Plain-language explanation

Explain how the entire system works sequentially for a non-coder and a senior risk leader.

### C. Business value and decision support

Explain what decisions the system supports, what it does not support, and where value is likely to arise.

### D. Architecture and file relationship map

Explain every supplied file, its callers/dependencies, and how data moves between files and database objects. Include a text diagram.

### E. Database review

Review every schema, major table relationship, procedure, view, trigger, index, role, retention rule, and email/audit object.

### F. Python review

Review each class and function, including interfaces that are currently missing.

### G. Implemented versus scaffolded versus missing

Provide a three-column matrix:

- Implemented in supplied code.
- Scaffolded or partially implemented.
- Missing or external dependency.

### H. Defects and risks

Provide a severity-ranked issue list using Critical, High, Medium, and Low. Cite file paths and line numbers. Separate definite defects from design concerns and open questions.

### I. Model-risk and hallucination assessment

Evaluate entity matching, classification, scoring, hard gates, evidence grounding, validation, and LLM boundaries.

### J. Security, privacy, and compliance assessment

Evaluate identity, permissions, audit, email, IP collection, retention, network security, secrets, data licensing, and internal/public deployment boundaries.

### K. Scalability and operational assessment

Evaluate performance for roughly 373 counterparties, a growing alias table, multiple feeds, 120 days of data, duplicate coverage, concurrent refreshes, and email delivery.

### L. Testing strategy

Provide the exact unit, integration, database, regression, validation, security, performance, and user-acceptance tests required.

### M. Prioritized roadmap

Provide:

- Immediate fixes before any Azure deployment.
- Minimum viable internal pilot.
- Medium-term extensions.
- Production-readiness work.

### N. Recommended folder structure

Propose a corrected repository structure containing migrations, seeds, app code, tests, config, deployment, and documentation.

### O. Suggested corrections

Provide concrete code or SQL patches for the most important defects. Do not rewrite everything unnecessarily.

### P. Questions for stakeholders

List questions that must be answered by the manager, Azure administrator, information-security team, legal/compliance, data owner, model-risk function, and email/identity administrators.

## 15. Review standard

Be candid. The goal is not to validate the author’s confidence. The goal is to help turn a strong self-initiated risk-monitoring idea into a controlled, supportable internal system.

Do not describe the project as production-ready unless the supplied files actually justify that conclusion.
