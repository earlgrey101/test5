from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

import pandas as pd
import yaml

from entity_matcher import match_articles_to_counterparties
from portfolio_engine import score_portfolio_matches
from risk_engine import source_category

ROOT_DIR = Path(__file__).resolve().parents[2]


THEME_CODE_MAP = {
    "Regulatory Legal": "REGULATORY_LEGAL",
    "Regulatory Or Legal": "REGULATORY_LEGAL",
    "Fraud Misconduct": "FRAUD_MISCONDUCT",
    "Fraud Or Misconduct": "FRAUD_MISCONDUCT",
    "Cyber Privacy": "CYBER_PRIVACY",
    "Cyber Or Data Privacy": "CYBER_PRIVACY",
    "Credit Liquidity Stress": "CREDIT_LIQUIDITY",
    "Credit Or Liquidity Stress": "CREDIT_LIQUIDITY",
    "Operational Or Payment Disruption": "OPERATIONS_PAYMENTS",
    "Operations Payments": "OPERATIONS_PAYMENTS",
    "Consumer Trust": "CONSUMER_TRUST",
    "Sanctions Geopolitical": "SANCTIONS_GEOPOLITICAL",
    "Sanctions Or Geopolitical": "SANCTIONS_GEOPOLITICAL",
}

CLAIM_CODE_MAP = {
    "Confirmed regulatory or official source": "OFFICIAL_OR_CONFIRMED",
    "Reported legal or regulatory development by trusted source": "REPORTED_DEVELOPMENT",
    "Reported investigation by trusted source": "TRUSTED_REPORTED_INVESTIGATION",
    "Reported legal or regulatory development": "REPORTED_DEVELOPMENT",
    "Opinion or commentary": "OPINION_OR_COMMENTARY",
    "No serious claim detected": "NO_SERIOUS_CLAIM",
}

MATCH_SCORE_MAP = {"High": 90.0, "Medium": 70.0, "Low": 40.0, "Suppressed": 0.0}
CLAIM_SCORE_MAP = {
    "OFFICIAL_OR_CONFIRMED": 100.0,
    "TRUSTED_REPORTED_INVESTIGATION": 85.0,
    "REPORTED_DEVELOPMENT": 65.0,
    "OPINION_OR_COMMENTARY": 35.0,
    "NO_SERIOUS_CLAIM": 10.0,
}


def load_config() -> dict[str, Any]:
    with open(ROOT_DIR / "config_phase1.yaml", "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle)


def reference_frames(reference_data: list[dict[str, Any]]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    raw = pd.DataFrame(reference_data)
    if raw.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    counterparties = raw[
        [
            "counterparty_id",
            "legal_name",
            "common_name",
            "ticker",
            "counterparty_type",
            "country",
            "importance_tier",
            "exposure_index",
            "match_risk_level",
        ]
    ].drop_duplicates("counterparty_id")
    counterparties = counterparties.rename(
        columns={"counterparty_type": "counterparty_type_guess", "country": "country_guess"}
    )
    counterparties["active_status"] = "Active"
    counterparties["source_name_status"] = "Complete"
    counterparties["alias_review_required"] = "No"
    counterparties["review_flags"] = ""
    counterparties["relationship_owner"] = ""
    counterparties["notes"] = ""

    aliases = raw[
        [
            "alias_id",
            "counterparty_id",
            "alias_text",
            "alias_category",
            "match_strength",
            "requires_context",
            "dangerous_short_alias",
        ]
    ].copy()
    aliases["active_status"] = "Active"
    aliases["do_not_match_terms"] = raw.get("do_not_match_terms", "")

    exclusions = raw[
        [
            "counterparty_id",
            "alias_text",
            "do_not_match_terms",
            "require_context_terms",
        ]
    ].copy()
    exclusions["active_status"] = "Active"
    exclusions = exclusions[
        exclusions["do_not_match_terms"].fillna("").astype(str).str.strip().ne("")
        | exclusions["require_context_terms"].fillna("").astype(str).str.strip().ne("")
    ]
    return counterparties, aliases, exclusions


def match_article(article: dict[str, Any], reference_data: list[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    counterparties, aliases, exclusions = reference_frames(reference_data)
    if counterparties.empty or aliases.empty:
        return []

    article_id = article.get("canonical_url") or article.get("raw_url") or article.get("title")
    articles = pd.DataFrame(
        [
            {
                "validation_id": article_id,
                "title": article.get("title", ""),
                "snippet": article.get("snippet", ""),
                "url": article.get("canonical_url") or article.get("raw_url", ""),
                "source_title": article.get("source_title", ""),
                "domain": article.get("domain_name", ""),
                "published_at": article.get("published_utc", ""),
            }
        ]
    )
    matches, _ = match_articles_to_counterparties(
        articles,
        counterparties,
        aliases,
        exclusions,
        context_window=18,
    )
    if matches.empty:
        return []

    output: list[dict[str, Any]] = []
    for _, row in matches.iterrows():
        band = str(row.get("entity_match_confidence") or "Low")
        alias_row = aliases[
            (aliases["counterparty_id"].astype(str) == str(row.get("counterparty_id")))
            & (aliases["alias_text"].astype(str) == str(row.get("alias_matched")))
        ]
        alias_id = None if alias_row.empty else alias_row.iloc[0].get("alias_id")
        output.append(
            {
                "counterparty_id": row.get("counterparty_id"),
                "alias_id": alias_id,
                "alias_text": row.get("alias_matched"),
                "match_method": "ALIAS_WITH_CONTEXT" if row.get("context_passed") == "Yes" else "ALIAS_EXACT",
                "entity_match_score": MATCH_SCORE_MAP.get(band, 40.0),
                "entity_match_band": band,
                "evidence_text": row.get("alias_matched"),
                "token_distance": None,
                "context_terms_found": row.get("context_hits", ""),
                "exclusion_triggered": row.get("suppressed") == "Yes",
                "exclusion_reason": row.get("do_not_match_hits", ""),
                "human_review_required": row.get("needs_human_review") == "Yes",
                "model_version": "portfolio_matcher_v1",
                "_counterparties": counterparties,
                "_aliases": aliases,
                "_article_frame": articles,
                "_match_frame": pd.DataFrame([row.to_dict()]),
            }
        )
    return output


def _theme_code(theme_text: str) -> str:
    first = (theme_text or "").split(";")[0].strip()
    return THEME_CODE_MAP.get(first, "ORDINARY_CONTEXT")


def _claim_code(claim_text: str) -> str:
    return CLAIM_CODE_MAP.get(claim_text or "", "NO_SERIOUS_CLAIM")


def classify_and_score(article: dict[str, Any], match: dict[str, Any]) -> dict[str, Any]:
    cfg = load_config()
    scored = score_portfolio_matches(
        match["_article_frame"],
        match["_match_frame"],
        match["_counterparties"],
        match["_aliases"],
        cfg,
    )
    if scored.empty:
        raise ValueError("The classifier did not produce a score for the accepted match.")

    row = scored.iloc[0]
    claim_code = _claim_code(str(row.get("claim_status", "")))
    theme_code = _theme_code(str(row.get("themes", "")))
    source_name = str(row.get("source_name", ""))
    _, source_rank, _, _ = source_category(source_name, cfg)
    source_score = {1: 20.0, 2: 35.0, 3: 60.0, 4: 80.0, 5: 95.0}.get(source_rank, 35.0)
    recency_component = max(0.0, min(1.0, float(row.get("base_article_risk", 0.0)) / 100.0))

    return {
        "risk_theme_code": theme_code,
        "theme_confidence_score": 80.0 if bool(row.get("risk_term_near_counterparty")) else 30.0,
        "theme_evidence_text": str(row.get("nearby_risk_hits") or row.get("risk_hits") or "")[:1000],
        "claim_code": claim_code,
        "claim_confidence_score": CLAIM_SCORE_MAP[claim_code],
        "claim_evidence_text": str(row.get("claim_matches") or "")[:1000],
        "risk_term_near_entity": bool(row.get("risk_term_near_counterparty")),
        "is_context_only": bool(row.get("context_only_signal")),
        "classification_version": "portfolio_classifier_v1",
        "severity_score": float(row.get("base_article_risk", 0.0)),
        "confidence_score": float(row.get("confidence_score", 0.0)),
        "source_quality_score": source_score,
        "claim_strength_score": CLAIM_SCORE_MAP[claim_code],
        "recency_multiplier": recency_component,
        "exposure_multiplier": float(row.get("exposure_multiplier", 1.0)),
        "raw_score": float(row.get("initial_signal_score", 0.0)),
        "final_score": float(row.get("overall_priority_score", 0.0)),
        "scoring_version": "portfolio_scoring_v1",
    }
