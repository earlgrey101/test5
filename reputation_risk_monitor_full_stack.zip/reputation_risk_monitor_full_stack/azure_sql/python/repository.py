from __future__ import annotations

import json
import os
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterable

try:
    from mssql_python import connect
except ImportError:
    connect = None


@dataclass(frozen=True)
class DatabaseConfig:
    server: str
    database: str
    authentication: str = "ActiveDirectoryInteractive"
    encrypt: bool = True
    trust_server_certificate: bool = False

    @classmethod
    def from_env(cls) -> "DatabaseConfig":
        return cls(
            server=os.environ["AZURE_SQL_SERVER"],
            database=os.environ["AZURE_SQL_DATABASE"],
            authentication=os.getenv("AZURE_SQL_AUTHENTICATION", "ActiveDirectoryInteractive"),
            encrypt=os.getenv("AZURE_SQL_ENCRYPT", "yes").lower() in {"1", "true", "yes"},
            trust_server_certificate=os.getenv("AZURE_SQL_TRUST_SERVER_CERTIFICATE", "no").lower()
            in {"1", "true", "yes"},
        )

    def connection_string(self) -> str:
        return ";".join(
            [
                f"Server=tcp:{self.server},1433",
                f"Database={self.database}",
                f"Authentication={self.authentication}",
                f"Encrypt={'yes' if self.encrypt else 'no'}",
                f"TrustServerCertificate={'yes' if self.trust_server_certificate else 'no'}",
            ]
        )


class AzureSqlRepository:
    def __init__(self, config: DatabaseConfig):
        if connect is None:
            raise RuntimeError("Install mssql-python before using AzureSqlRepository.")
        self.config = config

    @contextmanager
    def connection(self):
        conn = connect(self.config.connection_string())
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    @staticmethod
    def _set_actor(cursor, actor_name: str | None, actor_email: str | None, actor_ip: str | None, session_id: str | None) -> None:
        cursor.execute(
            "EXEC audit.sp_SetSessionActor @actor_name=?, @actor_email=?, @actor_ip=?, @session_id=?",
            (actor_name, actor_email, actor_ip, session_id),
        )

    def start_manual_run(self, requested_by: str, actor_name: str | None, actor_ip: str | None, session_id: str | None) -> uuid.UUID:
        with self.connection() as conn:
            cursor = conn.cursor()
            self._set_actor(cursor, actor_name, requested_by, actor_ip, session_id)
            cursor.execute(
                "DECLARE @id uniqueidentifier; EXEC ops.sp_StartIngestionRun 'MANUAL', ?, ?, ?, @id OUTPUT; SELECT @id;",
                (requested_by, actor_ip, session_id),
            )
            value = cursor.fetchone()[0]
            return uuid.UUID(str(value))

    def update_run_status(self, run_id: uuid.UUID, status: str, error_message: str | None = None) -> None:
        with self.connection() as conn:
            conn.cursor().execute("EXEC ops.sp_UpdateRunStatus ?, ?, ?", (str(run_id), status, error_message))

    def add_stage_article(self, run_id: uuid.UUID, article: dict[str, Any]) -> int:
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                DECLARE @stage_id bigint;
                EXEC ingest.sp_AddStageArticle ?,?,?,?,?,?,?,?,?,?,?,@stage_id OUTPUT;
                SELECT @stage_id;
                """,
                (
                    str(run_id),
                    article.get("raw_url"),
                    article.get("canonical_url"),
                    article.get("external_story_id"),
                    article.get("title"),
                    article.get("snippet"),
                    article.get("domain_name"),
                    article.get("source_title"),
                    article.get("feed_source"),
                    article.get("source_query"),
                    article.get("published_utc"),
                ),
            )
            return int(cursor.fetchone()[0])

    def reject_stage_article(self, stage_id: int, run_id: uuid.UUID, rejection_type: str, reason_code: str, reason_detail: str | None = None) -> None:
        with self.connection() as conn:
            conn.cursor().execute(
                "EXEC ingest.sp_RejectStageArticle ?,?,?,?,?",
                (stage_id, str(run_id), rejection_type, reason_code, reason_detail),
            )

    def upsert_article(self, stage_id: int, run_id: uuid.UUID, article: dict[str, Any]) -> tuple[int, int, str]:
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                DECLARE @article_id bigint,@story_id bigint,@result_code varchar(30);
                EXEC ingest.sp_UpsertAcceptedArticle ?,?,?,?,?,?,?,?,?,?,?,?,?,@article_id OUTPUT,@story_id OUTPUT,@result_code OUTPUT;
                SELECT @article_id,@story_id,@result_code;
                """,
                (
                    stage_id,
                    str(run_id),
                    article["canonical_url"],
                    article["story_key"],
                    article.get("external_story_id"),
                    article["title"],
                    article.get("snippet"),
                    article.get("domain_name"),
                    article.get("source_title"),
                    article.get("feed_source"),
                    article.get("source_query"),
                    article.get("published_utc"),
                    article.get("source_quality_id"),
                ),
            )
            row = cursor.fetchone()
            return int(row[0]), int(row[1]), str(row[2])

    def load_matching_reference(self) -> list[dict[str, Any]]:
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM ref.vw_ActiveCounterpartyMatchingData")
            columns = [column[0] for column in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def save_match(self, run_id: uuid.UUID, article_id: int, match: dict[str, Any]) -> int:
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                DECLARE @match_id bigint;
                EXEC risk.sp_SaveMatch ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,@match_id OUTPUT;
                SELECT @match_id;
                """,
                (
                    article_id,
                    str(run_id),
                    match["counterparty_id"],
                    match.get("alias_id"),
                    match.get("alias_text"),
                    match["match_method"],
                    match["entity_match_score"],
                    match["entity_match_band"],
                    match.get("evidence_text"),
                    match.get("token_distance"),
                    match.get("context_terms_found"),
                    bool(match.get("exclusion_triggered", False)),
                    match.get("exclusion_reason"),
                    bool(match.get("human_review_required", False)),
                    match["model_version"],
                ),
            )
            return int(cursor.fetchone()[0])

    def save_classification_and_score(self, match_id: int, result: dict[str, Any]) -> None:
        with self.connection() as conn:
            conn.cursor().execute(
                """
                EXEC risk.sp_SaveClassificationAndScore
                    ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
                """,
                (
                    match_id,
                    result["risk_theme_code"],
                    result["theme_confidence_score"],
                    result.get("theme_evidence_text"),
                    result["claim_code"],
                    result["claim_confidence_score"],
                    result.get("claim_evidence_text"),
                    bool(result["risk_term_near_entity"]),
                    bool(result["is_context_only"]),
                    result["classification_version"],
                    result["severity_score"],
                    result["confidence_score"],
                    result["source_quality_score"],
                    result["claim_strength_score"],
                    result["recency_multiplier"],
                    result["exposure_multiplier"],
                    result["raw_score"],
                    result["final_score"],
                    result["scoring_version"],
                ),
            )

    def apply_gates(self, run_id: uuid.UUID) -> None:
        with self.connection() as conn:
            conn.cursor().execute("EXEC risk.sp_ApplyHardGatesForRun ?", (str(run_id),))

    def complete_run(self, run_id: uuid.UUID, counts: dict[str, int]) -> None:
        with self.connection() as conn:
            conn.cursor().execute(
                "EXEC ops.sp_CompleteIngestionRun ?,?,?,?,?,?,?,?,?",
                (
                    str(run_id),
                    counts.get("source_rows_collected", 0),
                    counts.get("junk_rows_rejected", 0),
                    counts.get("duplicate_url_rows", 0),
                    counts.get("new_article_rows", 0),
                    counts.get("existing_article_rows", 0),
                    counts.get("new_story_rows", 0),
                    counts.get("article_rows_processed", 0),
                    counts.get("match_rows_created", 0),
                ),
            )

    def purge_expired(self) -> None:
        with self.connection() as conn:
            conn.cursor().execute("EXEC ops.sp_PurgeExpiredData")

    def refresh_status(self) -> dict[str, Any]:
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM ops.vw_RefreshStatus")
            columns = [column[0] for column in cursor.description]
            row = cursor.fetchone()
            return dict(zip(columns, row)) if row else {}

    def dashboard_items(self, category_code: str | None = None) -> list[dict[str, Any]]:
        sql = "SELECT * FROM risk.vw_DashboardItems WHERE placement_status='Active'"
        params: tuple[Any, ...] = ()
        if category_code:
            sql += " AND category_code=?"
            params = (category_code,)
        sql += " ORDER BY final_score DESC, published_utc DESC"
        with self.connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            columns = [column[0] for column in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
