from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Iterable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .repository import AzureSqlRepository


@dataclass
class RefreshResult:
    run_id: uuid.UUID
    counts: dict[str, int]


def canonicalize_url(url: str) -> str:
    parts = urlsplit((url or "").strip())
    if parts.scheme not in {"http", "https"} or not parts.netloc:
        return ""
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True) if not k.lower().startswith("utm_") and k.lower() not in {"gclid", "fbclid"}]
    path = re.sub(r"/{2,}", "/", parts.path or "/")
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), path.rstrip("/") or "/", urlencode(query), ""))


def story_key(title: str) -> str:
    value = re.sub(r"\s+", " ", (title or "").lower()).strip()
    value = re.sub(r"[^a-z0-9 ]+", "", value)
    return value[:1000]


def obvious_junk_reason(article: dict[str, Any]) -> str | None:
    title = str(article.get("title") or "").strip()
    raw_url = str(article.get("url") or article.get("raw_url") or "").strip()
    if article.get("is_error"):
        return "FEED_ERROR"
    if not title:
        return "MISSING_TITLE"
    if len(title) < 8:
        return "TITLE_TOO_SHORT"
    if not canonicalize_url(raw_url):
        return "INVALID_URL"
    if title.lower() in {"error", "not found", "access denied"}:
        return "ERROR_PAGE"
    return None


def run_manual_refresh(
    repository: AzureSqlRepository,
    requested_by: str,
    actor_name: str | None,
    actor_ip: str | None,
    session_id: str | None,
    collect_articles: Callable[[], Iterable[dict[str, Any]]],
    match_article: Callable[[dict[str, Any], list[dict[str, Any]]], Iterable[dict[str, Any]]],
    classify_and_score: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]],
) -> RefreshResult:
    repository.purge_expired()
    run_id = repository.start_manual_run(requested_by, actor_name, actor_ip, session_id)
    repository.update_run_status(run_id, "COLLECTING")
    counts = {
        "source_rows_collected": 0,
        "junk_rows_rejected": 0,
        "duplicate_url_rows": 0,
        "new_article_rows": 0,
        "existing_article_rows": 0,
        "new_story_rows": 0,
        "article_rows_processed": 0,
        "match_rows_created": 0,
    }

    try:
        reference_data = repository.load_matching_reference()
        repository.update_run_status(run_id, "PROCESSING")

        for raw in collect_articles():
            counts["source_rows_collected"] += 1
            raw_url = str(raw.get("url") or raw.get("raw_url") or "")
            article = {
                "raw_url": raw_url,
                "canonical_url": canonicalize_url(raw_url),
                "external_story_id": raw.get("external_story_id"),
                "title": str(raw.get("title") or "").strip(),
                "snippet": raw.get("snippet"),
                "domain_name": raw.get("domain") or raw.get("domain_name"),
                "source_title": raw.get("source_title"),
                "feed_source": raw.get("feed_source"),
                "source_query": raw.get("query") or raw.get("source_query"),
                "published_utc": raw.get("published_at") or raw.get("published_utc"),
                "source_quality_id": raw.get("source_quality_id"),
            }
            stage_id = repository.add_stage_article(run_id, article)
            junk_reason = obvious_junk_reason(raw)
            if junk_reason:
                repository.reject_stage_article(stage_id, run_id, "JUNK", junk_reason)
                counts["junk_rows_rejected"] += 1
                continue

            article["story_key"] = story_key(article["title"])
            article_id, _, result_code = repository.upsert_article(stage_id, run_id, article)
            if result_code.startswith("NEW_ARTICLE"):
                counts["new_article_rows"] += 1
                if result_code == "NEW_ARTICLE_NEW_STORY":
                    counts["new_story_rows"] += 1
            else:
                counts["existing_article_rows"] += 1
                counts["duplicate_url_rows"] += 1
                continue

            counts["article_rows_processed"] += 1
            for match in match_article(article, reference_data):
                match_id = repository.save_match(run_id, article_id, match)
                result = classify_and_score(article, match)
                repository.save_classification_and_score(match_id, result)
                counts["match_rows_created"] += 1

        repository.apply_gates(run_id)
        repository.complete_run(run_id, counts)
        repository.purge_expired()
        return RefreshResult(run_id=run_id, counts=counts)
    except Exception as exc:
        repository.update_run_status(run_id, "FAILED", str(exc)[:4000])
        raise
