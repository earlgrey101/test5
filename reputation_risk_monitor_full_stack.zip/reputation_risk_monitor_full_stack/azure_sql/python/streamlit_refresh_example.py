from __future__ import annotations

import os
import uuid

import pandas as pd
import streamlit as st

from .repository import AzureSqlRepository, DatabaseConfig
from .refresh_pipeline import run_manual_refresh


def get_repository() -> AzureSqlRepository:
    return AzureSqlRepository(DatabaseConfig.from_env())


def render_refresh_status(repository: AzureSqlRepository) -> None:
    status = repository.refresh_status()
    columns = st.columns(4)
    columns[0].metric("Articles stored", status.get("article_count_stored", 0) or 0)
    columns[1].metric("Processed this run", status.get("article_count_processed_last_run", 0) or 0)
    columns[2].metric("New this run", status.get("new_article_count_last_run", 0) or 0)
    columns[3].metric("Last refresh UTC", status.get("last_refresh_utc") or "Not yet refreshed")


def render_manual_refresh(
    collect_articles,
    match_article,
    classify_and_score,
    actor_name: str,
    actor_email: str,
    actor_ip: str | None,
) -> None:
    repository = get_repository()
    render_refresh_status(repository)
    if st.button("Refresh live articles", type="primary"):
        with st.spinner("Collecting and processing articles"):
            result = run_manual_refresh(
                repository=repository,
                requested_by=actor_email,
                actor_name=actor_name,
                actor_ip=actor_ip,
                session_id=str(uuid.uuid4()),
                collect_articles=collect_articles,
                match_article=match_article,
                classify_and_score=classify_and_score,
            )
        st.success(f"Refresh completed. {result.counts['article_rows_processed']} articles were processed.")
        st.rerun()


def load_dashboard_items(category_code: str | None = None) -> pd.DataFrame:
    return pd.DataFrame(get_repository().dashboard_items(category_code))
