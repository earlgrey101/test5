External counterparty risk monitor

Run locally on Windows

1. Double click install_requirements.bat once.
2. Double click start_dashboard.bat.
3. Open http://localhost:8501 if it does not open automatically.

Manual run

py -m pip install -r requirements.txt
py -m streamlit run app.py

This version keeps the portfolio matching, audit trail, email recipient controls, and local data files. The visual layer uses a pale blue background, black text, PayPal blue accents, and Google Material Symbols.

Navigation has been moved from the left sidebar to a top banner. Hold over the Menu button on the top right for about one second to open the dropdown. User and matching settings are now inside the Settings page.


Updated palette: #008CFF, #60CDFF, #002991, #949494, #BFBFBF, and black.
