
from __future__ import annotations

from pathlib import Path
from urllib.parse import quote, unquote

import pandas as pd
import streamlit as st
import yaml

from admin_store import (
    add_alias,
    add_counterparty,
    deactivate_alias,
    deactivate_counterparty,
    initialize_email_files,
    load_change_log,
    reactivate_counterparty,
)
from audit_store import (
    DEFAULT_RETENTION_DAYS,
    initialize_audit_files,
    load_audit_log,
    load_retention_log,
    log_event,
    purge_expired_records,
    retention_summary,
    utc_now_iso,
)
from email_manager import (
    active_recipients,
    add_recipient,
    compose_priority_email,
    deactivate_recipient,
    load_email_log,
    load_email_settings,
    load_recipients,
    save_email_setting,
    send_priority_email,
    smtp_ready,
)
from entity_matcher import load_portfolio_data, match_articles_to_counterparties
from portfolio_engine import portfolio_summary, score_portfolio_matches
from risk_appetite import threshold_summary

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

BRAND_DARK = "#002991"
BRAND = "#008CFF"
BRAND_LIGHT = "#60CDFF"
NEUTRAL = "#949494"
LINE_GRAY = "#BFBFBF"
BLACK = "#000000"
BG = "#F4FBFF"

PAGES = [
    "Overview",
    "Current items",
    "Counterparty portfolio",
    "Alias review",
    "Match testing",
    "Priority email",
    "Settings",
]

PAGE_ICONS = {
    "Overview": "dashboard",
    "Current items": "rule_settings",
    "Counterparty portfolio": "account_balance",
    "Alias review": "badge",
    "Match testing": "join_inner",
    "Priority email": "mail",
    "Settings": "tune",
}


@st.cache_data(show_spinner=False)
def load_config() -> dict:
    with open(BASE_DIR / "config_phase1.yaml", "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@st.cache_data(show_spinner=False)
def load_articles() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "sample_articles.csv")


@st.cache_data(show_spinner=False)
def load_portfolio() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    return load_portfolio_data(DATA_DIR)


@st.cache_data(show_spinner=False)
def run_portfolio_pipeline(context_window: int, token_window: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    cfg = load_config()
    cfg = dict(cfg)
    cfg.setdefault("scoring", {})["token_window"] = int(token_window)
    articles = load_articles()
    counterparties, aliases, exclusions = load_portfolio()
    matches, hit_detail = match_articles_to_counterparties(
        articles,
        counterparties,
        aliases,
        exclusions,
        context_window=int(context_window),
    )
    scored = score_portfolio_matches(articles, matches, counterparties, aliases, cfg)
    return articles, counterparties, aliases, exclusions, scored, {"matches": matches, "hit_detail": hit_detail, "cfg": cfg}


def refresh_data() -> None:
    st.cache_data.clear()
    st.rerun()


def get_client_ip_hint() -> str:
    try:
        ctx = getattr(st, "context", None)
        headers = getattr(ctx, "headers", None) if ctx is not None else None
        if headers:
            for key in ["X-Forwarded-For", "X-Real-IP", "Forwarded", "CF-Connecting-IP"]:
                value = headers.get(key) if hasattr(headers, "get") else None
                if value:
                    return str(value).split(",")[0].strip()
    except Exception:
        pass
    return "Unavailable locally"


def actor_context() -> dict:
    if "audit_session_id" not in st.session_state:
        st.session_state["audit_session_id"] = utc_now_iso().replace(":", "").replace("-", "").replace("+", "Z")
    return {
        "actor_name": st.session_state.get("audit_actor_name", "Local user"),
        "actor_email": st.session_state.get("audit_actor_email", ""),
        "ip_address": st.session_state.get("audit_ip_address", get_client_ip_hint()),
        "session_id": st.session_state.get("audit_session_id", ""),
    }


def log_setting_change_if_needed(setting_key: str, value, label: str) -> None:
    state_key = f"audit_setting_previous_{setting_key}"
    old_value = st.session_state.get(state_key, None)
    new_value = str(value)
    if old_value is None:
        st.session_state[state_key] = new_value
        return
    if str(old_value) != new_value:
        log_event(
            DATA_DIR,
            actor_context(),
            "settings_change",
            "matching_settings",
            f"Changed {label}",
            "setting",
            setting_key,
            label,
            "Matching setting updated from the sidebar.",
            str(old_value),
            new_value,
        )
        st.session_state[state_key] = new_value


def icon(name: str) -> str:
    icons = {
        "overview": "dashboard",
        "items": "rule_settings",
        "portfolio": "account_balance",
        "alias": "badge",
        "match": "join_inner",
        "settings": "tune",
        "shield": "verified_user",
        "mail": "mail",
        "person": "person",
        "audit": "history",
        "search": "search",
        "filter": "filter_alt",
        "download": "download",
        "add": "add_circle",
        "remove": "remove_circle",
        "restore": "restore",
        "warning": "warning",
        "check": "check_circle",
    }
    material_name = icons.get(name, icons["overview"])
    return f'<span class="google-icon material-symbols-outlined" aria-hidden="true">{material_name}</span>'


def set_style() -> None:
    st.markdown(
        f"""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,300,0,0&display=swap');
        :root {{
            --bg: {BG};
            --panel: #FFFFFF;
            --panel-soft: #FFFFFF;
            --brand-dark: {BRAND_DARK};
            --brand: {BRAND};
            --brand-light: {BRAND_LIGHT};
            --black: {BLACK};
            --muted: {NEUTRAL};
            --line: {LINE_GRAY};
            --line-soft: #D9D9D9;
        }}
        html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stHeader"], .main, .block-container {{
            background: var(--bg) !important;
            color: var(--black) !important;
            font-family: Arial, Helvetica, sans-serif !important;
        }}
        .block-container {{
            padding-top: 5.25rem !important;
            max-width: 1420px !important;
        }}
        h1, h2, h3, h4, h5, h6, .page-title, .section-title, .metric-value, .metric-label, .subhead {{
            font-family: Arial, Helvetica, sans-serif !important;
            font-weight: 700 !important;
            color: var(--black) !important;
            letter-spacing: -0.01em;
        }}
        p, div, span, label, input, button, textarea, select, option, [data-testid="stMarkdownContainer"] {{
            font-family: Arial, Helvetica, sans-serif !important;
            color: var(--black) !important;
        }}
        em, i, u, a {{
            font-style: normal !important;
            text-decoration: none !important;
        }}
        .hero {{
            background: var(--panel);
            border: 1px solid var(--line);
            border-top: 5px solid var(--brand-dark);
            padding: 1.25rem 1.35rem;
            margin-bottom: 1rem;
        }}
        .page-title {{
            font-size: 2rem;
            line-height: 1.12;
            margin-bottom: 0.35rem;
        }}
        .page-subtitle {{
            color: var(--muted) !important;
            font-size: 1rem;
            line-height: 1.45;
            max-width: 1050px;
        }}
        .section-row {{
            display: flex;
            align-items: center;
            gap: 0.55rem;
            margin-top: 1rem;
            margin-bottom: 0.65rem;
            padding-bottom: 0.35rem;
            border-bottom: 2px solid var(--line);
        }}
        .google-icon {{
            font-family: 'Material Symbols Outlined' !important;
            font-weight: normal !important;
            font-style: normal !important;
            font-size: 21px !important;
            line-height: 1 !important;
            letter-spacing: normal !important;
            text-transform: none !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            color: #000000 !important;
            font-variation-settings: 'FILL' 0, 'wght' 300, 'GRAD' 0, 'opsz' 24;
            -webkit-font-feature-settings: 'liga' !important;
            -webkit-font-smoothing: antialiased !important;
            user-select: none;
            flex: 0 0 auto;
        }}
        .section-row .google-icon, .card-icon .google-icon {{
            width: 22px;
            height: 22px;
        }}
        .section-title {{
            font-size: 1.24rem;
        }}
        .card-grid {{
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 0.85rem;
            margin: 0.8rem 0 1rem 0;
        }}
        .metric-card {{
            background: var(--panel);
            border: 1px solid var(--line);
            border-top: 4px solid var(--brand);
            padding: 0.9rem 1rem;
            min-height: 118px;
        }}
        .metric-card.dark {{ border-top-color: var(--brand-dark); }}
        .metric-label {{
            font-size: 0.94rem;
            line-height: 1.25;
        }}
        .metric-value {{
            color: var(--brand-dark) !important;
            font-size: 1.85rem;
            margin-top: 0.2rem;
            line-height: 1.0;
        }}
        .metric-caption {{
            color: var(--muted) !important;
            font-size: 0.86rem;
            margin-top: 0.35rem;
            line-height: 1.25;
        }}
        .explain-grid {{
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 0.85rem;
            margin-bottom: 0.8rem;
        }}
        .explain-card {{
            background: var(--panel-soft);
            border: 1px solid var(--line-soft);
            padding: 0.85rem 0.95rem;
            line-height: 1.42;
        }}
        .subhead {{ margin-bottom: 0.25rem; }}
        div[data-testid="stSidebar"] {{
            background: #FFFFFF !important;
            border-right: 1px solid var(--line) !important;
        }}
        .stButton button, .stDownloadButton button {{
            background: var(--brand) !important;
            color: #FFFFFF !important;
            border: 1px solid var(--brand-dark) !important;
            border-radius: 0 !important;
            font-weight: 700 !important;
        }}
        div[data-baseweb="select"] > div, div[data-baseweb="input"] > div, textarea {{
            border-radius: 0 !important;
            border-color: var(--line) !important;
        }}
        .dataframe, [data-testid="stDataFrame"] {{
            font-family: Arial, Helvetica, sans-serif !important;
        }}

        *, *::before, *::after {{
            box-shadow: none !important;
            text-shadow: none !important;
        }}
        .material-symbols-rounded, .material-icons, .material-symbols-outlined,
        span[class*="material"], i[class*="material"], [class*="material-symbols"] {{
            font-family: "Material Symbols Outlined", "Material Symbols Rounded", "Material Icons" !important;
            font-weight: normal !important;
            font-style: normal !important;
            font-size: 20px !important;
            line-height: 1 !important;
            letter-spacing: normal !important;
            text-transform: none !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            color: #000000 !important;
            font-variation-settings: "FILL" 0, "wght" 300, "GRAD" 0, "opsz" 24;
            -webkit-font-feature-settings: "liga" !important;
            -webkit-font-smoothing: antialiased !important;
        }}
        div[data-testid="stToolbar"], div[data-testid="stDecoration"] {{
            visibility: hidden !important;
            height: 0 !important;
        }}
        div[data-baseweb="tab-list"] {{
            gap: 0.35rem !important;
            border-bottom: 1px solid var(--line) !important;
        }}
        button[data-baseweb="tab"] {{
            background: #FFFFFF !important;
            border: 1px solid var(--line) !important;
            border-bottom: none !important;
            border-radius: 0 !important;
            color: var(--black) !important;
            font-family: Arial, Helvetica, sans-serif !important;
            font-weight: 700 !important;
        }}
        button[data-baseweb="tab"][aria-selected="true"] {{
            border-top: 4px solid var(--brand-dark) !important;
            color: var(--brand-dark) !important;
        }}
        div[data-testid="stExpander"] {{
            border: 1px solid var(--line) !important;
            border-radius: 0 !important;
            background: #FFFFFF !important;
        }}
        [data-testid="stMetric"], [data-testid="stDataFrame"], [data-testid="stTable"], .stAlert {{
            border-radius: 0 !important;
            box-shadow: none !important;
        }}
        [data-testid="stDataFrame"] div, [data-testid="stDataFrame"] span {{
            font-family: Arial, Helvetica, sans-serif !important;
        }}
        .sidebar-label {{
            font-family: Arial, Helvetica, sans-serif !important;
            font-weight: 700 !important;
            color: var(--brand-dark) !important;
            border-top: 1px solid var(--line-soft);
            padding-top: 0.75rem;
            margin-top: 0.75rem;
            margin-bottom: 0.35rem;
        }}

        [data-testid="stSidebar"], [data-testid="collapsedControl"] {{
            display: none !important;
        }}
        .top-banner {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 66px;
            background: var(--brand-dark);
            border-bottom: 1px solid var(--brand-dark);
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 1.25rem;
        }}
        .top-title-wrap {{
            display: flex;
            align-items: center;
            gap: 0.7rem;
        }}
        .top-title-icon {{
            width: 34px;
            height: 34px;
            border: 1px solid var(--brand-light);
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--brand-dark);
        }}
        .top-title-icon .google-icon, .top-menu-button .google-icon {{
            color: #FFFFFF !important;
        }}
        .top-title {{
            font-family: Arial, Helvetica, sans-serif !important;
            font-size: 1.25rem;
            font-weight: 700 !important;
            color: #FFFFFF !important;
            line-height: 1.1;
        }}
        .top-subtitle {{
            color: var(--brand-light) !important;
            font-size: 0.78rem;
            margin-top: 0.12rem;
        }}
        .top-menu-zone {{
            position: relative;
            min-width: 220px;
            display: flex;
            justify-content: flex-end;
            padding: 0.45rem 0;
        }}
        .top-menu-button {{
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
            border: 1px solid var(--brand-light);
            background: var(--brand-dark);
            color: #FFFFFF !important;
            padding: 0.55rem 0.75rem;
            font-weight: 700 !important;
            cursor: default;
        }}
        .top-menu-panel {{
            position: absolute;
            top: 100%;
            right: 0;
            min-width: 265px;
            background: #FFFFFF;
            border: 1px solid var(--line);
            padding: 0.35rem;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-4px);
            transition: opacity 140ms ease 750ms, transform 140ms ease 750ms, visibility 0s linear 890ms;
            z-index: 1000000;
        }}
        .top-menu-zone:hover .top-menu-panel, .top-menu-zone:focus-within .top-menu-panel {{
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
            transition-delay: 750ms, 750ms, 0s;
        }}
        .top-menu-link {{
            display: flex;
            align-items: center;
            gap: 0.55rem;
            padding: 0.62rem 0.7rem;
            border-left: 3px solid transparent;
            color: var(--black) !important;
            font-weight: 700 !important;
        }}
        .top-menu-link:hover {{
            background: #F4FBFF;
            border-left-color: var(--brand);
        }}
        .top-menu-link.active {{
            background: #EAF8FF;
            border-left-color: var(--brand-dark);
            color: var(--brand-dark) !important;
        }}
        .top-menu-note {{
            border-top: 1px solid var(--line-soft);
            margin-top: 0.25rem;
            padding: 0.55rem 0.7rem 0.35rem 0.7rem;
            color: var(--muted) !important;
            font-size: 0.78rem;
            line-height: 1.25;
        }}

        @media (max-width: 980px) {{
            .card-grid, .explain-grid {{ grid-template-columns: 1fr; }}
            .top-subtitle {{ display: none; }}
            .top-title-icon .google-icon, .top-menu-button .google-icon {{
            color: #FFFFFF !important;
        }}
        .top-title {{ font-size: 1rem; }}
            .top-menu-zone {{ min-width: 130px; }}
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def page_from_query() -> str:
    try:
        value = st.query_params.get("page", "Overview")
        if isinstance(value, list):
            value = value[0] if value else "Overview"
        value = unquote(str(value))
        return value if value in PAGES else "Overview"
    except Exception:
        return "Overview"


def render_top_banner(current_page: str) -> None:
    links = []
    for page_name in PAGES:
        active = " active" if page_name == current_page else ""
        links.append(
            f'<a class="top-menu-link{active}" href="?page={quote(page_name)}">{icon(PAGE_ICONS.get(page_name, "overview"))}<span>{page_name}</span></a>'
        )
    menu_html = "".join(links)
    st.markdown(
        f'''<div class="top-banner">
            <div class="top-title-wrap">
                <div class="top-title-icon">{icon("shield")}</div>
                <div>
                    <div class="top-title">External counterparty risk monitor</div>
                    <div class="top-subtitle">Portfolio review, matching, email controls, and audit tracking</div>
                </div>
            </div>
            <div class="top-menu-zone" tabindex="0">
                <div class="top-menu-button">{icon("settings")}<span>Menu</span></div>
                <div class="top-menu-panel">
                    {menu_html}
                    <div class="top-menu-note">Hold over this area for about one second to open the menu.</div>
                </div>
            </div>
        </div>''',
        unsafe_allow_html=True,
    )

def section(title: str, icon_name: str = "overview") -> None:
    st.markdown(f'<div class="section-row">{icon(icon_name)}<div class="section-title">{title}</div></div>', unsafe_allow_html=True)


def metric_card(label: str, value: object, caption: str, icon_name: str = "overview", dark: bool = False) -> str:
    cls = "metric-card dark" if dark else "metric-card"
    return f"""
    <div class="{cls}">
        <div class="card-icon">{icon(icon_name)}</div>
        <div class="metric-label">{label}</div>
        <div class="metric-value">{value}</div>
        <div class="metric-caption">{caption}</div>
    </div>
    """


def cards(items: list[tuple[str, object, str, str, bool]]) -> None:
    html = '<div class="card-grid">' + "".join(metric_card(*x) for x in items) + "</div>"
    st.markdown(html, unsafe_allow_html=True)


def table(df: pd.DataFrame, columns: dict[str, str], height: int = 360) -> None:
    if df is None or df.empty:
        st.info("No rows to display.")
        return
    visible = [c for c in columns if c in df.columns]
    out = df[visible].rename(columns=columns)
    st.dataframe(out, use_container_width=True, height=height, hide_index=True)


def download_button(df: pd.DataFrame, label: str, file_name: str) -> None:
    if df is not None and not df.empty:
        st.download_button(label, data=df.to_csv(index=False), file_name=file_name, mime="text/csv")


def placement_counts(scored: pd.DataFrame) -> dict[str, int]:
    if scored is None or scored.empty:
        return {"Priority items": 0, "Review items": 0, "Reference items": 0}
    return {k: int(scored["review_bucket"].eq(k).sum()) for k in ["Priority items", "Review items", "Reference items"]}


def status_sentence(scored: pd.DataFrame, counterparties: pd.DataFrame, matches: pd.DataFrame) -> str:
    counts = placement_counts(scored)
    matched = matches["counterparty_id"].nunique() if matches is not None and not matches.empty else 0
    total = len(counterparties)
    if counts["Priority items"] > 0:
        return f"{counts['Priority items']} item needs attention across the current matched sample. {matched} of {total} counterparties matched at least one article."
    return f"No item meets the top attention level in the current sample. {matched} of {total} counterparties matched at least one article."


def theme_options(cfg: dict) -> list[str]:
    raw = cfg.get("risk_terms", {}) or {}
    return sorted([k.replace("_", " ").title() for k in raw.keys()])


def apply_theme_filter(df: pd.DataFrame, theme: str) -> pd.DataFrame:
    if theme == "All" or df is None or df.empty or "themes" not in df.columns:
        return df
    return df[df["themes"].astype(str).str.contains(theme, case=False, na=False)]


def search_counterparty_frame(df: pd.DataFrame, query: str) -> pd.DataFrame:
    if not query:
        return df
    q = query.strip().lower()
    mask = pd.Series(False, index=df.index)
    for col in ["counterparty_id", "legal_name", "common_name", "ticker", "counterparty_type_guess", "country_guess"]:
        if col in df.columns:
            mask = mask | df[col].astype(str).str.lower().str.contains(q, na=False)
    return df[mask]


def overview_page(counterparties, aliases, exclusions, matches, scored, hit_detail) -> None:
    st.markdown(
        f"""
        <div class="hero">
            <div class="page-title">External counterparty risk monitor</div>
            <div class="page-subtitle">This dashboard checks public article signals against the counterparty master list, applies alias and exclusion rules, scores only matched rows, and separates priority items from review and reference rows.</div>
            <div class="page-subtitle" style="margin-top:.6rem;color:{BRAND_DARK}!important;font-weight:700!important;">{status_sentence(scored, counterparties, matches)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    counts = placement_counts(scored)
    matched_count = matches["counterparty_id"].nunique() if matches is not None and not matches.empty else 0
    active_count = int(counterparties["active_status"].astype(str).str.lower().eq("active").sum()) if not counterparties.empty and "active_status" in counterparties else len(counterparties)
    recipients = active_recipients(DATA_DIR)
    cards([
        ("Active counterparties", active_count, "Counterparties currently included in matching.", "portfolio", True),
        ("Matched counterparties", matched_count, "Counterparties with at least one matched article in the sample data.", "match", False),
        ("Priority items", counts["Priority items"], "Rows passing the source, claim, match, and score checks.", "shield", True),
        ("Email recipients", len(recipients), "Active internal recipients for priority item email previews or sends.", "mail", False),
    ])
    st.markdown(
        """
        <div class="explain-grid">
            <div class="explain-card"><div class="subhead">Portfolio coverage</div>The dashboard uses the counterparty file, alias file, and exclusion file before scoring any article.</div>
            <div class="explain-card"><div class="subhead">Editable master list</div>Counterparties and aliases can be added or removed in the dashboard. Remove actions set records inactive to keep a local change trail.</div>
            <div class="explain-card"><div class="subhead">Controlled emails</div>Priority item emails are BCC only and recipient addresses must end in @paypal.com. The default mode is preview only unless SMTP is configured.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    section("Top rows to review first", "items")
    top = scored.sort_values("overall_priority_score", ascending=False).head(12) if scored is not None and not scored.empty else pd.DataFrame()
    table(top, {
        "review_bucket": "Placement",
        "counterparty_name": "Counterparty",
        "themes": "Risk theme",
        "entity_match_confidence": "Match confidence",
        "overall_priority_score": "Score",
        "source_name": "Source",
        "claim_status": "Claim status",
        "title": "Article",
        "placement_explanation": "Reason",
    }, height=420)
    section("Portfolio health check", "portfolio")
    summary = portfolio_summary(counterparties, aliases, exclusions, matches, scored)
    table(summary, {"metric": "Metric", "value": "Value", "explanation": "What it means"}, height=360)


def current_items_page(scored, cfg) -> None:
    section("Current items", "items")
    if scored is None or scored.empty:
        st.info("No matched rows were scored.")
        return
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        bucket = st.selectbox("Placement", ["All", "Priority items", "Review items", "Reference items"])
    with col2:
        counterparties = ["All"] + sorted(scored["counterparty_name"].dropna().unique().tolist())
        counterparty = st.selectbox("Counterparty", counterparties)
    with col3:
        confidence = st.selectbox("Match confidence", ["All", "High", "Medium", "Low"])
    with col4:
        theme = st.selectbox("Risk theme", ["All"] + theme_options(cfg))
    query = st.text_input("Search current item text", placeholder="Search by source, article, counterparty, claim, or reason")
    df = scored.copy()
    if bucket != "All":
        df = df[df["review_bucket"] == bucket]
    if counterparty != "All":
        df = df[df["counterparty_name"] == counterparty]
    if confidence != "All":
        df = df[df["entity_match_confidence"] == confidence]
    df = apply_theme_filter(df, theme)
    if query:
        q = query.lower().strip()
        searchable = df[[c for c in ["title", "source_name", "counterparty_name", "claim_status", "gate_failure_reasons", "themes"] if c in df.columns]].astype(str).agg(" ".join, axis=1).str.lower()
        df = df[searchable.str.contains(q, na=False)]
    table(df.sort_values("overall_priority_score", ascending=False), {
        "review_bucket": "Placement",
        "counterparty_name": "Counterparty",
        "alias_matched": "Alias matched",
        "entity_match_confidence": "Match confidence",
        "overall_priority_score": "Score",
        "initial_signal_band": "Signal level",
        "source_name": "Source",
        "source_category": "Source quality",
        "claim_status": "Claim status",
        "themes": "Risk theme",
        "gate_failure_reasons": "Why not priority",
        "title": "Article",
    }, height=560)
    download_button(df, "Download current items", "current_items.csv")


def portfolio_page(counterparties, aliases, matches, scored) -> None:
    section("Counterparty portfolio", "portfolio")
    tab_search, tab_add, tab_remove, tab_log = st.tabs(["Search", "Add", "Remove or restore", "Change log"])
    matched_counts = matches.groupby("counterparty_id").size().rename("matched_article_rows") if matches is not None and not matches.empty else pd.Series(dtype=int)
    scored_counts = scored.groupby("counterparty_id")["review_bucket"].value_counts().unstack(fill_value=0) if scored is not None and not scored.empty else pd.DataFrame()
    df = counterparties.copy()
    df["alias_count"] = aliases.groupby("counterparty_id").size().reindex(df["counterparty_id"]).fillna(0).astype(int).values
    df["matched_article_rows"] = df["counterparty_id"].map(matched_counts).fillna(0).astype(int)
    for bucket in ["Priority items", "Review items", "Reference items"]:
        if bucket in scored_counts.columns:
            df[bucket] = df["counterparty_id"].map(scored_counts[bucket]).fillna(0).astype(int)
        else:
            df[bucket] = 0
    with tab_search:
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            search = st.text_input("Search coded counterparties", placeholder="Name, ticker, ID, type, country")
        with col2:
            status = st.selectbox("Status", ["All", "Active", "Inactive"])
        with col3:
            risk_level = st.selectbox("Match risk", ["All"] + sorted(df["match_risk_level"].dropna().unique().tolist()))
        with col4:
            only_matched = st.checkbox("Only show article matches", value=False)
        out = search_counterparty_frame(df, search)
        if status != "All":
            out = out[out["active_status"].astype(str).str.lower() == status.lower()]
        if risk_level != "All":
            out = out[out["match_risk_level"] == risk_level]
        if only_matched:
            out = out[out["matched_article_rows"] > 0]
        table(out.sort_values(["Priority items", "Review items", "matched_article_rows"], ascending=False), {
            "counterparty_id": "ID",
            "active_status": "Status",
            "legal_name": "Legal name",
            "common_name": "Common name",
            "ticker": "Ticker",
            "counterparty_type_guess": "Type",
            "country_guess": "Country",
            "alias_count": "Aliases",
            "matched_article_rows": "Matched rows",
            "Priority items": "Priority",
            "Review items": "Review",
            "Reference items": "Reference",
            "match_risk_level": "Match risk",
            "alias_review_required": "Alias review",
        }, height=560)
        download_button(out, "Download portfolio view", "portfolio_view.csv")
    with tab_add:
        st.markdown("Add a new counterparty to the local master list. A legal-name alias is created automatically. Add extra aliases if the entity is known by other names.")
        with st.form("add_counterparty_form"):
            c1, c2 = st.columns(2)
            legal_name = c1.text_input("Legal name")
            common_name = c2.text_input("Common name")
            c3, c4, c5 = st.columns(3)
            ticker = c3.text_input("Ticker if public")
            ticker_exchange_hint = c4.text_input("Exchange hint")
            country_guess = c5.text_input("Country")
            c6, c7 = st.columns(2)
            counterparty_type_guess = c6.text_input("Counterparty type")
            match_risk_level = c7.selectbox("Match risk level", ["Low", "Medium", "High"], index=1)
            extra_aliases = st.text_area("Known subsidiary, brand, or alias names", placeholder="Separate with semicolons")
            dangerous_short_aliases = st.text_input("Dangerous short aliases", placeholder="Optional")
            do_not_match_terms = st.text_input("Do not match terms", placeholder="Optional")
            notes = st.text_area("Notes")
            submitted = st.form_submit_button("Add counterparty")
        if submitted:
            if not legal_name.strip():
                st.error("Legal name is required.")
            else:
                new_id = add_counterparty(DATA_DIR, {
                    "legal_name": legal_name,
                    "common_name": common_name,
                    "ticker": ticker,
                    "ticker_exchange_hint": ticker_exchange_hint,
                    "country_guess": country_guess,
                    "counterparty_type_guess": counterparty_type_guess,
                    "match_risk_level": match_risk_level,
                    "extra_aliases": extra_aliases,
                    "dangerous_short_aliases": dangerous_short_aliases,
                    "do_not_match_terms": do_not_match_terms,
                    "notes": notes,
                })
                log_event(DATA_DIR, actor_context(), "counterparty_change", "counterparty_portfolio", "Added counterparty", "counterparty", new_id, legal_name, f"Manual add with match risk {match_risk_level}", "", legal_name)
                st.success(f"Added counterparty {new_id}.")
                refresh_data()
    with tab_remove:
        search = st.text_input("Find counterparty to remove or restore", key="remove_search")
        candidates = search_counterparty_frame(counterparties, search)
        label_map = {f"{row.counterparty_id} | {row.legal_name} | {row.active_status}": row.counterparty_id for _, row in candidates.iterrows()}
        if label_map:
            selected = st.selectbox("Counterparty", list(label_map.keys()))
            cp_id = label_map[selected]
            c1, c2 = st.columns(2)
            if c1.button("Remove from active monitoring"):
                deactivate_counterparty(DATA_DIR, cp_id)
                log_event(DATA_DIR, actor_context(), "counterparty_change", "counterparty_portfolio", "Removed from active monitoring", "counterparty", cp_id, selected, "Counterparty and related aliases/exclusions set inactive.", "Active", "Inactive")
                st.success("Counterparty removed from active monitoring.")
                refresh_data()
            if c2.button("Restore to active monitoring"):
                reactivate_counterparty(DATA_DIR, cp_id)
                log_event(DATA_DIR, actor_context(), "counterparty_change", "counterparty_portfolio", "Restored to active monitoring", "counterparty", cp_id, selected, "Counterparty set active.", "Inactive", "Active")
                st.success("Counterparty restored.")
                refresh_data()
        else:
            st.info("No matching counterparty found.")
    with tab_log:
        log = load_change_log(DATA_DIR)
        table(log.sort_values("changed_at", ascending=False) if not log.empty else log, {
            "changed_at": "Changed at",
            "action": "Action",
            "counterparty_id": "Counterparty ID",
            "counterparty_name": "Counterparty",
            "detail": "Detail",
        }, height=520)


def alias_page(counterparties, aliases, exclusions) -> None:
    section("Alias review", "alias")
    tab_view, tab_add, tab_remove, tab_exclusions = st.tabs(["Search aliases", "Add alias", "Remove alias", "Exclusions"])
    with tab_view:
        st.markdown("Use this page to identify aliases that could create false matches before enabling broader public monitoring.")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            alias_search = st.text_input("Search aliases", placeholder="Alias, ID, notes")
        with col2:
            requires_context = st.selectbox("Requires context", ["All", "Yes", "No"])
        with col3:
            dangerous = st.selectbox("Dangerous short alias", ["All", "Yes", "No"])
        with col4:
            active = st.selectbox("Alias status", ["All", "Active", "Inactive"])
        df = aliases.copy()
        if alias_search:
            q = alias_search.lower().strip()
            searchable = df.astype(str).agg(" ".join, axis=1).str.lower()
            df = df[searchable.str.contains(q, na=False)]
        if requires_context != "All":
            df = df[df["requires_context"].astype(str).str.lower() == requires_context.lower()]
        if dangerous != "All":
            df = df[df["dangerous_short_alias"].astype(str).str.lower() == dangerous.lower()]
        if active != "All":
            df = df[df["active_status"].astype(str).str.lower() == active.lower()]
        table(df, {
            "alias_id": "Alias ID",
            "counterparty_id": "Counterparty ID",
            "alias_text": "Alias",
            "alias_category": "Alias type",
            "match_strength": "Strength",
            "requires_context": "Requires context",
            "dangerous_short_alias": "Dangerous short alias",
            "active_status": "Status",
            "review_status": "Review status",
            "notes": "Notes",
        }, height=500)
        download_button(df, "Download aliases", "aliases_filtered.csv")
    with tab_add:
        st.markdown("Add aliases only for counterparties already in the master list.")
        active_cps = counterparties[counterparties["active_status"].astype(str).str.lower() == "active"].copy()
        cp_labels = {f"{row.counterparty_id} | {row.legal_name}": row.counterparty_id for _, row in active_cps.iterrows()}
        with st.form("add_alias_form"):
            selected = st.selectbox("Counterparty", list(cp_labels.keys())) if cp_labels else None
            alias_text = st.text_input("Alias text")
            c1, c2, c3 = st.columns(3)
            alias_category = c1.selectbox("Alias type", ["legal_name_variant", "common_name", "ticker", "known_brand_or_subsidiary", "abbreviation", "former_name"])
            match_strength = c2.selectbox("Match strength", ["Strong", "Medium", "Weak"], index=1)
            requires_context = c3.selectbox("Requires business context", ["No", "Yes"], index=1)
            dangerous_short_alias = st.selectbox("Dangerous short alias", ["No", "Yes"], index=1 if len(alias_text.strip()) <= 4 and alias_text.strip() else 0)
            notes = st.text_input("Notes")
            submitted = st.form_submit_button("Add alias")
        if submitted:
            if not selected or not alias_text.strip():
                st.error("Choose a counterparty and enter an alias.")
            else:
                alias_id = add_alias(DATA_DIR, cp_labels[selected], alias_text, alias_category, match_strength, requires_context == "Yes", dangerous_short_alias == "Yes", notes)
                log_event(DATA_DIR, actor_context(), "alias_change", "alias_review", "Added alias", "alias", alias_id, alias_text, f"Alias added for {selected}", "", alias_text)
                st.success(f"Added alias {alias_id}.")
                refresh_data()
    with tab_remove:
        q = st.text_input("Find alias to remove", key="alias_remove_search")
        df = aliases.copy()
        if q:
            searchable = df.astype(str).agg(" ".join, axis=1).str.lower()
            df = df[searchable.str.contains(q.lower().strip(), na=False)]
        alias_labels = {f"{row.alias_id} | {row.alias_text} | {row.counterparty_id} | {row.active_status}": row.alias_id for _, row in df.iterrows()}
        if alias_labels:
            selected = st.selectbox("Alias", list(alias_labels.keys()))
            if st.button("Remove alias from active matching"):
                deactivate_alias(DATA_DIR, alias_labels[selected])
                log_event(DATA_DIR, actor_context(), "alias_change", "alias_review", "Removed alias from active matching", "alias", alias_labels[selected], selected, "Alias set inactive.", "Active", "Inactive")
                st.success("Alias removed from active matching.")
                refresh_data()
        else:
            st.info("No alias found.")
    with tab_exclusions:
        table(exclusions, {
            "counterparty_id": "Counterparty ID",
            "alias_text": "Alias",
            "do_not_match_terms": "Do not match terms",
            "require_context_terms": "Required context terms",
            "active_status": "Status",
            "notes": "Notes",
        }, height=500)


def match_testing_page(matches, hit_detail, scored, cfg) -> None:
    section("Match testing", "match")
    st.markdown("This page shows which counterparties matched, which aliases matched, and whether the article likely relates to the counterparty. The relevance check is automated and should be reviewed before relying on it.")
    theme = st.selectbox("Risk theme", ["All"] + theme_options(cfg), key="match_theme")
    scored_filtered = apply_theme_filter(scored, theme)
    if theme != "All" and scored_filtered is not None and not scored_filtered.empty:
        keep = set(scored_filtered["article_id"].astype(str) + "|" + scored_filtered["counterparty_id"].astype(str))
        matches = matches[(matches["article_id"].astype(str) + "|" + matches["counterparty_id"].astype(str)).isin(keep)] if matches is not None and not matches.empty else matches
    table(matches, {
        "article_id": "Article ID",
        "counterparty_name": "Counterparty matched",
        "alias_matched": "Alias matched",
        "alias_category": "Alias type",
        "entity_match_confidence": "Match confidence",
        "needs_human_review": "Needs review",
        "automated_relevance_check": "Does it likely relate",
        "match_reason": "Match reason",
        "title": "Article",
        "source_name": "Source",
    }, height=520)
    download_button(matches, "Download match test", "article_counterparty_match_test.csv")
    section("Alias hit detail", "alias")
    table(hit_detail, {
        "article_id": "Article ID",
        "counterparty_name": "Counterparty",
        "alias_matched": "Alias",
        "requires_context": "Context needed",
        "context_passed": "Context found",
        "context_hits": "Context terms",
        "do_not_match_hits": "Do not match hits",
        "entity_match_confidence": "Match confidence",
        "suppressed": "Suppressed",
        "title": "Article",
    }, height=420)
    download_button(hit_detail, "Download alias hit detail", "article_alias_hit_detail.csv")
    section("Scored matched rows", "items")
    table(scored_filtered, {
        "review_bucket": "Placement",
        "counterparty_name": "Counterparty",
        "themes": "Risk theme",
        "entity_match_confidence": "Match confidence",
        "overall_priority_score": "Score",
        "claim_status": "Claim status",
        "reason_codes": "Reason codes",
        "gate_failure_reasons": "Gate failures",
        "title": "Article",
    }, height=420)


def email_page(scored) -> None:
    section("Priority email", "mail")
    settings = load_email_settings(DATA_DIR)
    recipients = load_recipients(DATA_DIR)
    active = recipients[recipients["active_status"].astype(str).str.lower() == "active"].copy()
    previous = recipients[recipients["active_status"].astype(str).str.lower() != "active"].copy()
    priority_count = int(scored["review_bucket"].astype(str).eq("Priority items").sum()) if scored is not None and not scored.empty else 0
    cards([
        ("Priority items", priority_count, "Only this placement is included in the email body.", "shield", True),
        ("Active recipients", len(active), "People currently included in BCC.", "person", False),
        ("Previous recipients", len(previous), "People removed from the active list.", "person", False),
        ("Send mode", settings.get("send_mode", "Preview only"), "Preview is the safest default until SMTP is configured.", "mail", True),
    ])
    tab_recipients, tab_compose, tab_log, tab_directory = st.tabs(["Recipients", "Compose", "Send log", "Directory option"])
    with tab_recipients:
        st.markdown("Recipients must use @paypal.com email addresses. Removed recipients stay searchable in the previous recipient list.")
        q = st.text_input("Search recipients", placeholder="Name or email")
        show_status = st.selectbox("Recipient status", ["Active", "Previous", "All"])
        shown = recipients.copy()
        if show_status == "Active":
            shown = shown[shown["active_status"].astype(str).str.lower() == "active"]
        elif show_status == "Previous":
            shown = shown[shown["active_status"].astype(str).str.lower() != "active"]
        if q:
            searchable = shown[["display_name", "email", "notes"]].astype(str).agg(" ".join, axis=1).str.lower()
            shown = shown[searchable.str.contains(q.lower().strip(), na=False)]
        table(shown, {
            "recipient_id": "Recipient ID",
            "display_name": "Name",
            "email": "Email",
            "active_status": "Status",
            "added_at": "Added",
            "removed_at": "Removed",
            "notes": "Notes",
        }, height=360)
        c1, c2 = st.columns(2)
        with c1:
            with st.form("add_recipient_form"):
                name = st.text_input("Name")
                email = st.text_input("Email", placeholder="name@paypal.com")
                notes = st.text_input("Notes")
                submitted = st.form_submit_button("Add recipient")
            if submitted:
                ok, msg = add_recipient(DATA_DIR, name, email, notes)
                if ok:
                    log_event(DATA_DIR, actor_context(), "email_recipient_change", "priority_email", "Added email recipient", "email_recipient", email, name, msg, "", email, status="Completed")
                    st.success(msg)
                    refresh_data()
                else:
                    log_event(DATA_DIR, actor_context(), "email_recipient_change", "priority_email", "Failed to add email recipient", "email_recipient", email, name, msg, "", email, status="Blocked")
                    st.error(msg)
        with c2:
            active_labels = {f"{row.display_name} | {row.email}": row.recipient_id for _, row in active.iterrows()}
            if active_labels:
                selected = st.selectbox("Remove active recipient", list(active_labels.keys()))
                if st.button("Remove recipient"):
                    ok, msg = deactivate_recipient(DATA_DIR, active_labels[selected])
                    if ok:
                        log_event(DATA_DIR, actor_context(), "email_recipient_change", "priority_email", "Removed email recipient", "email_recipient", active_labels[selected], selected, msg, "Active", "Inactive")
                        st.success(msg)
                        refresh_data()
                    else:
                        log_event(DATA_DIR, actor_context(), "email_recipient_change", "priority_email", "Failed to remove email recipient", "email_recipient", active_labels[selected], selected, msg, "", "", status="Blocked")
                        st.error(msg)
            else:
                st.info("No active recipients yet.")
    with tab_compose:
        st.markdown("The email is sent with recipients in BCC. The sender account is still treated as TBD until your team provides an approved mailbox and SMTP settings.")
        c1, c2 = st.columns(2)
        sender_email = c1.text_input("General sender email", value=settings.get("sender_email", "TBD"))
        sender_name = c2.text_input("Sender display name", value=settings.get("sender_name", "External Risk Monitor"))
        mode = st.selectbox("Mode", ["Preview only", "Send if SMTP is configured"], index=0 if settings.get("send_mode", "Preview only") == "Preview only" else 1)
        if st.button("Save email settings"):
            old_sender_email = settings.get("sender_email", "")
            old_sender_name = settings.get("sender_name", "")
            old_mode = settings.get("send_mode", "")
            save_email_setting(DATA_DIR, "sender_email", sender_email)
            save_email_setting(DATA_DIR, "sender_name", sender_name)
            save_email_setting(DATA_DIR, "send_mode", mode)
            if old_sender_email != sender_email:
                log_event(DATA_DIR, actor_context(), "settings_change", "priority_email", "Changed sender email", "email_setting", "sender_email", "General sender email", "Sender email setting updated.", old_sender_email, sender_email)
            if old_sender_name != sender_name:
                log_event(DATA_DIR, actor_context(), "settings_change", "priority_email", "Changed sender display name", "email_setting", "sender_name", "Sender display name", "Sender display name updated.", old_sender_name, sender_name)
            if old_mode != mode:
                log_event(DATA_DIR, actor_context(), "settings_change", "priority_email", "Changed send mode", "email_setting", "send_mode", "Mode", "Email mode updated.", old_mode, mode)
            st.success("Email settings saved.")
            refresh_data()
        subject, body = compose_priority_email(scored, sender_name)
        st.text_input("Subject", value=subject, disabled=True)
        st.text_area("Email preview", value=body, height=340, disabled=True)
        ready, ready_msg = smtp_ready(sender_email)
        if mode == "Send if SMTP is configured":
            st.info(ready_msg)
        c3, c4 = st.columns(2)
        if c3.button("Log preview"):
            ok, msg = send_priority_email(DATA_DIR, scored, sender_email, sender_name, active, dry_run=True)
            log_event(DATA_DIR, actor_context(), "email_activity", "priority_email", "Logged email preview", "email", sender_email, subject, msg, "", f"recipients={len(active)}; priority_items={priority_count}", status="Completed" if ok else "Blocked")
            if ok:
                st.success(msg)
                refresh_data()
            else:
                st.error(msg)
        if c4.button("Send priority email"):
            dry_run = mode != "Send if SMTP is configured"
            ok, msg = send_priority_email(DATA_DIR, scored, sender_email, sender_name, active, dry_run=dry_run)
            log_event(DATA_DIR, actor_context(), "email_activity", "priority_email", "Sent or attempted priority email", "email", sender_email, subject, msg, "", f"dry_run={dry_run}; recipients={len(active)}; priority_items={priority_count}", status="Completed" if ok else "Blocked")
            if ok:
                st.success(msg)
                refresh_data()
            else:
                st.error(msg)
    with tab_log:
        log = load_email_log(DATA_DIR)
        table(log.sort_values("sent_at", ascending=False) if not log.empty else log, {
            "sent_at": "Time",
            "mode": "Mode",
            "sender_email": "Sender",
            "recipient_count": "Recipients",
            "subject": "Subject",
            "item_count": "Items",
            "status": "Status",
            "error": "Message",
        }, height=460)
    with tab_directory:
        st.markdown("A live Outlook or corporate directory connection is not included in this local version. That should use an approved internal identity or Microsoft Graph setup with company-managed credentials. Until that exists, the dashboard uses a local recipient register and requires @paypal.com addresses.")


def settings_page(cfg) -> None:
    section("Settings", "settings")
    st.markdown("Use this page to review current thresholds, coded risk themes, and the rolling audit trail. Audit times are stored in UTC.")
    tab_profile, tab_thresholds, tab_themes, tab_audit = st.tabs(["User and matching", "Current settings", "Risk themes", "Audit and retention"])
    with tab_profile:
        st.markdown("These local settings control who is recorded in the audit trail and how nearby article terms are evaluated in the sample run.")
        c1, c2 = st.columns(2)
        with c1:
            st.text_input("Your name", key="audit_actor_name", value=st.session_state.get("audit_actor_name", "Local user"))
            st.text_input("Your PayPal email", key="audit_actor_email", value=st.session_state.get("audit_actor_email", ""), placeholder="name@paypal.com")
        with c2:
            st.text_input("IP address", key="audit_ip_address", value=st.session_state.get("audit_ip_address", get_client_ip_hint()), disabled=True)
            st.caption("Local Streamlit usually cannot capture IP unless an internal proxy passes request headers.")
        c3, c4 = st.columns(2)
        with c3:
            st.slider("Business context word range", 6, 30, key="context_window", step=1)
        with c4:
            st.slider("Risk word range", 6, 30, key="token_window", step=1)
        st.caption("Changes are logged with UTC time in the audit trail.")
    with tab_thresholds:
        st.markdown("These settings are loaded from the configuration file. Sidebar controls let you test the matching and nearby word ranges without editing code.")
        thresholds = threshold_summary(cfg)
        table(thresholds, {
            "category": "Category",
            "setting": "Setting",
            "current_value": "Current value",
            "note": "Meaning",
        }, height=560)
    with tab_themes:
        theme_df = pd.DataFrame([{"risk_theme": theme, "included_in_filter": "Yes"} for theme in theme_options(cfg)])
        table(theme_df, {"risk_theme": "Risk theme", "included_in_filter": "Available in dashboard filter"}, height=420)
    with tab_audit:
        st.markdown("The local audit log stores counterparty changes, alias changes, email recipient changes, email activity, and settings changes. The rolling retention period is 120 days by default.")
        retention_days = st.number_input("Retention period in days", min_value=30, max_value=180, value=DEFAULT_RETENTION_DAYS, step=10)
        cards([
            ("Retention window", f"{retention_days} days", "Records older than this are deleted during cleanup.", "audit", True),
            ("Current UTC time", utc_now_iso(), "Audit timestamps use UTC.", "settings", False),
            ("Client IP", actor_context().get("ip_address", "Unavailable locally"), "Local Streamlit usually cannot reliably capture IP unless headers are passed by an internal proxy.", "match", False),
            ("Session ID", actor_context().get("session_id", ""), "Generated locally for this Streamlit session.", "person", True),
        ])
        st.markdown("Retention status")
        table(retention_summary(DATA_DIR, int(retention_days)), {"item": "Item", "value": "Value", "meaning": "Meaning"}, height=260)
        c1, c2 = st.columns(2)
        if c1.button("Run retention cleanup now"):
            result = purge_expired_records(DATA_DIR, int(retention_days), cleanup_cache=True)
            log_event(DATA_DIR, actor_context(), "retention_cleanup", "settings", "Manual retention cleanup", "retention", "audit_and_cache", "Rolling audit storage", str(result), "", f"retention_days={retention_days}")
            st.cache_data.clear()
            st.success("Retention cleanup completed.")
            st.rerun()
        if c2.button("Clear Streamlit cached calculations"):
            log_event(DATA_DIR, actor_context(), "cache_activity", "settings", "Cleared Streamlit cache", "cache", "streamlit_cache", "Streamlit cache", "Manual cache clear from settings page.")
            st.cache_data.clear()
            st.success("Cached calculations cleared.")
            st.rerun()
        audit = load_audit_log(DATA_DIR, int(retention_days))
        st.markdown("Audit trail")
        c3, c4, c5 = st.columns(3)
        with c3:
            event_type = st.selectbox("Event type", ["All"] + sorted(audit["event_type"].dropna().astype(str).unique().tolist()) if not audit.empty else ["All"])
        with c4:
            area = st.selectbox("Area", ["All"] + sorted(audit["area"].dropna().astype(str).unique().tolist()) if not audit.empty else ["All"])
        with c5:
            search = st.text_input("Search audit trail", placeholder="Actor, email, target, detail")
        shown = audit.copy()
        if event_type != "All":
            shown = shown[shown["event_type"].astype(str) == event_type]
        if area != "All":
            shown = shown[shown["area"].astype(str) == area]
        if search:
            q = search.lower().strip()
            searchable = shown.astype(str).agg(" ".join, axis=1).str.lower()
            shown = shown[searchable.str.contains(q, na=False)]
        shown = shown.sort_values("event_time_utc", ascending=False) if not shown.empty else shown
        table(shown, {
            "event_time_utc": "Time UTC",
            "event_type": "Event type",
            "area": "Area",
            "action": "Action",
            "actor_name": "By whom",
            "actor_email": "Actor email",
            "ip_address": "IP",
            "target_type": "Target type",
            "target_id": "Target ID",
            "target_name": "Target",
            "detail": "Detail",
            "old_value": "Before",
            "new_value": "After",
            "status": "Status",
        }, height=520)
        download_button(shown, "Download audit trail", "audit_trail_last_120_days.csv")
        st.markdown("Cleanup history")
        cleanup_log = load_retention_log(DATA_DIR).sort_values("cleanup_time_utc", ascending=False)
        table(cleanup_log, {
            "cleanup_time_utc": "Cleanup time UTC",
            "retention_days": "Retention days",
            "audit_rows_deleted": "Audit rows deleted",
            "email_rows_deleted": "Email rows deleted",
            "counterparty_change_rows_deleted": "Counterparty log rows deleted",
            "cache_items_deleted": "Cache items deleted",
            "status": "Status",
        }, height=260)


def main() -> None:
    initialize_email_files(DATA_DIR)
    initialize_audit_files(DATA_DIR)
    st.set_page_config(page_title="External counterparty risk monitor", layout="wide", page_icon="○", initial_sidebar_state="collapsed")
    set_style()
    st.session_state.setdefault("audit_actor_name", "Local user")
    st.session_state.setdefault("audit_actor_email", "")
    st.session_state.setdefault("audit_ip_address", get_client_ip_hint())
    st.session_state.setdefault("context_window", 18)
    st.session_state.setdefault("token_window", 12)
    if "retention_cleanup_done" not in st.session_state:
        purge_expired_records(DATA_DIR, DEFAULT_RETENTION_DAYS, cleanup_cache=True)
        st.session_state["retention_cleanup_done"] = True
    page = page_from_query()
    render_top_banner(page)
    context_window = int(st.session_state.get("context_window", 18))
    token_window = int(st.session_state.get("token_window", 12))
    log_setting_change_if_needed("context_window", context_window, "Business context word range")
    log_setting_change_if_needed("token_window", token_window, "Risk word range")
    articles, counterparties, aliases, exclusions, scored, aux = run_portfolio_pipeline(context_window, token_window)
    matches = aux["matches"]
    hit_detail = aux["hit_detail"]
    cfg = aux["cfg"]
    if page == "Overview":
        overview_page(counterparties, aliases, exclusions, matches, scored, hit_detail)
    elif page == "Current items":
        current_items_page(scored, cfg)
    elif page == "Counterparty portfolio":
        portfolio_page(counterparties, aliases, matches, scored)
    elif page == "Alias review":
        alias_page(counterparties, aliases, exclusions)
    elif page == "Match testing":
        match_testing_page(matches, hit_detail, scored, cfg)
    elif page == "Priority email":
        email_page(scored)
    else:
        settings_page(cfg)

if __name__ == "__main__":
    main()
