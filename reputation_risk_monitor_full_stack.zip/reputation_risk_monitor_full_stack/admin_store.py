from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

COUNTERPARTY_COLUMNS = [
    "counterparty_id", "source_number", "legal_name", "common_name", "ticker", "ticker_exchange_hint",
    "ticker_status", "known_subsidiary_brand_names", "dangerous_short_aliases", "do_not_match_terms",
    "counterparty_type_guess", "type_guess_confidence", "country_guess", "source_name_status",
    "importance_tier", "exposure_index", "relationship_owner", "notes", "active_status",
    "search_enabled_default", "match_risk_level", "alias_review_required", "review_flags",
]

ALIAS_COLUMNS = [
    "alias_id", "counterparty_id", "alias_text", "alias_category", "match_strength", "requires_context",
    "dangerous_short_alias", "active_status", "review_status", "notes",
]

EXCLUSION_COLUMNS = [
    "exclusion_id", "counterparty_id", "alias_text", "do_not_match_terms", "require_context_terms", "active_status", "notes",
]

CHANGE_LOG_COLUMNS = [
    "changed_at", "action", "counterparty_id", "counterparty_name", "detail",
]

RECIPIENT_COLUMNS = [
    "recipient_id", "display_name", "email", "active_status", "added_at", "removed_at", "notes",
]

EMAIL_SETTINGS_COLUMNS = ["setting", "value"]
EMAIL_LOG_COLUMNS = ["sent_at", "mode", "sender_email", "recipient_count", "subject", "item_count", "status", "error"]


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def read_csv(path: Path, columns: list[str]) -> pd.DataFrame:
    if path.exists():
        df = pd.read_csv(path)
    else:
        df = pd.DataFrame(columns=columns)
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    df = df[columns + [c for c in df.columns if c not in columns]]
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].fillna("")
    return df


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def next_numeric_id(existing: pd.Series, prefix: str, width: int = 4) -> str:
    nums = []
    for value in existing.astype(str).tolist():
        if value.startswith(prefix):
            tail = value.replace(prefix, "", 1)
            if tail.isdigit():
                nums.append(int(tail))
    return f"{prefix}{(max(nums) + 1) if nums else 1:0{width}d}"


def append_change_log(data_dir: Path, action: str, counterparty_id: str, counterparty_name: str, detail: str) -> None:
    path = data_dir / "counterparty_change_log.csv"
    df = read_csv(path, CHANGE_LOG_COLUMNS)
    df.loc[len(df)] = [now_iso(), action, counterparty_id, counterparty_name, detail]
    save_csv(df, path)


def add_counterparty(data_dir: Path, payload: dict) -> str:
    cp_path = data_dir / "counterparties.csv"
    alias_path = data_dir / "counterparty_aliases.csv"
    counterparties = read_csv(cp_path, COUNTERPARTY_COLUMNS)
    aliases = read_csv(alias_path, ALIAS_COLUMNS)
    new_id = next_numeric_id(counterparties["counterparty_id"], "CPTY_", 4)
    legal_name = str(payload.get("legal_name", "")).strip()
    common_name = str(payload.get("common_name", "")).strip() or legal_name
    ticker = str(payload.get("ticker", "")).strip().upper()
    row = {col: "" for col in COUNTERPARTY_COLUMNS}
    row.update({
        "counterparty_id": new_id,
        "source_number": "Manual",
        "legal_name": legal_name,
        "common_name": common_name,
        "ticker": ticker,
        "ticker_exchange_hint": str(payload.get("ticker_exchange_hint", "")).strip(),
        "ticker_status": "User entered" if ticker else "Not provided",
        "known_subsidiary_brand_names": str(payload.get("known_subsidiary_brand_names", "")).strip(),
        "dangerous_short_aliases": str(payload.get("dangerous_short_aliases", "")).strip(),
        "do_not_match_terms": str(payload.get("do_not_match_terms", "")).strip(),
        "counterparty_type_guess": str(payload.get("counterparty_type_guess", "")).strip() or "Manual entry",
        "type_guess_confidence": "User entered",
        "country_guess": str(payload.get("country_guess", "")).strip(),
        "source_name_status": "Manual entry",
        "importance_tier": str(payload.get("importance_tier", "")).strip(),
        "exposure_index": str(payload.get("exposure_index", "")).strip(),
        "relationship_owner": str(payload.get("relationship_owner", "")).strip(),
        "notes": str(payload.get("notes", "")).strip(),
        "active_status": "Active",
        "search_enabled_default": "Yes",
        "match_risk_level": str(payload.get("match_risk_level", "Medium")).strip() or "Medium",
        "alias_review_required": "Yes",
        "review_flags": "manual entry; review aliases before broad monitoring",
    })
    counterparties.loc[len(counterparties)] = row
    added_aliases = []
    for alias_text, category, strength in [
        (legal_name, "legal_name", "Strong"),
        (common_name, "common_name", "Medium"),
        (ticker, "ticker", "Medium"),
    ]:
        alias_text = str(alias_text).strip()
        if not alias_text:
            continue
        if alias_text.lower() in {a.lower() for a in added_aliases}:
            continue
        alias_id = next_numeric_id(aliases["alias_id"], "ALIAS_", 5)
        aliases.loc[len(aliases)] = [
            alias_id, new_id, alias_text, category, strength,
            "Yes" if category == "ticker" or len(alias_text) <= 4 else "No",
            "Yes" if category == "ticker" or len(alias_text) <= 4 else "No",
            "Active", "Needs review" if category == "ticker" else "Ready", "Added with manual counterparty entry",
        ]
        added_aliases.append(alias_text)
    for extra_alias in str(payload.get("extra_aliases", "")).replace("|", ";").split(";"):
        alias_text = extra_alias.strip()
        if not alias_text or alias_text.lower() in {a.lower() for a in added_aliases}:
            continue
        alias_id = next_numeric_id(aliases["alias_id"], "ALIAS_", 5)
        aliases.loc[len(aliases)] = [alias_id, new_id, alias_text, "known_brand_or_subsidiary", "Medium", "Yes" if len(alias_text) <= 4 else "No", "Yes" if len(alias_text) <= 4 else "No", "Active", "Needs review", "Added from extra alias field"]
        added_aliases.append(alias_text)
    save_csv(counterparties, cp_path)
    save_csv(aliases, alias_path)
    append_change_log(data_dir, "add_counterparty", new_id, legal_name, f"Added {legal_name} with {len(added_aliases)} aliases")
    return new_id


def deactivate_counterparty(data_dir: Path, counterparty_id: str) -> None:
    cp_path = data_dir / "counterparties.csv"
    alias_path = data_dir / "counterparty_aliases.csv"
    excl_path = data_dir / "counterparty_exclusions.csv"
    counterparties = read_csv(cp_path, COUNTERPARTY_COLUMNS)
    aliases = read_csv(alias_path, ALIAS_COLUMNS)
    exclusions = read_csv(excl_path, EXCLUSION_COLUMNS)
    name = ""
    if counterparty_id in set(counterparties["counterparty_id"].astype(str)):
        idx = counterparties.index[counterparties["counterparty_id"].astype(str) == counterparty_id]
        name = str(counterparties.loc[idx[0], "legal_name"])
        counterparties.loc[idx, "active_status"] = "Inactive"
        counterparties.loc[idx, "search_enabled_default"] = "No"
    aliases.loc[aliases["counterparty_id"].astype(str) == counterparty_id, "active_status"] = "Inactive"
    exclusions.loc[exclusions["counterparty_id"].astype(str) == counterparty_id, "active_status"] = "Inactive"
    save_csv(counterparties, cp_path)
    save_csv(aliases, alias_path)
    save_csv(exclusions, excl_path)
    append_change_log(data_dir, "remove_counterparty", counterparty_id, name, "Set counterparty, aliases, and exclusions to inactive")


def reactivate_counterparty(data_dir: Path, counterparty_id: str) -> None:
    cp_path = data_dir / "counterparties.csv"
    counterparties = read_csv(cp_path, COUNTERPARTY_COLUMNS)
    idx = counterparties.index[counterparties["counterparty_id"].astype(str) == counterparty_id]
    if len(idx):
        counterparties.loc[idx, "active_status"] = "Active"
        counterparties.loc[idx, "search_enabled_default"] = "Yes"
        name = str(counterparties.loc[idx[0], "legal_name"])
        save_csv(counterparties, cp_path)
        append_change_log(data_dir, "reactivate_counterparty", counterparty_id, name, "Set counterparty back to active")


def add_alias(data_dir: Path, counterparty_id: str, alias_text: str, alias_category: str, match_strength: str, requires_context: bool, dangerous_short_alias: bool, notes: str = "") -> str:
    alias_path = data_dir / "counterparty_aliases.csv"
    cp_path = data_dir / "counterparties.csv"
    aliases = read_csv(alias_path, ALIAS_COLUMNS)
    counterparties = read_csv(cp_path, COUNTERPARTY_COLUMNS)
    alias_id = next_numeric_id(aliases["alias_id"], "ALIAS_", 5)
    aliases.loc[len(aliases)] = [alias_id, counterparty_id, alias_text.strip(), alias_category, match_strength, "Yes" if requires_context else "No", "Yes" if dangerous_short_alias else "No", "Active", "Needs review" if requires_context or dangerous_short_alias else "Ready", notes]
    save_csv(aliases, alias_path)
    name = ""
    sub = counterparties[counterparties["counterparty_id"].astype(str) == counterparty_id]
    if not sub.empty:
        name = str(sub.iloc[0].get("legal_name", ""))
    append_change_log(data_dir, "add_alias", counterparty_id, name, f"Added alias {alias_text}")
    return alias_id


def deactivate_alias(data_dir: Path, alias_id: str) -> None:
    alias_path = data_dir / "counterparty_aliases.csv"
    aliases = read_csv(alias_path, ALIAS_COLUMNS)
    idx = aliases.index[aliases["alias_id"].astype(str) == alias_id]
    if len(idx):
        cp_id = str(aliases.loc[idx[0], "counterparty_id"])
        alias_text = str(aliases.loc[idx[0], "alias_text"])
        aliases.loc[idx, "active_status"] = "Inactive"
        save_csv(aliases, alias_path)
        append_change_log(data_dir, "remove_alias", cp_id, "", f"Set alias inactive: {alias_text}")


def load_change_log(data_dir: Path) -> pd.DataFrame:
    return read_csv(data_dir / "counterparty_change_log.csv", CHANGE_LOG_COLUMNS)


def initialize_email_files(data_dir: Path) -> None:
    recipients_path = data_dir / "email_recipients.csv"
    settings_path = data_dir / "email_settings.csv"
    log_path = data_dir / "email_send_log.csv"
    if not recipients_path.exists():
        save_csv(pd.DataFrame(columns=RECIPIENT_COLUMNS), recipients_path)
    if not settings_path.exists():
        save_csv(pd.DataFrame([
            {"setting": "sender_email", "value": "TBD"},
            {"setting": "sender_name", "value": "External Risk Monitor"},
            {"setting": "send_mode", "value": "Preview only"},
        ], columns=EMAIL_SETTINGS_COLUMNS), settings_path)
    if not log_path.exists():
        save_csv(pd.DataFrame(columns=EMAIL_LOG_COLUMNS), log_path)
