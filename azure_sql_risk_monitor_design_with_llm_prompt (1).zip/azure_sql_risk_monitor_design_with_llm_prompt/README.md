# Azure SQL design for the counterparty risk monitor

This package defines an Azure SQL Database design for the counterparty news-monitoring workflow.

## Recommended architecture

1. The Streamlit dashboard sends a manual refresh request.
2. A Python refresh service starts an ingestion run in Azure SQL.
3. The service collects title, URL, source, snippet, published time, feed, and query metadata.
4. Obvious junk is rejected and logged.
5. Unique URLs are stored once. Related URLs are grouped under one story.
6. Active counterparties, aliases, and exclusions are loaded from Azure SQL.
7. The Python matching layer creates article-counterparty matches and evidence spans.
8. The Python classification layer assigns risk theme, claim strength, and component scores.
9. Azure SQL applies deterministic hard gates and assigns Priority, Review, or Reference.
10. Streamlit reads dashboard views and may create an email batch for Priority items.
11. Retention cleanup deletes raw articles and derived results after 120 days.

Azure SQL does not scrape websites itself. The collection step runs in the local Python application initially, or later in an approved Azure Function/API. Automatic scraping is disabled by default.

## Database schemas

- `ref`: counterparties, aliases, exclusions, themes, source quality, claim strength, categories
- `ops`: settings, thresholds, refresh runs, cleanup history
- `ingest`: staging, rejected rows, stories, accepted articles
- `risk`: matches, classifications, scores, gates, dashboard placement
- `notify`: recipients, email batches, delivery logs
- `audit`: user and system actions

## Retention

- Accepted raw articles: 120 days
- Article-counterparty matches, classifications, scores, gates, placements: 120 days through cascade deletion
- Rejected staging rows: 30 days by default
- Audit events: 120 days
- Refresh summaries: retained for 365 days by default

The purge procedure runs at the start and end of a manual refresh. For guaranteed cleanup when nobody opens the dashboard, schedule only the purge procedure through Azure Elastic Jobs. This does not enable automatic scraping.

## Deployment order

Run the SQL files in order:

1. `sql/01_schema.sql`
2. `sql/02_reference_seed.sql`
3. `sql/03_procedures.sql`
4. `sql/04_views.sql`
5. `sql/05_security.sql`
6. `sql/07_audit_triggers.sql`
7. `sql/06_retention_job.sql`

`sql/all_in_one.sql` contains the same scripts combined.

## Python integration

The `python` folder contains a database repository, refresh orchestration scaffold, Streamlit button example, and seed-data loader. The preferred authentication approach is Microsoft Entra authentication. Connection details are read from environment variables and are not stored in source code.

## Manual refresh behavior

The Refresh button should:

- call `ops.sp_StartIngestionRun` with mode `MANUAL`
- collect articles
- save all attempted rows to `ingest.ArticleStage`
- save rejected junk to `ingest.ArticleRejection`
- upsert unique stories and article URLs
- save match/classification/score output
- call `risk.sp_ApplyHardGatesForRun`
- call `ops.sp_CompleteIngestionRun`
- call `ops.sp_PurgeExpiredData`
- reload the dashboard views

The database rejects an `AUTOMATED` run unless `AUTO_SCRAPE_APPROVED` is explicitly set to `1`.
